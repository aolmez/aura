'use strict';
const express = require('express');
const router = express.Router();
const HomeController = require('../server/controllers/homeController');
const AuraDataAccess = require('../server/dataaccess/aura');

router.get('/', HomeController.index);
router.get('/heartbeat', HomeController.heartbeat);
router.get('/share', HomeController.share);
router.get('/privacypolicy', HomeController.privacypolicy);


router.get('/d', function mainHandler(req, res) {
    throw new Error('Broke!');
});
router.get('/test', function (req, res) {
    // var filter = {};
    // filter.Longitude = 39.931150;
    // filter.Latitude = 32.842499;
    // filter.PageIndex = 0;
    // let aura = new AuraDataAccess();
    // aura.getPagedNearBy(filter,function(e,q){});
    res.send('Wiki home page');
  });
 
module.exports = router;