'use strict';
const express = require('express');
const router = express.Router();
const HomeController = require('../server/controllers/homeController');
const FileController = require('../server/controllers/fileController');
const AccountController = require('../server/controllers/accountController');
const AuraDataAccess = require('../server/dataaccess/aura');
const ApplicationContext = require('../server/core/applicationContext');

router.get('/', HomeController.login);
router.post('/', HomeController.loginProcess);
router.get('/dashboard', ApplicationContext.IsAuthenticated, HomeController.dashboard);
router.post('/searchVenue', ApplicationContext.IsAuthenticated, HomeController.searchVenue);
router.post('/publish', ApplicationContext.IsAuthenticated, HomeController.publish);


router.get('/account', ApplicationContext.IsAuthenticated, AccountController.index);
router.post('/account/create', ApplicationContext.IsAuthenticated, AccountController.create);
router.get('/account/getAllUser', ApplicationContext.IsAuthenticated, AccountController.getAllUser);

router.use('/uploader', require('express-plupload').middleware);
router.post('/uploader', FileController.uploader); 
router.post('/uploadTemp', require('express-plupload').middleware);
router.post('/uploadTemp', FileController.uploadTemp); 


module.exports = router;