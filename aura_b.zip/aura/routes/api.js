'use strict';
const express = require('express');
const authenticationStrategy = require('../server/core/authenticationStrategy');
const router = express.Router();
const ApplicationContext = require('../server/core/applicationContext');
const AccountApiController = require('../server/controllers/accountApiController');
const AuraApiController = require('../server/controllers/auraApiController');
const ActorApiController = require('../server/controllers/actorApiController');
const DeviceController = require('../server/controllers/deviceController');
const NotificationController = require('../server/controllers/notificationController');
const InformationMessageController = require('../server/controllers/informationMessageController');
const SettingController = require('../server/controllers/settingController');

router.get('/heartbeat', AccountApiController.heartbeat);
router.post('/account/loginByFacebook', AccountApiController.loginByFacebook);
router.post('/account/loginByGoogle', AccountApiController.loginByGoogle);
router.post('/account/checkUsername', authenticationStrategy.isAuthenticated, AccountApiController.checkUsername);
router.post('/account/followUserWithFacebookId', authenticationStrategy.isAuthenticated, AccountApiController.followUserWithFacebookId);
router.post('/account/followUserWithFacebookIdNew', authenticationStrategy.isAuthenticated, AccountApiController.followUserWithFacebookIdNew);
router.post('/account/updateMetadata', authenticationStrategy.isAuthenticated, AccountApiController.updateMetadata);
router.post('/account/uploadAvatar', authenticationStrategy.isAuthenticated, AccountApiController.uploadAvatar);
router.post('/account/getStatistics', authenticationStrategy.isAuthenticated, AccountApiController.getStatistics);
router.post('/account/followUserById', authenticationStrategy.isAuthenticated, AccountApiController.followUserById);
router.post('/account/unfollowUserById', authenticationStrategy.isAuthenticated, AccountApiController.unfollowUserById);
router.post('/account/getUserFollowers', authenticationStrategy.isAuthenticated, AccountApiController.getUserFollowers);
router.post('/account/getUserFollowings', authenticationStrategy.isAuthenticated, AccountApiController.getUserFollowings);
router.post('/account/getUserFollowersWithUserId', authenticationStrategy.isAuthenticated, AccountApiController.getUserFollowersWithUserId);
router.post('/account/getUserFollowingsWithUserId', authenticationStrategy.isAuthenticated, AccountApiController.getUserFollowingsWithUserId);
router.post('/account/deactive', authenticationStrategy.isAuthenticated, AccountApiController.deactive);
router.post('/account/blockUser', authenticationStrategy.isAuthenticated, AccountApiController.blockUser);
router.post('/account/unblockUser', authenticationStrategy.isAuthenticated, AccountApiController.unblockUser);
router.post('/account/getPagedBlockUser', authenticationStrategy.isAuthenticated, AccountApiController.getPagedBlockUser);

router.post('/venue/star', authenticationStrategy.isAuthenticated, AccountApiController.starVenue);
router.post('/venue/unstar', authenticationStrategy.isAuthenticated, AccountApiController.unstarVenue);
router.post('/venue/getPaged', authenticationStrategy.isAuthenticated, AccountApiController.getVenuePaged);

router.post('/aura/getById', authenticationStrategy.isAuthenticated, AuraApiController.getById);
router.post('/aura/publish', authenticationStrategy.isAuthenticated, AuraApiController.publish);
router.post('/aura/getPaged', authenticationStrategy.isAuthenticated, AuraApiController.getPaged);
router.post('/aura/getPagedNearBy', authenticationStrategy.isAuthenticated, AuraApiController.getPagedNearBy);
router.post('/aura/like', authenticationStrategy.isAuthenticated, AuraApiController.like);
router.post('/aura/unlike', authenticationStrategy.isAuthenticated, AuraApiController.unlike);
router.post('/aura/watch', authenticationStrategy.isAuthenticated, AuraApiController.increaseViewerCount);
router.post('/aura/getByOwner', authenticationStrategy.isAuthenticated, AuraApiController.getByOwner);
router.post('/aura/getCoordinateByOwner', authenticationStrategy.isAuthenticated, AuraApiController.getCoordinateByOwner);
router.post('/aura/getCoordinateByUser', authenticationStrategy.isAuthenticated, AuraApiController.getCoordinateByUser);
router.post('/aura/getByVenueId', authenticationStrategy.isAuthenticated, AuraApiController.getByVenueId);
router.post('/aura/getByUser', authenticationStrategy.isAuthenticated, AuraApiController.getByUser);
router.post('/aura/getExplorePaged', authenticationStrategy.isAuthenticated, AuraApiController.getExplorePaged);
router.post('/aura/getCoordinateForMap', authenticationStrategy.isAuthenticated, AuraApiController.getCoordinateForMap);
router.post('/aura/getLikers', authenticationStrategy.isAuthenticated, AuraApiController.getLikers);
router.post('/aura/getWatchers', authenticationStrategy.isAuthenticated, AuraApiController.getWatchers);
router.post('/aura/delete', authenticationStrategy.isAuthenticated, AuraApiController.delete);

router.post('/actor/getPaged', authenticationStrategy.isAuthenticated, ActorApiController.getPaged);
router.post('/actor/getStatistics', authenticationStrategy.isAuthenticated, ActorApiController.getStatistics);
router.post('/actor/getVenueDetailById', authenticationStrategy.isAuthenticated, ActorApiController.getVenueDetailById);

router.post('/device/add', authenticationStrategy.isAuthenticated, DeviceController.add);

router.post('/notification/getPaged', authenticationStrategy.isAuthenticated, NotificationController.getPaged);
router.post('/notification/send', authenticationStrategy.isAuthenticated, NotificationController.send);
router.get('/notification/sendAllUser', NotificationController.sendAllUser);

router.post('/informationmessage/reportproblem', authenticationStrategy.isAuthenticated, InformationMessageController.reportProblem);
router.post('/informationmessage/shareidea', authenticationStrategy.isAuthenticated, InformationMessageController.shareIdea);
router.post('/informationmessage/reportAura', authenticationStrategy.isAuthenticated, InformationMessageController.reportAura);


router.post('/setting/pushsettings', authenticationStrategy.isAuthenticated, SettingController.setPushSetting);
router.get('/setting/pushsettings', authenticationStrategy.isAuthenticated, SettingController.getPushSetting);

router.post('/setting/aurasettings', authenticationStrategy.isAuthenticated, SettingController.setAuraSetting);
router.get('/setting/aurasettings', authenticationStrategy.isAuthenticated, SettingController.getAuraSetting);

router.post('/setting/setmutesettings', authenticationStrategy.isAuthenticated, SettingController.setMuteSetting);
router.post('/setting/getmutesettings', authenticationStrategy.isAuthenticated, SettingController.getMuteSetting);
router.post('/setting/clearmutesettings', authenticationStrategy.isAuthenticated, SettingController.clearMuteSetting);


router.get('/getTermsAndConditions', SettingController.getTermsAndConditions);

module.exports = router;