const express = require('express'),
    bodyparser = require('body-parser'),
    fs = require('fs'),
    https = require('https'),
    server = express(),
    scribe = require('scribe-js')({rootPath: 'https-logs'}),
    console = process.console;
const logger = require('morgan');
const expressValidator = require('express-validator');
const cookieParser = require('cookie-parser');
const csrf = require('csurf');
const path = require('path');
const cluster = require('cluster');
const os = require('os');
const bodyParser = require('body-parser');
const session = require('express-session');
const redisStore = require('connect-redis')(session);
const debug = require('debug')('CubbySoftware');
const passport = require('passport');
const Formdata = require('./server/core/formdata');

module.exports = httpsServer;

function httpsServer(config) {
    try {
        const port = config.httpsPort,
            httpsOptions = {
                key: fs.readFileSync('server/ssl/server.key'),
                cert: fs.readFileSync('server/ssl/server.crt'),
                ca: [fs.readFileSync('server/ssl/ca.crt')],
                requestCert: true,
                rejectUnauthorized: false,
                agent: false,
                passphrase: '1234'
            };
        const pages = require('./routes/pages');
        const api = require('./routes/api');
        const adminPages = require('./routes/admin');


        server.set('view engine', 'ejs');
        server.set('views', path.join(__dirname, 'views'));
        server.engine('html', require('ejs').renderFile);
        server.set('view engine', 'ejs');


        server.set('trust proxy', 1);
        server.use(logger('dev'));
        server.use(bodyParser.json());
        server.use(bodyParser.urlencoded({extended: false}));
        server.use(expressValidator());
//app.use(express.methodover);
        server.use(cookieParser());
        server.use(passport.initialize());
        server.use(passport.session());

        server.use(require('stylus').middleware(path.join(__dirname, 'public')));
        server.use(express.static(path.join(__dirname, 'public')));
        server.use('/api', api);
        server.use(csrf({cookie: true}));
        if (process.env.USE_REDIS && process.env.USE_REDIS == 'true') {
            server.use(session({
                store: new redisStore({
                    host: process.env.REDIS_HOST,
                    port: process.env.REDIS_PORT,
                    prefix: process.env.REDIS_PREFIX,
                    ttl: 1000,
                    disableTTL: true,
                    scanCount: 32,
                    unref: true
                }),
                secret: process.env.SESSION_SECRET
            }));
        }
        else {
            server.use(session({
                secret: process.env.SESSION_SECRET,
                resave: false,
                saveUninitialized: true,
                //cookie: { secure: true }
                cookie: {maxAge: 600000, httpOnly: false}
            }));
        }
        server.use('/', pages);
        server.use('/admin', adminPages);

        // configure express to use the scribe logger
        server.use(scribe.express.logger());
        server.use('/https-logs', scribe.webPanel()); // access at https://localhost:[port]/logs

        server.use(authChecker);

        // Create and start the https server
        if (process.env.DEBUG_MODE && process.env.DEBUG_MODE == 'false' && cluster.isMaster) {
            console.log(`Master ${process.pid} is running`);
            const numCPUs = os.cpus().length;
            for (let i = 0; i < numCPUs; i++) {
                cluster.fork();
            }
            cluster.on('exit', (worker, code, signal) => {
                console.log(`worker ${worker.process.pid} died`);
            });
        }
        else {
            https.createServer(httpsOptions, server).listen(port, function () {
                console.log(' ');
                console.log('Server listening at https://localhost:' + port + '/');
            });
        }


        return server;
    } catch (err) {
        console.log(err);
    }
    return null;
}

function authChecker(req, res, next) {
    console.log(' ');
    console.log('-----------------------------------');
    console.log('Auth Checker');
    console.log('authorized: ' + req.client.authorized);
    console.log('req.url: ' + req.url);

    if (req.client.authorized === true) {
        //console.log('authChecker - authorized');
        next();
    } else {
        let formdata = new Formdata();
        formdata.ErrorCode = 401;
        formdata.IsSuccess = false;
        res.status(401).json(formdata);
        //console.log('authChecker - 401');
        //res.status(401).render('home/unauthorized');
    }

    console.log('-----------------------------------');
    console.log(' ');
}
