'use strict';
const Formdata = require('../core/formdata');
const BasicAuthentication = require('../core/basic-auth');
const ApplicationContext = require('../core/applicationContext');
const UserModel = require('../models/usermodel');

class BasicAuthenticationAttribute {

    static check(req, res, next) {
        let formdata = new Formdata();
        const credentials = BasicAuthentication(req);
        if (credentials) {



        } else {
            formdata.ErrorCode = 401;
            formdata.Errors = 'Kullanıcı adı ve şifrenizi kontrol ediniz.';
            formdata.IsSuccess = false;
            res.json(formdata);
        }
    }

}
module.exports = BasicAuthenticationAttribute;

