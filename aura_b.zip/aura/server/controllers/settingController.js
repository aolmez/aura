'use strict';
const stringify = require('json-stringify');
const Formdata = require('../core/formdata');
const Application = require("../../app");
const ApplicationContext = require('../core/applicationContext');
const NotificationDataAccess = require('../dataaccess/notification');
const PagedFilter = require('../models/pagedFilter');
const DeviceDataAccess = require('../dataaccess/device');
const DeviceModel = require('../models/devicemodel');
const DeviceType = require('../models/devicetype');
const NotificationType = require('../models/notificationType');
const SettingsDataAccess = require('../dataaccess/settings');
const PushSettingModel = require('../models/pushsettingmodel');
const AuraSettingModel = require('../models/aurasettingmodel');
const AuraSettingsType = require('../models/aurasettingtype');
const MuteUserModel = require('../models/muteusermodel');

class SettingController {
    static getTermsAndConditions(req, res, next) {
        let formdata = new Formdata();
        let settingsDataAccess = new SettingsDataAccess();
        settingsDataAccess.getById(process.env.SETTINGS_PARAMS_TERMS_AND_CONDITIONS, function (response, setting) {
            if (response) {
                formdata.Errors = response.message;
                formdata.IsSuccess = false;
                res.json(formdata);
            }
            else {
                formdata.Data = setting.Value;
                formdata.IsSuccess = true;
                res.json(formdata);
            }
        });
    }

    static setPushSetting(req, res, next) {
        let formdata = new Formdata();
        req.assert('Status', 'Lütfen  Status giriniz.').notEmpty();
        req.assert('NotificationType', 'Lütfen  NotificationType giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            const document = req.body;
            let settingsDataAccess = new SettingsDataAccess();
            let setting = new PushSettingModel();
            setting.DocumentId = currentUser.DocumentId + '::' + document.NotificationType;
            setting.Status = document.Status;
            setting.NotificationType = document.NotificationType;
            setting.OwnerDocumentId = currentUser.DocumentId;
            settingsDataAccess.save(setting, function (response, setting) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static getPushSetting(req, res, next) {
        let formdata = new Formdata();
        let currentUser = req.user;
        let settingsDataAccess = new SettingsDataAccess();
        settingsDataAccess.getSettings(currentUser.DocumentId, function (response, settings) {
            if (response) {
                formdata.Errors = response.message;
                formdata.IsSuccess = false;
                res.json(formdata);
            }
            else {
                formdata.Data = stringify(settings, null, 2, { offset: 4 });
                formdata.IsSuccess = true;
                res.json(formdata);
            }
        });
    }

    static setAuraSetting(req, res, next) {
        let formdata = new Formdata();
        req.assert('Status', 'Lütfen  Status giriniz.').notEmpty();
        req.assert('AuraSettingsType', 'Lütfen  AuraSettingsType giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            const document = req.body;
            let settingsDataAccess = new SettingsDataAccess();
            let setting = new AuraSettingModel();
            setting.DocumentId = 'as::' + currentUser.DocumentId + '::' + document.AuraSettingsType;//aura setting
            setting.Status = document.Status;
            setting.AuraSettingsType = document.AuraSettingsType;
            setting.OwnerDocumentId = currentUser.DocumentId;
            settingsDataAccess.save(setting, function (response, setting) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static getAuraSetting(req, res, next) {
        let formdata = new Formdata();
        let currentUser = req.user;
        let settingsDataAccess = new SettingsDataAccess();
        settingsDataAccess.getAuraSettings(currentUser.DocumentId, function (response, settings) {
            if (response) {
                formdata.Errors = response.message;
                formdata.IsSuccess = false;
                res.json(formdata);
            }
            else {
                formdata.Data = stringify(settings, null, 2, { offset: 4 });
                formdata.IsSuccess = true;
                res.json(formdata);
            }
        });
    }

    static setMuteSetting(req, res, next) {
        let formdata = new Formdata();
        req.assert('FriendDocumentId', 'Lütfen  FriendDocumentId giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            const document = req.body;
            let settingsDataAccess = new SettingsDataAccess();
            let setting = new MuteUserModel();
            setting.DocumentId = 'ms::' + currentUser.DocumentId + '::' + document.FriendDocumentId;
            setting.FriendDocumentId = document.FriendDocumentId;
            setting.OwnerDocumentId = currentUser.DocumentId;
            settingsDataAccess.save(setting, function (response, setting) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static getMuteSetting(req, res, next) {
        let formdata = new Formdata();
        let currentUser = req.user;
        const document = req.body;
        let settingsDataAccess = new SettingsDataAccess();
        let key = 'ms::' + currentUser.DocumentId + '::' + document.FriendDocumentId;
        settingsDataAccess.getById(key, function (response, settings) {
            if (response) {
                formdata.Errors = response.message;
                formdata.IsSuccess = false;
                res.json(formdata);
            }
            else {
                formdata.Data = stringify(settings, null, 2, { offset: 4 });
                formdata.IsSuccess = true;
                res.json(formdata);
            }
        });
    }

    static clearMuteSetting(req, res, next) {
        let formdata = new Formdata();
        let currentUser = req.user;
        const document = req.body;
        let settingsDataAccess = new SettingsDataAccess();
        let key = 'ms::' + currentUser.DocumentId + '::' + document.FriendDocumentId;
        settingsDataAccess.deleteById(key, function (response, settings) {
            if (response) {
                formdata.Errors = response.message;
                formdata.IsSuccess = false;
                res.json(formdata);
            }
            else {
                formdata.Data = stringify(settings, null, 2, { offset: 4 });
                formdata.IsSuccess = true;
                res.json(formdata);
            }
        });
    }
}

module.exports = SettingController;
