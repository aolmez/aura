'use strict';
const couchbase = require("couchbase");
const uuidv1 = require('uuid/v1');
const stringify = require('json-stringify');
const Formdata = require('../core/formdata');
const ApplicationContext = require('../core/applicationContext');
const PagedFilter = require('../models/pagedFilter');
const UserModel = require('../models/usermodel');
const UserDataAccess = require('../dataaccess/user');

class ActorApiController {

    static getPaged(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  BaseType giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let userDataAccess = new UserDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            if (filter.Title.startsWith("@")) {
                filter.Title = ApplicationContext.trimByChar(filter.Title, "@");
                if (filter.Title.length > 0) {
                    userDataAccess.getByCity(filter, function (response, result) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        }
                        else {
                            formdata.Data = stringify(result, null, 2, { offset: 4 });
                            formdata.IsSuccess = true;
                            res.json(formdata);
                        }
                    });
                } else {
                    formdata.Data = stringify([], null, 2, { offset: 4 });
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            }
            else {
                userDataAccess.getByName(filter, function (response, result) {
                    if (response) {
                        formdata.Errors = response.message;
                        formdata.IsSuccess = false;
                        res.json(formdata);
                    }
                    else {
                        formdata.Data = stringify(result, null, 2, { offset: 4 });
                        formdata.IsSuccess = true;
                        res.json(formdata);
                    }
                });
            }
        }
    }

    static getStatistics(req, res, next) {
        let formdata = new Formdata();
        req.assert('DocumentId', 'Lütfen , E-posta adresini giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;
            let currentUser = req.user;
            userDataAccess.getById(document.DocumentId, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    userDataAccess.isFollowedUserById(currentUser.DocumentId, document.DocumentId, function (response, isFollowed) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        } else {
                            if (isFollowed && isFollowed.length > 0) {
                                result.IsFollowUser = true;
                            } else {
                                result.IsFollowUser = false;
                            }
                            formdata.Data = stringify(result, null, 2, { offset: 4 });
                            formdata.IsSuccess = true;
                            res.json(formdata);
                        }
                    });
                }
            });
        }
    }

    static getVenueDetailById(req, res, next) {
        let formdata = new Formdata();
        req.assert('DocumentId', 'Lütfen , DocumentId adresini giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;
            let currentUser = req.user;
            userDataAccess.getVenueDetailById(currentUser.DocumentId, document.DocumentId, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    formdata.Data = stringify(result, null, 2, { offset: 4 });
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }
}
module.exports = ActorApiController;