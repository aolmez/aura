'use strict';
const aws = require('aws-sdk');
const uuidv1 = require('uuid/v1');
const stringify = require('json-stringify');
const Formdata = require('../core/formdata');
const ApplicationContext = require('../core/applicationContext');
const DeviceDataAccess = require('../dataaccess/device');
const DeviceModel = require('../models/devicemodel');
const DeviceType = require('../models/devicetype');

class DeviceController {
    static add(req, res, next) {
        let formdata = new Formdata();
        req.assert('Token', 'Lütfen ,Token giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let deviceDataAccess = new DeviceDataAccess();
            const document = req.body;
            let device = new DeviceModel();
            device.OwnerId = currentUser.DocumentId;
            device.Token = document.Token;
            device.DeviceType = document.DeviceType;
            device.DocumentId = device.Token;
            deviceDataAccess.save(device, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, { offset: 4 });
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }
}

module.exports = DeviceController;
