'use strict';
const aws = require('aws-sdk');
const uuidv1 = require('uuid/v1');
const underscore = require('underscore');
const format = require('string-format');
const stringify = require('json-stringify');
const Application = require("../../app");
const Formdata = require('../core/formdata');
const AWSImageManager = require('../core/awsImageManager');
const AWSElasticTranscoder = require('../core/awsElasticTranscoder');
const ApplicationContext = require('../core/applicationContext');
const AuraModel = require('../models/auramodel');
const AuraType = require('../models/auratype');
const AuraDataAccess = require('../dataaccess/aura');
const PagedFilter = require('../models/pagedFilter');
const AuraLikersModel = require('../models/auralikersmodel');
const UserDataAccess = require('../dataaccess/user');
const VenueModel = require('../models/venuemodel');
const NotificationModel = require('../models/notificationModel');
const NotificationType = require('../models/notificationType');
const NotificationDataAccess = require('../dataaccess/notification');
const SettingsDataAccess = require('../dataaccess/settings');
const DeviceDataAccess = require('../dataaccess/device');
const DeviceModel = require('../models/devicemodel');
const DeviceType = require('../models/devicetype');
const AuraShareType = require('../models/aurasharetype');

class AuraApiController {

    static getById(req, res, next) {
        let formdata = new Formdata();
        req.assert('AuraDocumentId', 'Lütfen , AuraDocumentId giriniz.').notEmpty();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            auraDataAccess.getDetailById(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }


    static publish(req, res, next) {
        let formdata = new Formdata();
        req.assert('DocumentPath', 'Lütfen ,DocumentPath giriniz.').notEmpty();
        req.assert('BaseType', 'Lütfen  BaseType giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            let userDataAccess = new UserDataAccess();
            let settingsDataAccess = new SettingsDataAccess();
            let notificationDataAccess = new NotificationDataAccess();
            let deviceDataAccess = new DeviceDataAccess();
            const document = req.body;

            let aura = new AuraModel();
            aura.Owner = currentUser.DocumentId;
            aura.Author = currentUser.Username;
            aura.PhotoPath = currentUser.PhotoPath;
            aura.Title = document.Title;
            aura.VenueId = document.VenueId;
            aura.Location.latitude = document.Latitude;
            aura.Location.longitude = document.Longitude;
            aura.City = document.City;
            aura.Address = document.Address;
            aura.BaseType = document.BaseType;
            aura.ShareType = document.ShareType;
            aura.DocumentPath = document.DocumentPath;
            aura.VideoDocumentPath = document.VideoDocumentPath;
            aura.Duration = document.Duration;
            aura.IsActive = true;

            let venue = new VenueModel();
            venue.DocumentId = document.VenueId;
            venue.City = aura.City;
            venue.Location = aura.Location;
            venue.Title = aura.Title;
            venue.Address = aura.Address;
            venue.IsActive = true;
            let updateCheckInCount = true;
            if (aura.ShareType != AuraShareType.Public) {
                updateCheckInCount = false;
            }
            userDataAccess.saveVenue(currentUser, updateCheckInCount, venue).then(function (result) {
                if (aura.BaseType == AuraType.Image) {
                    AWSImageManager.copyToPictureFile(aura.DocumentPath, function (response, result) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        }
                        else {
                            auraDataAccess.save(aura, function (response, result) {
                                if (response) {
                                    formdata.Errors = response.message;
                                    formdata.IsSuccess = false;
                                    res.json(formdata);
                                }
                                else {
                                    let userDataAccess = new UserDataAccess();
                                    if (aura.ShareType == AuraShareType.Public) {
                                        userDataAccess.increaseAuraCount(currentUser.DocumentId, null);
                                    }
                                    AWSImageManager.deleteTemp(aura.DocumentPath);
                                    if (aura.ShareType == AuraShareType.Public) {
                                        if (!currentUser.AuraCount && currentUser.AuraCount == 0) {
                                            formdata.Data = stringify(result, null, 2, {offset: 4});
                                            AuraApiController.sendPushMessage(aura, req, res, next, formdata);
                                        } else {
                                            formdata.Data = stringify(result, null, 2, {offset: 4});
                                            formdata.IsSuccess = true;
                                            res.json(formdata);
                                        }
                                    } else {
                                        formdata.Data = stringify(result, null, 2, {offset: 4});
                                        formdata.IsSuccess = true;
                                        res.json(formdata);
                                    }
                                }
                            });
                        }
                    });
                }
                else {
                    AWSImageManager.copyToPictureFile(aura.DocumentPath, function (response, result) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        }
                        else {
                            AWSImageManager.copyToPictureFile(aura.VideoDocumentPath, function (response, result) {
                                if (response) {
                                    formdata.Errors = response.message;
                                    formdata.IsSuccess = false;
                                    res.json(formdata);
                                }
                                else {
                                    auraDataAccess.save(aura, function (response, result) {
                                        if (response) {
                                            formdata.Errors = response.message;
                                            formdata.IsSuccess = false;
                                            res.json(formdata);
                                        }
                                        else {
                                            let userDataAccess = new UserDataAccess();
                                            if (aura.ShareType == AuraShareType.Public) {
                                                userDataAccess.increaseAuraCount(currentUser.DocumentId, null);
                                                if (!currentUser.AuraCount && currentUser.AuraCount == 0) {
                                                    formdata.Data = stringify(result, null, 2, {offset: 4});
                                                    AuraApiController.sendPushMessage(aura, req, res, next, formdata);
                                                } else {
                                                    formdata.Data = stringify(result, null, 2, {offset: 4});
                                                    formdata.IsSuccess = true;
                                                    res.json(formdata);
                                                }
                                            } else {
                                                formdata.Data = stringify(result, null, 2, {offset: 4});
                                                formdata.IsSuccess = true;
                                                res.json(formdata);
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            }).catch(function (error) {
                formdata.Errors = error.message;
                formdata.IsSuccess = false;
                res.json(formdata);
            });
        }
    }

    static sendPushMessage(aura, req, res, next, formdata) {
        let currentUser = req.user;
        let auraDataAccess = new AuraDataAccess();
        let userDataAccess = new UserDataAccess();
        let settingsDataAccess = new SettingsDataAccess();
        let notificationDataAccess = new NotificationDataAccess();
        let deviceDataAccess = new DeviceDataAccess();
        settingsDataAccess.getById(process.env.SETTINGS_PARAMS_NOTIFICATIONS_FIRST_AURA_MESSSAGE, function (response, setting) {
            if (response) {
                formdata.Errors = response.message;
                formdata.IsSuccess = false;
                res.json(formdata);
            }
            else {
                deviceDataAccess.getFollowersByOwnerId(aura.Owner, NotificationType.FirstAura, function (response, devices) {
                    if (response) {
                        formdata.Errors = response.message;
                        formdata.IsSuccess = false;
                        res.json(formdata);
                    }
                    else {
                        if (devices.length !== 0) {
                            let notificationModel = new NotificationModel();
                            notificationModel.NotificationType = NotificationType.FirstAura;
                            notificationModel.Message = format(setting.Value, currentUser.Username);
                            notificationModel.Data = aura;
                            notificationModel.Data.DocumentPath = aura.DocumentPath;


                            let deviceOwnersPromises = Array();
                            let deviceOwners = devices.reduce((previous, item) => {
                                if (!previous.some(element => element.OwnerId === item.OwnerId)) {
                                    previous.push(item);
                                }
                                return previous;
                            }, []);
                            deviceOwners.forEach(function (deviceOwner) {
                                notificationModel.DocumentId = 'na::' + aura.DocumentId + "::" + deviceOwner;
                                notificationModel.OwnerId = deviceOwner;
                                let deviceOwnersPromise = new Promise(function (resolve, reject) {
                                    notificationDataAccess.save(notificationModel, function (response, notification) {
                                        if (response) {
                                            reject(response);
                                        }
                                        else {
                                            resolve();
                                        }
                                    });
                                });
                                deviceOwnersPromises.push(deviceOwnersPromise);
                            });

                            Promise.all(deviceOwnersPromises).then(function () {
                                let promises = Array();
                                devices.forEach(function (device) {
                                    notificationModel.DocumentId = 'na::' + aura.DocumentId + "::" + device.OwnerId;
                                    notificationModel.OwnerId = device.Owner;
                                    let data = {
                                        DocumentId: aura.DocumentId + "::" + device.OwnerId,
                                        AuraDocumentId: 'na::' + aura.DocumentId,
                                        Owner: currentUser.DocumentId,
                                        OwnerPhotoPath: currentUser.PhotoPath,
                                        Fullname: currentUser.Fullname,
                                        Username: currentUser.Username,
                                        DocumentPath: aura.DocumentPath,
                                        NotificationType: NotificationType.FirstAura.toString()
                                    };
                                    let message = {
                                        android: {
                                            priority: 'normal',
                                            notification: {
                                                title: '',
                                                body: notificationModel.Message,
                                                sound: "default"
                                            },
                                            data: data
                                        },
                                        apns: {
                                            payload: {
                                                aps: {
                                                    alert: {
                                                        title: '',
                                                        body: notificationModel.Message,
                                                        sound: "default"
                                                    }
                                                },
                                                data: data
                                            },
                                        },
                                        token: device.Token
                                    };

                                    let promise = new Promise(function (resolve, reject) {
                                        Application.notification.manager.send(message);
                                        resolve();
                                    });

                                    promises.push(promise);

                                });
                                Promise.all(promises).then(function () {
                                    formdata.IsSuccess = true;
                                    res.json(formdata);
                                }).catch(function (err) {
                                    formdata.IsSuccess = false;
                                    res.json(formdata);
                                });
                            }).catch(function (err) {
                                formdata.IsSuccess = false;
                                res.json(formdata);
                            });
                        } else {
                            formdata.IsSuccess = true;
                            res.json(formdata);
                        }
                    }
                });
            }
        });
    }

    static getPaged(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  PageIndex giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            auraDataAccess.getPaged(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static getPagedNearBy(req, res, next) {
        let formdata = new Formdata();
        req.assert('Latitude', 'Lütfen , Latitude giriniz.').notEmpty();
        req.assert('Longitude', 'Lütfen  Longitude giriniz.').notEmpty();
        req.assert('PageIndex', 'Lütfen  PageIndex giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            auraDataAccess.getPagedNearBy(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static like(req, res, next) {
        let formdata = new Formdata();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            let settingsDataAccess = new SettingsDataAccess();
            let notificationDataAccess = new NotificationDataAccess();
            let deviceDataAccess = new DeviceDataAccess();

            const document = req.body;
            let likeDocumentId = 'l::' + document.DocumentId + "::" + currentUser.DocumentId;

            let like = new AuraLikersModel();
            like.DocumentId = likeDocumentId;
            like.AuraDocumentId = document.DocumentId;
            like.Owner = currentUser.DocumentId;
            like.OwnerPhotoPath = currentUser.PhotoPath;
            like.Fullname = currentUser.Fullname;
            like.Username = currentUser.Username;

            auraDataAccess.getById(document.DocumentId, function (response, aura) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    settingsDataAccess.getById(process.env.SETTINGS_PARAMS_NOTIFICATIONS_LIKED_AURA_MESSSAGE, function (response, setting) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        }
                        else {
                            if (aura.Owner != currentUser.DocumentId) {
                                let notificationModel = new NotificationModel();
                                notificationModel.UserFriendId = currentUser.DocumentId;
                                notificationModel.OwnerId = aura.Owner;
                                notificationModel.DocumentId = likeDocumentId;
                                notificationModel.NotificationType = NotificationType.Like;
                                notificationModel.Message = format(setting.Value, currentUser.Username);
                                notificationModel.Data = like;
                                notificationModel.Data.DocumentPath = aura.DocumentPath;
                                notificationDataAccess.save(notificationModel, function (response, notification) {
                                    if (response) {
                                        formdata.Errors = response.message;
                                        formdata.IsSuccess = false;
                                        res.json(formdata);
                                    }
                                    else {
                                        deviceDataAccess.getByOwnerId(currentUser.DocumentId, aura.Owner, NotificationType.Like, function (response, devices) {
                                            if (response) {
                                                formdata.Errors = response.message;
                                                formdata.IsSuccess = false;
                                                res.json(formdata);
                                            }
                                            else {
                                                auraDataAccess.like(document.DocumentId, like, function (response, result) {
                                                    if (response) {
                                                        formdata.Errors = response.message;
                                                        formdata.IsSuccess = false;
                                                        res.json(formdata);
                                                    }
                                                    else {
                                                        formdata.Data = stringify(result, null, 2, {offset: 4});
                                                        formdata.IsSuccess = true;
                                                        devices.forEach(function (device) {
                                                            let data = {
                                                                DocumentId: likeDocumentId,
                                                                AuraDocumentId: document.DocumentId,
                                                                Owner: currentUser.DocumentId,
                                                                OwnerPhotoPath: currentUser.PhotoPath,
                                                                Fullname: currentUser.Fullname,
                                                                Username: currentUser.Username,
                                                                DocumentPath: aura.DocumentPath,
                                                                NotificationType: NotificationType.Like.toString()
                                                            };
                                                            let message = {
                                                                android: {
                                                                    priority: 'normal',
                                                                    notification: {
                                                                        title: '',
                                                                        body: notificationModel.Message,
                                                                        sound: "default"
                                                                    },
                                                                    data: data
                                                                },
                                                                apns: {
                                                                    payload: {
                                                                        aps: {
                                                                            alert: {
                                                                                title: '',
                                                                                body: notificationModel.Message,
                                                                                sound: "default"
                                                                            }
                                                                        },
                                                                        data: data
                                                                    },
                                                                },
                                                                token: device.Token
                                                            };

                                                            Application.notification.manager.send(message);
                                                        });
                                                        res.json(formdata);
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            } else {
                                auraDataAccess.like(document.DocumentId, like, function (response, result) {
                                    if (response) {
                                        formdata.Errors = response.message;
                                        formdata.IsSuccess = false;
                                        res.json(formdata);
                                    }
                                    else {
                                        formdata.Data = stringify(result, null, 2, {offset: 4});
                                        formdata.IsSuccess = true;
                                        res.json(formdata);
                                    }
                                });
                            }
                        }
                    });
                }
            });
        }
    }

    static unlike(req, res, next) {
        let formdata = new Formdata();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            let notificationDataAccess = new NotificationDataAccess();
            const document = req.body;
            let likeDocumentId = 'l::' + document.DocumentId + "::" + currentUser.DocumentId;

            let like = new AuraLikersModel();
            like.DocumentId = likeDocumentId;
            like.AuraDocumentId = document.DocumentId;
            like.Owner = currentUser.DocumentId;
            like.OwnerPhotoPath = currentUser.PhotoPath;
            like.Fullname = currentUser.Fullname;
            like.Username = currentUser.Username;

            auraDataAccess.unlike(document.DocumentId, like, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    notificationDataAccess.delete(likeDocumentId, function (response, notification) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        }
                        else {
                            formdata.Data = stringify(result, null, 2, {offset: 4});
                            formdata.IsSuccess = true;
                            res.json(formdata);
                        }
                    });
                }
            });
        }
    }

    static increaseViewerCount(req, res, next) {
        let formdata = new Formdata();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let likeDocumentId = 'w::' + document.DocumentId + "::" + currentUser.DocumentId;

            let like = new AuraLikersModel();
            like.DocumentId = likeDocumentId;
            like.AuraDocumentId = document.DocumentId;
            like.Owner = currentUser.DocumentId;
            like.Type = 'watcher';
            like.OwnerPhotoPath = currentUser.PhotoPath;
            like.Fullname = currentUser.Fullname;
            like.Username = currentUser.Username;

            auraDataAccess.increaseViewerCount(document.DocumentId, like, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static getByOwner(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  BaseType giriniz.').notEmpty().isInt();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            auraDataAccess.getByOwner(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static getByUser(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  BaseType giriniz.').notEmpty().isInt();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            filter.User = document.UserId;
            auraDataAccess.getByUser(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static getCoordinateByOwner(req, res, next) {
        let formdata = new Formdata();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            filter.PageIndex = 0;
            filter.PageSize = 2000;
            auraDataAccess.getCoordinateByOwner(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    let auras = [];
                    if (result && result != null) {
                        for (const item of result) {
                            auras.push(item.value);
                        }
                    }
                    formdata.Data = stringify(auras, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static getCoordinateByUser(req, res, next) {
        let formdata = new Formdata();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            filter.User = document.UserId;
            filter.PageIndex = 0;
            filter.PageSize = 2000;
            auraDataAccess.getCoordinateByOwner(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    let auras = [];
                    if (result && result != null) {
                        for (const item of result) {
                            auras.push(item.value);
                        }
                    }
                    formdata.Data = stringify(auras, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }


    static getByVenueId(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  BaseType giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            auraDataAccess.getByVenueId(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static getExplorePaged(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  BaseType giriniz.').notEmpty().isInt();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            auraDataAccess.getExplorePaged(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    console.log(result.map((aura, key) => aura.Title));
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static getCoordinateForMap(req, res, next) {
        let formdata = new Formdata();
        req.assert('Latitude', 'Lütfen ,DocumentPath giriniz.').notEmpty();
        req.assert('Longitude', 'Lütfen  BaseType giriniz.').notEmpty();
        req.assert('PageIndex', 'Lütfen  BaseType giriniz.').notEmpty().isInt();
        req.assert('Radius', 'Lütfen  Radius giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            filter.PageSize = 100;
            auraDataAccess.getCoordinateForMap(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static getLikers(req, res, next) {
        let formdata = new Formdata();
        req.assert('AuraDocumentId', 'Lütfen , AuraDocumentId giriniz.').notEmpty();
        req.assert('PageIndex', 'Lütfen  PageIndex giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            auraDataAccess.getLikers(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static getWatchers(req, res, next) {
        let formdata = new Formdata();
        req.assert('AuraDocumentId', 'Lütfen , AuraDocumentId giriniz.').notEmpty();
        req.assert('PageIndex', 'Lütfen  PageIndex giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            auraDataAccess.getWatchers(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static delete(req, res, next) {
        let formdata = new Formdata();
        req.assert('AuraDocumentId', 'Lütfen , AuraDocumentId giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            let userDataAccess = new UserDataAccess();
            const document = req.body;

            auraDataAccess.getById(document.AuraDocumentId, function (response, aura) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    auraDataAccess.deleteByOwnerId(document.AuraDocumentId, currentUser.DocumentId, function (response, result) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        }
                        else {
                            userDataAccess.decreaseAuraCount(currentUser.DocumentId, function (response, result) {

                            });
                            userDataAccess.decreaseCheckInCount(aura.VenueId, function (response, result) {

                            });
                            formdata.Data = stringify(result, null, 2, {offset: 4});
                            formdata.IsSuccess = true;
                            res.json(formdata);
                        }
                    });
                }
            });
        }
    }
}

module.exports = AuraApiController;