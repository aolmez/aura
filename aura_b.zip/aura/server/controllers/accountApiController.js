'use strict';
const aws = require('aws-sdk');
const async = require('async');
const couchbase = require("couchbase");
const uuidv1 = require('uuid/v1');
const fs = require('fs');
const path = require('path');
const multiparty = require('multiparty');
const format = require('string-format');
const stringify = require('json-stringify');
const atomicCounter = require('dynamodb-atomic-counter');
const Application = require("../../app");
const Formdata = require('../core/formdata');
const ApplicationContext = require('../core/applicationContext');
const PagedFilter = require('../models/pagedFilter');
const AWSImageManager = require('../core/awsImageManager');
const UserModel = require('../models/usermodel');
const UserDataAccess = require('../dataaccess/user');
const UserFriendsDataAccess = require('../dataaccess/userfriends');
const NotificationModel = require('../models/notificationModel');
const NotificationType = require('../models/notificationType');
const NotificationDataAccess = require('../dataaccess/notification');
const SettingsDataAccess = require('../dataaccess/settings');
const DeviceDataAccess = require('../dataaccess/device');
const DeviceModel = require('../models/devicemodel');
const DeviceType = require('../models/devicetype');
const UserFriendModel = require('../models/userfriendmodel');
const AuraDataAccess = require('../dataaccess/aura');
const UserSettingsDataAccess = require('../dataaccess/usersettings');
const BlockedUserModel = require('../models/blockeduser');

class AccountApiController {

    static heartbeat(req, res) {
        res.sendStatus(200);
    }

    static loginByFacebook(req, res, next) {
        let formdata = new Formdata();
        req.assert('Email', 'Lütfen , E-posta adresini giriniz.').notEmpty();
        req.assert('Facebook', 'Lütfen , E-posta adresini giriniz.').notEmpty();
        req.assert('Fullname', 'Lütfen , E-posta adresini giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;

            let user = new UserModel();
            user.Email = document.Email;
            user.Firstname = document.Firstname;
            user.Lastname = document.Lastname;
            user.Fullname = document.Fullname;
            user.PhotoPath = document.PhotoPath;
            user.Facebook = document.Facebook;
            user.IsActive = true;
            userDataAccess.getByEmail(user.Email, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    if (result == null) {
                        userDataAccess.getByFacebookId(user.Facebook, function (response, result) {
                            if (response) {
                                formdata.Errors = response.message;
                                formdata.IsSuccess = false;
                                res.json(formdata);
                            } else {
                                if (result && result.id) {
                                    user.DocumentId = result.id;
                                    //#region getByEmail.
                                    userDataAccess.getById(result.id, function (response, result) {
                                        if (response) {
                                            formdata.Errors = response.message;
                                            formdata.IsSuccess = false;
                                            res.json(formdata);
                                        }
                                        else {
                                            let downloadAvatar = false;
                                            if (result) {
                                                let record = result;
                                                user.IsActive = true;
                                                user.Username = record.Username;
                                                user.AuraCount = record.AuraCount;
                                                user.Followers = record.Followers;
                                                user.Following = record.Following;
                                                if (record.ShortBiography)
                                                    user.ShortBiography = record.ShortBiography;

                                                if (record.PhotoPath) {
                                                    user.PhotoPath = record.PhotoPath;
                                                } else {
                                                    if (user.PhotoPath) {
                                                        downloadAvatar = true;
                                                    }
                                                }
                                            } else {
                                                downloadAvatar = true;
                                            }

                                            if (downloadAvatar) {
                                                let photoPath = ApplicationContext.toRemoveSpecialChar(user.Email) + ".jpeg";
                                                AWSImageManager.downloadAndUploadAWS(user.PhotoPath, photoPath, function (response, result) {
                                                    if (response) {
                                                        user.IsActive = true;
                                                        formdata.Errors = response.message;
                                                        formdata.IsSuccess = false;
                                                        res.json(formdata);
                                                    }
                                                    else {
                                                        user.PhotoPath = photoPath;
                                                        //#region save.
                                                        userDataAccess.save(user, function (response, result) {
                                                            if (response) {
                                                                formdata.Errors = response.message;
                                                                formdata.IsSuccess = false;
                                                                res.json(formdata);
                                                            } else {
                                                                let auraDataAccess = new AuraDataAccess();
                                                                auraDataAccess.activeWithOwnerId(user.DocumentId, function (response, result) {
                                                                });
                                                                result.IsNewUser = false;
                                                                formdata.Data = stringify(result, null, 2, {offset: 4});
                                                                formdata.IsSuccess = true;
                                                                res.json(formdata);
                                                            }
                                                        });
                                                        //#endregion save.
                                                    }
                                                });
                                            } else {
                                                //#region save.
                                                userDataAccess.save(user, function (response, result) {
                                                    if (response) {
                                                        formdata.Errors = response.message;
                                                        formdata.IsSuccess = false;
                                                        res.json(formdata);
                                                    } else {
                                                        let auraDataAccess = new AuraDataAccess();
                                                        auraDataAccess.activeWithOwnerId(user.DocumentId, function (response, result) {
                                                        });
                                                        result.IsNewUser = false;
                                                        formdata.Data = stringify(result, null, 2, {offset: 4});
                                                        formdata.IsSuccess = true;
                                                        res.json(formdata);
                                                    }
                                                });
                                                //#endregion save.
                                            }

                                        }
                                    });
                                    //#endregion getByEmail.
                                }
                                else {
                                    let photoPath = ApplicationContext.toRemoveSpecialChar(user.Email) + ".jpeg";
                                    AWSImageManager.downloadAndUploadAWS(user.PhotoPath, photoPath, function (response, result) {
                                        if (response) {
                                            user.IsActive = true;
                                            formdata.Errors = response.message;
                                            formdata.IsSuccess = false;
                                            res.json(formdata);
                                        }
                                        else {
                                            user.PhotoPath = photoPath;
                                            //#region save.
                                            userDataAccess.save(user, function (response, result) {
                                                if (response) {
                                                    formdata.Errors = response.message;
                                                    formdata.IsSuccess = false;
                                                    res.json(formdata);
                                                } else {
                                                    result.IsNewUser = true;
                                                    formdata.Data = stringify(result, null, 2, {offset: 4});
                                                    formdata.IsSuccess = true;
                                                    res.json(formdata);
                                                }
                                            });
                                            //#endregion save.
                                        }
                                    });
                                }
                            }
                        });
                    } else {
                        result.Facebook = user.Facebook;
                        result.IsActive = true;
                        //#region save.
                        userDataAccess.save(result, function (response, result) {
                            if (response) {
                                formdata.Errors = response.message;
                                formdata.IsSuccess = false;
                                res.json(formdata);
                            } else {
                                result.IsNewUser = false;
                                formdata.Data = stringify(result, null, 2, {offset: 4});
                                formdata.IsSuccess = true;
                                res.json(formdata);
                            }
                        });
                        //#endregion save.
                    }
                }
            });
        }
    }

    static loginByGoogle(req, res, next) {
        let formdata = new Formdata();
        req.assert('Email', 'Lütfen , E-posta adresini giriniz.').notEmpty();
        req.assert('Google', 'Lütfen , E-posta adresini giriniz.').notEmpty();
        req.assert('Fullname', 'Lütfen , E-posta adresini giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;

            let user = new UserModel();
            user.Email = document.Email;
            user.Firstname = document.Firstname;
            user.Lastname = document.Lastname;
            user.Fullname = document.Fullname;
            user.PhotoPath = document.PhotoPath;
            user.Google = document.Google;
            user.IsActive = true;
            userDataAccess.getByEmail(user.Email, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    if (result == null) {
                        userDataAccess.getByGoogleId(user.Google, function (response, result) {
                            if (response) {
                                formdata.Errors = response.message;
                                formdata.IsSuccess = false;
                                res.json(formdata);
                            } else {
                                if (result && result.id) {
                                    user.DocumentId = result.id;
                                    //#region getByEmail.
                                    userDataAccess.getById(result.id, function (response, result) {
                                        if (response) {
                                            formdata.Errors = response.message;
                                            formdata.IsSuccess = false;
                                            res.json(formdata);
                                        }
                                        else {
                                            let downloadAvatar = false;
                                            if (result) {
                                                let record = result;
                                                user.IsActive = true;
                                                user.Username = record.Username;
                                                user.AuraCount = record.AuraCount;
                                                user.Followers = record.Followers;
                                                user.Following = record.Following;
                                                if (record.ShortBiography)
                                                    user.ShortBiography = record.ShortBiography;

                                                if (record.PhotoPath) {
                                                    user.PhotoPath = record.PhotoPath;
                                                } else {
                                                    if (user.PhotoPath) {
                                                        downloadAvatar = true;
                                                    }
                                                }
                                            } else {
                                                downloadAvatar = true;
                                            }

                                            if (downloadAvatar) {
                                                let photoPath = ApplicationContext.toRemoveSpecialChar(user.Email) + ".jpeg";
                                                AWSImageManager.downloadAndUploadAWS(user.PhotoPath, photoPath, function (response, result) {
                                                    if (response) {
                                                        user.IsActive = true;
                                                        formdata.Errors = response.message;
                                                        formdata.IsSuccess = false;
                                                        res.json(formdata);
                                                    }
                                                    else {
                                                        user.PhotoPath = result.Key;
                                                        //#region save.
                                                        userDataAccess.save(user, function (response, result) {
                                                            if (response) {
                                                                formdata.Errors = response.message;
                                                                formdata.IsSuccess = false;
                                                                res.json(formdata);
                                                            } else {
                                                                let auraDataAccess = new AuraDataAccess();
                                                                auraDataAccess.activeWithOwnerId(user.DocumentId, function (response, result) {
                                                                });
                                                                result.IsNewUser = false;
                                                                formdata.Data = stringify(result, null, 2, {offset: 4});
                                                                formdata.IsSuccess = true;
                                                                res.json(formdata);
                                                            }
                                                        });
                                                        //#endregion save.
                                                    }
                                                });
                                            } else {
                                                //#region save.
                                                userDataAccess.save(user, function (response, result) {
                                                    if (response) {
                                                        formdata.Errors = response.message;
                                                        formdata.IsSuccess = false;
                                                        res.json(formdata);
                                                    } else {
                                                        let auraDataAccess = new AuraDataAccess();
                                                        auraDataAccess.activeWithOwnerId(user.DocumentId, function (response, result) {
                                                        });
                                                        result.IsNewUser = false;
                                                        formdata.Data = stringify(result, null, 2, {offset: 4});
                                                        formdata.IsSuccess = true;
                                                        res.json(formdata);
                                                    }
                                                });
                                                //#endregion save.
                                            }

                                        }
                                    });
                                    //#endregion getByEmail.
                                }
                                else {
                                    let photoPath = ApplicationContext.toRemoveSpecialChar(user.Email) + ".jpeg";
                                    AWSImageManager.downloadAndUploadAWS(user.PhotoPath, photoPath, function (response, result) {
                                        if (response) {
                                            user.IsActive = true;
                                            formdata.Errors = response.message;
                                            formdata.IsSuccess = false;
                                            res.json(formdata);
                                        }
                                        else {
                                            user.PhotoPath = result.Key;
                                            //#region save.
                                            userDataAccess.save(user, function (response, result) {
                                                if (response) {
                                                    formdata.Errors = response.message;
                                                    formdata.IsSuccess = false;
                                                    res.json(formdata);
                                                } else {
                                                    result.IsNewUser = true;
                                                    formdata.Data = stringify(result, null, 2, {offset: 4});
                                                    formdata.IsSuccess = true;
                                                    res.json(formdata);
                                                }
                                            });
                                            //#endregion save.
                                        }
                                    });
                                }
                            }
                        });
                    } else {
                        result.Google = user.Google;
                        result.IsActive = true;
                        //#region save.
                        userDataAccess.save(result, function (response, result) {
                            if (response) {
                                formdata.Errors = response.message;
                                formdata.IsSuccess = false;
                                res.json(formdata);
                            } else {
                                result.IsNewUser = false;
                                formdata.Data = stringify(result, null, 2, {offset: 4});
                                formdata.IsSuccess = true;
                                res.json(formdata);
                            }
                        });
                        //#endregion save.
                    }
                }
            });
        }
    }

    static checkUsername(req, res, next) {
        let formdata = new Formdata();
        req.assert('DocumentId', 'Lütfen , E-posta adresini giriniz.').notEmpty();
        req.assert('Username', 'Lütfen , E-posta adresini giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;

            let user = new UserModel();
            user.DocumentId = document.DocumentId;
            user.Username = document.Username;

            if (ApplicationContext.checkUsernameOnlyLatinChars(user.Username)) {
                //#region getByUsername. 
                userDataAccess.getByUsername(user.Username, function (response, result) {
                    if (response) {
                        formdata.Errors = response.message;
                        formdata.IsSuccess = false;
                        res.json(formdata);
                    } else {
                        if (result) {
                            formdata.ErrorCode = '1000';
                            formdata.Errors = 'Sorry, this username is already taken :(';
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        } else {
                            userDataAccess.updateUsernameById(user.DocumentId, user.Username, function (response, result) {
                                if (response) {
                                    formdata.Errors = response.message;
                                    formdata.IsSuccess = false;
                                    res.json(formdata);
                                } else {
                                    formdata.IsSuccess = true;
                                    res.json(formdata);
                                }
                            });
                        }
                    }
                });
                //#endregion getByUsername. 
            }
            else {
                formdata.ErrorCode = '1001';
                formdata.Errors = 'Sorry, this username contains different char :(';
                formdata.IsSuccess = false;
                res.json(formdata);
            }
        }
    }

    static followUserById(req, res, next) {
        let formdata = new Formdata();
        req.assert('UserId', 'Lütfen , UserId giriniz.').notEmpty();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            let settingsDataAccess = new SettingsDataAccess();
            let notificationDataAccess = new NotificationDataAccess();
            let deviceDataAccess = new DeviceDataAccess();
            let currentUser = req.user;
            const document = req.body;


            let key = currentUser.DocumentId + '::' + document.UserId;

            settingsDataAccess.getById(process.env.SETTINGS_PARAMS_NOTIFICATIONS_NEW_FOLLOW_MESSSAGE, function (response, setting) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {

                    let doc = new UserFriendModel();
                    doc.DocumentId = key;
                    doc.OwnerDocumentId = currentUser.DocumentId;
                    doc.OwnerFullname = currentUser.Fullname;
                    doc.OwnerUsername = currentUser.Username;
                    doc.OwnerPhotoPath = currentUser.PhotoPath;
                    doc.FriendDocumentId = document.DocumentId;

                    let notificationModel = new NotificationModel();
                    notificationModel.OwnerId = document.UserId;
                    notificationModel.DocumentId = "f::" + key;
                    notificationModel.NotificationType = NotificationType.NewFollow;
                    notificationModel.Message = format(setting.Value, currentUser.Username);
                    notificationModel.Data = doc;
                    notificationModel.UserFriendId = currentUser.DocumentId;
                    notificationDataAccess.save(notificationModel, function (response, notification) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        }
                        else {

                            deviceDataAccess.getByOwnerId(currentUser.DocumentId, document.UserId, NotificationType.NewFollow, function (response, devices) {
                                if (response) {
                                    formdata.Errors = response.message;
                                    formdata.IsSuccess = false;
                                    res.json(formdata);
                                }
                                else {
                                    userDataAccess.followUserById(currentUser, document.UserId, function (response, result) {
                                        if (response) {
                                            formdata.Errors = response.message;
                                            formdata.IsSuccess = false;
                                            res.json(formdata);
                                        } else {
                                            formdata.IsSuccess = true;
                                            devices.forEach(function (device) {
                                                let data = {
                                                    DocumentId: key,
                                                    Owner: currentUser.DocumentId,
                                                    OwnerPhotoPath: currentUser.PhotoPath,
                                                    Fullname: currentUser.Fullname,
                                                    Username: currentUser.Username,
                                                    FriendDocumentId: document.UserId,
                                                    NotificationType: NotificationType.NewFollow.toString()
                                                };
                                                let message = {
                                                    android: {
                                                        priority: 'normal',
                                                        notification: {
                                                            title: '',
                                                            body: notificationModel.Message,
                                                            sound: "default"
                                                        },
                                                        data: data
                                                    },
                                                    apns: {
                                                        payload: {
                                                            aps: {
                                                                alert: {
                                                                    title: '',
                                                                    body: notificationModel.Message,
                                                                    sound: "default"
                                                                }
                                                            },
                                                            data: data
                                                        },
                                                    },
                                                    token: device.Token
                                                };

                                                Application.notification.manager.send(message);
                                            });
                                            res.json(formdata);
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
    }

    static unfollowUserById(req, res, next) {
        let formdata = new Formdata();
        req.assert('UserId', 'Lütfen , UserId giriniz.').notEmpty();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            let notificationDataAccess = new NotificationDataAccess();
            let currentUser = req.user;
            const document = req.body;
            let key = currentUser.DocumentId + '::' + document.UserId;
            userDataAccess.unfollowUserById(currentUser.DocumentId, document.UserId, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    notificationDataAccess.delete("f::" + key, function (response, notification) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        }
                        else {
                            result.IsNewUser = false;
                            formdata.Data = stringify(result, null, 2, {offset: 4});
                            formdata.IsSuccess = true;
                            res.json(formdata);
                        }
                    });
                }
            });
        }
    }

    ///
    // @deprecated
    ///
    static followUserWithFacebookId(req, res, next) {
        let formdata = new Formdata();
        req.assert('DocumentId', 'Lütfen , E-posta adresini giriniz.').notEmpty();
        req.assert('Friends', 'Lütfen , E-posta adresini giriniz.').notEmpty();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;

            let user = new UserModel();
            user.DocumentId = document.DocumentId;
            let currentUser = req.user;
            let friends = document.Friends;
            userDataAccess.addFriendsById(currentUser, friends, 'facebook', function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static followUserWithFacebookIdNew(req, res, next) {
        let formdata = new Formdata();
        req.assert('DocumentId', 'Lütfen , DocumentId bilgisini giriniz.').notEmpty();
        //req.assert('Friends', 'Lütfen , Friends bilgisini giriniz.').notEmpty();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;

            let user = new UserModel();
            user.DocumentId = document.DocumentId;
            let currentUser = req.user;
            let friends = document.Friends;
            if (friends) {
                let followingFriends = friends.map(
                    friend => {
                        if (friend.IsSelected === true) {
                            return friend.FriendId;
                        }
                    }
                );

                friends = friends.map(
                    friend => {
                        return friend.FriendId;
                    }
                );
                userDataAccess.informById(currentUser, friends, 'facebook', function (response, result) {
                    if (response) {
                        formdata.Errors = response.message;
                        formdata.IsSuccess = false;
                        res.json(formdata);
                    } else {
                        userDataAccess.addFriendsById(currentUser, followingFriends, 'facebook', function (response, result) {
                            if (response) {
                                formdata.Errors = response.message;
                                formdata.IsSuccess = false;
                                res.json(formdata);
                            } else {
                                formdata.IsSuccess = true;
                                res.json(formdata);
                            }
                        });
                    }
                });
            }
            else {
                formdata.IsSuccess = true;
                res.json(formdata);
            }
        }
    }

    static followUserWithGoogleId(req, res, next) {
        let formdata = new Formdata();
        req.assert('DocumentId', 'Lütfen , E-posta adresini giriniz.').notEmpty();
        req.assert('Friends', 'Lütfen , E-posta adresini giriniz.').notEmpty();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;

            let user = new UserModel();
            user.DocumentId = document.DocumentId;
            let friends = document.Friends;
            userDataAccess.addFriendsById(user.DocumentId, friends, 'google', function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static updateMetadata(req, res, next) {
        let formdata = new Formdata();
        req.assert('DocumentId', 'Lütfen , E-posta adresini giriniz.').notEmpty();
        req.assert('Fullname', 'Lütfen , E-posta adresini giriniz.').notEmpty();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;

            let user = new UserModel();
            user.DocumentId = document.DocumentId;
            user.Fullname = document.Fullname;
            user.ShortBiography = document.ShortBiography;

            userDataAccess.updateMetadataById(user.DocumentId, user.Fullname, user.ShortBiography, '', function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static uploadAvatar(req, res, next) {
        let formdata = new Formdata();

        var form = new multiparty.Form();
        form.parse(req, function (err, fields, files) {
            let documentId = fields.DocumentId ? fields.DocumentId[0] : undefined;
            if (!documentId) {
                formdata.Errors = 'Lütfen , DocumentId giriniz.';
                formdata.IsSuccess = false;
                res.json(formdata);
            }
            else {
                let userDataAccess = new UserDataAccess();
                const document = req.body;

                let user = new UserModel();
                user.DocumentId = documentId;

                userDataAccess.getById(user.DocumentId, function (response, result) {
                    if (response) {
                        formdata.Errors = response.message;
                        formdata.IsSuccess = false;
                        res.json(formdata);
                    } else {
                        let photoPath = result.PhotoPath;
                        AWSImageManager.uploadAWS(files, photoPath, function (response, result) {
                            if (response) {
                                user.IsActive = true;
                                formdata.Errors = response.message;
                                formdata.IsSuccess = false;
                                res.json(formdata);
                            }
                            else {
                                user.PhotoPath = result.Key;
                                formdata.IsSuccess = true;
                                res.json(formdata);
                            }
                        });
                    }
                });
            }
        });
    }

    static getStatistics(req, res, next) {
        let formdata = new Formdata();
        req.assert('DocumentId', 'Lütfen ,DocumentId giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            let userSettingsDataAccess = new UserSettingsDataAccess();
            let settingsDataAccess = new SettingsDataAccess();
            const document = req.body;
            let currentUser = req.user;
            userDataAccess.getById(document.DocumentId, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    userDataAccess.isFollowedUserById(currentUser.DocumentId, document.DocumentId, function (response, isFollowed) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        } else {
                            if (isFollowed && isFollowed.length > 0) {
                                result.IsFollowUser = true;
                            } else {
                                result.IsFollowUser = false;
                            }
                            //ben bu adamı blokladım mı ?
                            userSettingsDataAccess.checkBlocked(currentUser.DocumentId, document.DocumentId, function (response, isBlocked) {
                                if (response) {
                                    formdata.Errors = response.message;
                                    formdata.IsSuccess = false;
                                    res.json(formdata);
                                } else {
                                    if (isBlocked && isBlocked.length > 0) {
                                        result.IsBlocked = true;
                                    } else {
                                        result.IsBlocked = false;
                                    }
                                    let key = 'ms::' + currentUser.DocumentId + '::' + document.DocumentId;
                                    settingsDataAccess.getById(key, function (response, settings) {
                                        if (response && response.code != 13) {
                                            formdata.Errors = response.message;
                                            formdata.IsSuccess = false;
                                            res.json(formdata);
                                        }
                                        else {
                                            if (settings) {
                                                result.IsMute = true;
                                            } else {
                                                result.IsMute = false;
                                            }
                                            formdata.Data = stringify(result, null, 2, {offset: 4});
                                            formdata.IsSuccess = true;
                                            res.json(formdata);
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
    }

    ///
    // Kullanıcıyı follow edenlerleri getirir.
    ///
    static getUserFollowers(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  PageIndex giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;
            let currentUser = req.user;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            userDataAccess.getUserFollowers(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    ///
    //  Kullanıcıyı follow edenlerleri getirir.
    ///
    static getUserFollowersWithUserId(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  PageIndex giriniz.').notEmpty().isInt();
        req.assert('UserId', 'Lütfen  UserId giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;
            let currentUser = req.user;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            filter.User = document.UserId;
            userDataAccess.getUserFollowers(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    ///
    //   Kullanıcının follow ettiklerini getirir.
    ///
    static getUserFollowings(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  PageIndex giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;
            let currentUser = req.user;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            userDataAccess.getUserFollowings(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    ///
    //   Kullanıcının follow ettiklerini getirir.
    ///
    static getUserFollowingsWithUserId(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  PageIndex giriniz.').notEmpty().isInt();
        req.assert('UserId', 'Lütfen  UserId giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;
            let currentUser = req.user;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            filter.User = document.UserId;
            userDataAccess.getUserFollowings(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static deactive(req, res, next) {
        let formdata = new Formdata();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            let notificationDataAccess = new NotificationDataAccess();

            let currentUser = req.user;
            userDataAccess.deactive(currentUser.DocumentId, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    let auraDataAccess = new AuraDataAccess();
                    auraDataAccess.deactiveWithOwnerId(currentUser.DocumentId, function (response, result) {
                    });
                    notificationDataAccess.deleteByOwnerId(currentUser.DocumentId, function (response, result) {
                    });
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static blockUser(req, res, next) {
        let formdata = new Formdata();
        req.assert('FriendDocumentId', 'Lütfen  FriendDocumentId giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userSettingsDataAccess = new UserSettingsDataAccess();
            let userDataAccess = new UserDataAccess();
            let blockedUserModel = new BlockedUserModel();
            let notificationDataAccess = new NotificationDataAccess();
            let currentUser = req.user;
            const document = req.body;

            blockedUserModel.DocumentId = currentUser.DocumentId + "::" + document.FriendDocumentId;
            blockedUserModel.OwnerId = currentUser.DocumentId;
            blockedUserModel.BlockedUserId = document.FriendDocumentId;

            userDataAccess.getById(document.FriendDocumentId, function (response, friend) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    blockedUserModel.BlockedUserPhotoPath = friend.PhotoPath;
                    blockedUserModel.BlockedFullname = friend.Fullname;
                    blockedUserModel.BlockedUsername = friend.Username;
                    userSettingsDataAccess.save(blockedUserModel, function (response, result) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        } else {
                            let promises = Array();
                            let unfollowCurrentUserPromise = new Promise(function (resolve, reject) {
                                userDataAccess.unfollowUserById(currentUser.DocumentId, document.FriendDocumentId, function (response, result) {
                                    if (response) {
                                        reject(response);
                                    } else {
                                        resolve();
                                    }
                                });
                            });
                            promises.push(unfollowCurrentUserPromise);

                            let unfollowCurrentUserNotificationPromise = new Promise(function (resolve, reject) {
                                notificationDataAccess.deleteByOwnerIdAndFirendId(currentUser.DocumentId, document.FriendDocumentId, function (response, notification) {
                                    if (response) {
                                        reject(response);
                                    }
                                    else {
                                        resolve();
                                    }
                                });
                            });
                            promises.push(unfollowCurrentUserNotificationPromise);

                            let unfollowFriendPromise = new Promise(function (resolve, reject) {
                                userDataAccess.unfollowUserById(document.FriendDocumentId, currentUser.DocumentId, function (response, result) {
                                    if (response) {
                                        reject(response);
                                    } else {
                                        resolve();
                                    }
                                });
                            });
                            promises.push(unfollowFriendPromise);

                            let unfollowFriendNotificationPromise = new Promise(function (resolve, reject) {
                                notificationDataAccess.deleteByOwnerIdAndFirendId(document.FriendDocumentId, currentUser.DocumentId, function (response, notification) {
                                    if (response) {
                                        reject(response);
                                    } else {
                                        resolve();
                                    }
                                });
                            });
                            promises.push(unfollowFriendNotificationPromise);


                            Promise.all(promises).then(function () {
                                formdata.IsSuccess = true;
                                res.json(formdata);
                            }).catch(function (err) {
                                formdata.IsSuccess = false;
                                res.json(formdata);
                            });
                        }
                    });
                }
            });
        }
    }

    static unblockUser(req, res, next) {
        let formdata = new Formdata();
        req.assert('FriendDocumentId', 'Lütfen  FriendDocumentId giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userSettingsDataAccess = new UserSettingsDataAccess();
            let userDataAccess = new UserDataAccess();
            let blockedUserModel = new BlockedUserModel();
            let currentUser = req.user;
            const document = req.body;

            blockedUserModel.DocumentId = currentUser.DocumentId + "::" + document.FriendDocumentId;
            userSettingsDataAccess.delete(blockedUserModel.DocumentId, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static starVenue(req, res, next) {
        let formdata = new Formdata();
        req.assert('VenueId', 'Lütfen , VenueId giriniz.').notEmpty();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            let settingsDataAccess = new SettingsDataAccess();
            let notificationDataAccess = new NotificationDataAccess();
            let deviceDataAccess = new DeviceDataAccess();
            let currentUser = req.user;
            const document = req.body;


            let key = currentUser.DocumentId + '::' + document.VenueId;
            userDataAccess.getById(document.VenueId, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    let doc = new UserFriendModel();
                    doc.FriendFullname = result.Title;
                    doc.DocumentId = key;
                    doc.OwnerDocumentId = currentUser.DocumentId;
                    doc.OwnerFullname = currentUser.Fullname;
                    doc.OwnerUsername = currentUser.Username;
                    doc.OwnerPhotoPath = currentUser.PhotoPath;
                    doc.FriendDocumentId = document.VenueId;
                    doc.Type = 'starVenue';

                    userDataAccess.saveFriend(doc, function (response, result) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        } else {
                            userDataAccess.changeVenueFollowers(document.VenueId, function (response, result) {
                                if (response) {
                                    formdata.Errors = response.message;
                                    formdata.IsSuccess = false;
                                    res.json(formdata);
                                } else {
                                    userDataAccess.calculateFollowingCount(doc.OwnerDocumentId, function (response, result) {
                                        if (response) {
                                            formdata.Errors = response.message;
                                            formdata.IsSuccess = false;
                                            res.json(formdata);
                                        } else {
                                            formdata.IsSuccess = true;
                                            res.json(formdata);
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
    }

    static unstarVenue(req, res, next) {
        let formdata = new Formdata();
        req.assert('VenueId', 'Lütfen , VenueId giriniz.').notEmpty();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            let notificationDataAccess = new NotificationDataAccess();
            let currentUser = req.user;
            const document = req.body;
            let key = currentUser.DocumentId + '::' + document.VenueId;
            userDataAccess.removeFriendsById(key, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    userDataAccess.changeVenueFollowers(document.VenueId, function (response, result) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        } else {
                            userDataAccess.calculateFollowingCount(currentUser.DocumentId, function (response, result) {
                                if (response) {
                                    formdata.Errors = response.message;
                                    formdata.IsSuccess = false;
                                    res.json(formdata);
                                } else {
                                    formdata.IsSuccess = true;
                                    res.json(formdata);
                                }
                            });
                        }
                    });
                }
            });
        }
    }

    static getVenuePaged(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  PageIndex giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let auraDataAccess = new AuraDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            auraDataAccess.getStarVenuePaged(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }


    static getPagedBlockUser(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  PageIndex giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let currentUser = req.user;
            let userDataAccess = new UserDataAccess();
            let userSettingsDataAccess = new UserSettingsDataAccess();
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            userSettingsDataAccess.getPagedBlockUser(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }
}

module.exports = AccountApiController;

//https://awspilot.github.io/dynamodb-oop/