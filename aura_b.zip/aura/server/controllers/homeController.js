'use strict';
const aws = require('aws-sdk');
const crypto = require('crypto');
const deferred = require('deferred');
const stringify = require('json-stringify');
const Busboy = require('busboy');
const Formdata = require('../core/formdata');
const ApplicationContext = require('../core/applicationContext');
const UserModel = require('../models/usermodel');
const UserDataAccess = require('../dataaccess/user');
const Application = require("../../app");
const AuraApiController = require('./auraApiController');
const AuraDataAccess = require('../dataaccess/aura');
const AuraType = require('../models/auratype');

class HomeController {
    static heartbeat(req, res, next) {
        res.sendStatus(200);
    }

    static index(req, res, next) {
        res.render('home/index', {csrfToken: req.csrfToken()});
    }

    static login(req, res, next) {
        res.render('home/login', {csrfToken: req.csrfToken()});
    }

    static dashboard(req, res, next) {
        res.render('home/dashboard', {csrfToken: req.csrfToken()});
    }

    static share(req, res, next) {
        let formdata = new Formdata();
        const documentId = req.query.DocumentId;
        let auraDataAccess = new AuraDataAccess();
        res.render('home/share', {documentId: documentId});
    }

    static privacypolicy(req, res, next) {
        res.render('home/privacypolicy');
    }

    static loginProcess(req, res, next) {
        let formdata = new Formdata();
        req.assert('email', 'Lütfen , E-posta adresini giriniz.').isEmail();
        req.assert('password', 'Lütfen , Şifrenizi giriniz.').notEmpty();
        req.sanitize('email').normalizeEmail({remove_dots: false});
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;
            userDataAccess.getByEmail(document.email, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    if (ApplicationContext.validPassword(result.Password, document.password)) {
                        ApplicationContext.setUserInSession(req, result);
                        formdata.IsSuccess = true;
                        formdata.IsRedirect = true;
                        formdata.Url = '/admin/dashboard';
                        if (req.body.rememberMe == "true") {
                            req.session.cookie.maxAge = 30 * 24 * 60 * 60 * 1000; // Cookie expires after 30 days
                        } else {
                            req.session.cookie.expires = false; // Cookie expires at end of session
                        }
                        formdata.IsSuccess = true;
                        res.json(formdata);
                    } else {
                        formdata.Errors = 'Kullanıcı adı ve şifrenizi kontrol ediniz.';
                        formdata.IsSuccess = false;
                        res.json(formdata);
                    }
                }
            });
        }
    }

    static searchVenue(req, res, next) {
        let formdata = new Formdata();
        req.assert('lat', 'Lütfen , lat giriniz.').notEmpty();
        req.assert('lng', 'Lütfen , lng giriniz.').notEmpty();
        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            res.json(formdata);
        }
        else {
            let userDataAccess = new UserDataAccess();
            const document = req.body;
            const location = document.lat + ',' + document.lng;
            Application.foursquare.venues.search({ll: location, radius: 20}, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = result.response.venues;
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static publish(req, res, next) {
        let formdata = new Formdata();
        const document = req.body;
        const userId = document.UserId;
        let userDataAccess = new UserDataAccess();
        userDataAccess.getById(userId, function (response, result) {
            if (response) {
                formdata.Errors = response.message;
                formdata.IsSuccess = false;
                res.json(formdata);
            }
            else {
                req.user = result;
                req.body.BaseType = parseFloat(document.BaseType);
                req.body.ShareType = parseFloat(document.ShareType);
                req.body.Latitude = parseFloat(document.Latitude);
                req.body.Longitude = parseFloat(document.Longitude);
                AuraApiController.publish(req, res, next);
            }
        });
    }
}

module.exports = HomeController;
