'use strict';
const stringify = require('json-stringify');
const Formdata = require('../core/formdata');
const Application = require("../../app");
const ApplicationContext = require('../core/applicationContext');
const NotificationDataAccess = require('../dataaccess/notification');
const PagedFilter = require('../models/pagedFilter');
const DeviceDataAccess = require('../dataaccess/device');
const DeviceModel = require('../models/devicemodel');
const DeviceType = require('../models/devicetype');
const NotificationType = require('../models/notificationType');
const datan = require('../models/data');

class NotificationController {
    static getPaged(req, res, next) {
        let formdata = new Formdata();
        req.assert('PageIndex', 'Lütfen  PageIndex giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let notificationDataAccess = new NotificationDataAccess();
            let currentUser = req.user;
            const document = req.body;
            let filter = PagedFilter.load(document, currentUser.DocumentId);
            notificationDataAccess.getPaged(filter, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, {offset: 4});
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });

        }
    }

    static send(req, res, next) {
        let formdata = new Formdata();
        req.assert('FriendId', 'Lütfen FriendId giriniz.').notEmpty();
        req.assert('Message', 'Lütfen Message giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let deviceDataAccess = new DeviceDataAccess();
            const document = req.body;
            let currentUser = req.user;
            let friendId = document.FriendId;
            let messageContent = document.Message;
            let extra = document.Data == undefined ? '' : document.Data;
            deviceDataAccess.getByOwnerId(currentUser.DocumentId, friendId, NotificationType.ChatMessage, function (response, devices) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    if (devices.length !== 0) {
                        devices.forEach(function (device) {
                            let data = {
                                Extra: extra,
                                NotificationType: NotificationType.ChatMessage.toString()
                            };
                            let message = {
                                android: {
                                    priority: 'normal',
                                    notification: {
                                        title: '',
                                        body: messageContent,
                                        sound: "default"
                                    },
                                    data: data
                                },
                                apns: {
                                    payload: {
                                        aps: {
                                            alert: {
                                                title: '',
                                                body: messageContent,
                                                sound: "default"
                                            }
                                        },
                                        data: data
                                    },
                                },
                                token: device.Token
                            };

                            Application.notification.manager.send(message);
                        });
                    }
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
        }
    }

    static sendAllUser(req, res, next) {
        let formdata = new Formdata();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let deviceDataAccess = new DeviceDataAccess();
            const document = req.body;
            let messageContent = "Saturday night fever is on🔥Show and see what’s going on.";

            if (datan.length !== 0) {
                datan.forEach(function (device) {
                    let data = {
                        NotificationType: NotificationType.ChatMessage.toString()
                    };
                    let message = {
                        android: {
                            priority: 'normal',
                            notification: {
                                title: '',
                                body: messageContent,
                                sound: "default"
                            },
                            data: data
                        },
                        apns: {
                            payload: {
                                aps: {
                                    alert: {
                                        title: '',
                                        body: messageContent,
                                        sound: "default"
                                    }
                                },
                                data: data
                            },
                        },
                        token: device.Token
                    };

                    Application.notification.manager.send(message);
                });
            }
            formdata.IsSuccess = true;
            res.json(formdata);
           /* deviceDataAccess.getByAll(function (response, devices) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    if (devices.length !== 0) {
                        devices.forEach(function (device) {
                            let data = {
                                NotificationType: NotificationType.ChatMessage.toString()
                            };
                            let message = {
                                android: {
                                    priority: 'normal',
                                    notification: {
                                        title: '',
                                        body: messageContent,
                                        sound: "default"
                                    },
                                    data: data
                                },
                                apns: {
                                    payload: {
                                        aps: {
                                            alert: {
                                                title: '',
                                                body: messageContent,
                                                sound: "default"
                                            }
                                        },
                                        data: data
                                    },
                                },
                                token: device.Token
                            };

                            Application.notification.manager.send(message);
                        });
                    }
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });
            */
        }
    }
}

module.exports = NotificationController;
