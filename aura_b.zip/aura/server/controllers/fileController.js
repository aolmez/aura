'use strict';
const aws = require('aws-sdk');
const pluploader = require('express-plupload');
const stringify = require('json-stringify');
const ejs = require('ejs');
const fs = require('fs');
const path = require('path');
const mime = require('mime');
const Application = require("../../app");
const Formdata = require('../core/formdata');
const FileStorage = require('../core/fileStorage');

class FileController {

    static uploader(req, res, next) {
        let formdata = new Formdata();
        aws.config.update({
            accessKeyId: process.env.AWS_SECRET_KEY,
            secretAccessKey: process.env.AWS_SECRET_ACCESSKEY
        });
        const s3 = new aws.S3({
            params: {
                Bucket: process.env.AWS_TEMP_BUCKET,
                region: process.env.AWS_REGION
            }
        });

        if (!req.plupload.isNew) {
            const ext = FileController.getExtension(req.plupload.fields.name);
            let extra = {
                filename: req.plupload.fields.name,
                mimetype: mime.getType(ext)
            };
            const filename = extra.filename;
            formdata.Data = filename;
            formdata.ExtraData = extra;
            formdata.IsSuccess = true;
            res.send(stringify(formdata, null, 2, {offset: 4}));
            return;
        }
        const ext = FileController.getExtension(req.plupload.fields.name);
        let extra = {
            filename: req.plupload.fields.name,
            mimetype: mime.getType(ext)
        };

        const tempDirectory = FileStorage.getTempDirectory();
        const filename = extra.filename;
        const fileFullTempPath = path.join(tempDirectory, filename);

        var writeStream = fs.createWriteStream(fileFullTempPath, {
            start: req.plupload.completedOffset
        });

        writeStream.on('finish', function () {
            fs.readFile(fileFullTempPath, function (err, data) {
                if (err) {
                    formdata.Errors = err;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }

                let contentType = extra.mimetype;
                let contentLength = data.length;
                const base64data = new Buffer(data, 'binary');
                s3.upload({
                    Key: filename,
                    Body: base64data,
                    ContentType: contentType,
                    ContentLength: contentLength,
                    ACL: 'public-read'
                }, function (response) {
                    fs.unlink(fileFullTempPath, function (err) {
                        if (err) {
                        }
                    });

                    if (response) {
                        formdata.Errors = response;
                        formdata.IsSuccess = false;
                        res.send(stringify(formdata, null, 2, {offset: 4}));
                    } else {
                        formdata.Data = filename;
                        formdata.ExtraData = extra;
                        formdata.IsSuccess = true;
                        res.send(stringify(formdata, null, 2, {offset: 4}));
                    }
                });
            });
        });
        req.plupload.stream.pipe(writeStream);
    }

    static uploadTemp(req, res, next) {
        let formdata = new Formdata();

        if (!req.plupload.isNew) {
            const ext = FileController.getExtension(req.plupload.fields.name);
            let extra = {
                filename: req.plupload.fields.name,
                mimetype: mime.getType(ext)
            };
            const filename = extra.filename;
            formdata.Data = filename;
            formdata.ExtraData = extra;
            formdata.IsSuccess = true;
            res.send(stringify(formdata, null, 2, {offset: 4}));
            return;
        }
        const ext = FileController.getExtension(req.plupload.fields.name);
        let extra = {
            filename: req.plupload.fields.name,
            mimetype: mime.getType(ext)
        };

        const tempDirectory = FileStorage.getTempDirectory();
        const filename = extra.filename;
        const fileFullTempPath = path.join(tempDirectory, filename);

        var writeStream = fs.createWriteStream(fileFullTempPath, {
            start: req.plupload.completedOffset
        });

        writeStream.on('finish', function () {
            const filename = extra.filename;
            formdata.Data = filename;
            formdata.ExtraData = extra;
            formdata.IsSuccess = true;
            res.send(stringify(formdata, null, 2, {offset: 4}));
            return;
        });
        req.plupload.stream.pipe(writeStream);
    }

    static getExtension(filename) {
        var ext = path.extname(filename || '').split('.');
        return ext[ext.length - 1];
    }
}

module.exports = FileController;
