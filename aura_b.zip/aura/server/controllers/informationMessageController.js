'use strict';
const stringify = require('json-stringify');
const Formdata = require('../core/formdata');
const Application = require("../../app");
const ApplicationContext = require('../core/applicationContext');
const NotificationDataAccess = require('../dataaccess/notification');
const PagedFilter = require('../models/pagedFilter');
const InformationMessageDataAccess = require('../dataaccess/informationmessage');
const InformationMessageModel = require('../models/informationmessagemodel');
const InformationMessageType = require('../models/informationmessagetype');

class InformationMessageController {
    static reportProblem(req, res, next) {
        let formdata = new Formdata();
        req.assert('Message', 'Lütfen  Message giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let informationMessageDataAccess = new InformationMessageDataAccess();
            let informationMessageModel = new InformationMessageModel();
            let currentUser = req.user;
            const document = req.body;
            informationMessageModel.BaseType = InformationMessageType.Problem;
            informationMessageModel.Message = document.Message;
            informationMessageModel.Owner = currentUser.DocumentId;
            informationMessageModel.OwnerPhotoPath = currentUser.PhotoPath;
            informationMessageModel.Fullname = currentUser.Fullname;
            informationMessageModel.Username = currentUser.Username;
            informationMessageModel.OwnerPhotoPath = currentUser.PhotoPath;


            informationMessageDataAccess.save(informationMessageModel, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, { offset: 4 });
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });

        }
    }

    static reportAura(req, res, next) {
        let formdata = new Formdata();
        req.assert('Message', 'Lütfen  Message giriniz.').notEmpty();
        req.assert('AuraDocumentId', 'Lütfen  Message giriniz.').notEmpty();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let informationMessageDataAccess = new InformationMessageDataAccess();
            let informationMessageModel = new InformationMessageModel();
            let currentUser = req.user;
            const document = req.body;
            informationMessageModel.AruaDocumentId = document.AruaDocumentId;
            informationMessageModel.BaseType = InformationMessageType.AuraReport;
            informationMessageModel.Message = document.Message;
            informationMessageModel.Owner = currentUser.DocumentId;
            informationMessageModel.OwnerPhotoPath = currentUser.PhotoPath;
            informationMessageModel.Fullname = currentUser.Fullname;
            informationMessageModel.Username = currentUser.Username;
            informationMessageModel.OwnerPhotoPath = currentUser.PhotoPath;


            informationMessageDataAccess.save(informationMessageModel, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, { offset: 4 });
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });

        }
    }

    static shareIdea(req, res, next) {
        let formdata = new Formdata();
        req.assert('Message', 'Lütfen  Message giriniz.').notEmpty().isInt();

        const errors = req.validationErrors();
        if (errors) {
            formdata.Errors = ApplicationContext.getMessageString(errors);
            formdata.IsSuccess = false;
            res.json(formdata);
        }
        else {
            let informationMessageDataAccess = new InformationMessageDataAccess();
            let informationMessageModel = new InformationMessageModel();
            let currentUser = req.user;
            const document = req.body;
            informationMessageModel.BaseType = InformationMessageType.Idea;
            informationMessageModel.Message = document.Message;
            informationMessageModel.Owner = currentUser.DocumentId;
            informationMessageModel.OwnerPhotoPath = currentUser.PhotoPath;
            informationMessageModel.Fullname = currentUser.Fullname;
            informationMessageModel.Username = currentUser.Username;
            informationMessageModel.OwnerPhotoPath = currentUser.PhotoPath;


            informationMessageDataAccess.save(informationMessageModel, function (response, result) {
                if (response) {
                    formdata.Errors = response.message;
                    formdata.IsSuccess = false;
                    res.json(formdata);
                }
                else {
                    formdata.Data = stringify(result, null, 2, { offset: 4 });
                    formdata.IsSuccess = true;
                    res.json(formdata);
                }
            });

        }
    }
}

module.exports = InformationMessageController;
