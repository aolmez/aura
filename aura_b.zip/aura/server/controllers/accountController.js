'use strict';
const crypto = require('crypto');
const path = require('path');
const stringify = require('json-stringify');
const Busboy = require('busboy');
const Formdata = require('../core/formdata');
const ApplicationContext = require('../core/applicationContext');
const UserModel = require('../models/usermodel');
const UserDataAccess = require('../dataaccess/user');
const Application = require("../../app");
const AuraApiController = require('./auraApiController');
const AWSImageManager = require('../core/awsImageManager');
const FileStorage = require('../core/fileStorage');

class AccountController {

    static index(req, res, next) {
        res.render('account/index', { csrfToken: req.csrfToken() });
    }

    static create(req, res, next) {
        let formdata = new Formdata();
        const document = req.body;
        let userDataAccess = new UserDataAccess();

        let user = new UserModel();
        user.Username = document.Username;
        user.Email = document.Email;
        user.Firstname = document.Firstname;
        user.Lastname = document.Lastname;
        user.Fullname = user.Firstname + " " + user.Lastname;
        user.Password = ApplicationContext.generateHash(document.Password);
        user.PhotoPath = document.PhotoPath;
        user.IsActive = true;
        user.IsWebUser = true;
        userDataAccess.getByUsername(user.Username, function (response, result) {
            if (response) {
                formdata.Errors = response.message;
                formdata.IsSuccess = false;
                res.json(formdata);
            } else {
                if (result) {
                    formdata.ErrorCode = '1000';
                    formdata.Errors = 'Sorry, this username is already taken :(';
                    formdata.IsSuccess = false;
                    res.json(formdata);
                } else {
                    userDataAccess.getByEmail(user.Email, function (response, result) {
                        if (response) {
                            formdata.Errors = response.message;
                            formdata.IsSuccess = false;
                            res.json(formdata);
                        } else {
                            if (result) {
                                formdata.ErrorCode = '1000';
                                formdata.Errors = 'Sorry, this Email is already taken :(';
                                formdata.IsSuccess = false;
                                res.json(formdata);
                            } else {
                                let photoPath = ApplicationContext.toRemoveSpecialChar(user.Email) + ".jpeg";
                                const tempDirectory = FileStorage.getTempDirectory();
                                const fileFullTempPath = path.join(tempDirectory, user.PhotoPath);
                                AWSImageManager.uploadAvatarAWS(fileFullTempPath, photoPath, true, function (response, result) {
                                    if (response) {
                                        user.IsActive = true;
                                        formdata.Errors = response.message;
                                        formdata.IsSuccess = false;
                                        res.json(formdata);
                                    }
                                    else {
                                        user.PhotoPath = photoPath;
                                        //#region save.
                                        userDataAccess.save(user, function (response, result) {
                                            if (response) {
                                                formdata.Errors = response.message;
                                                formdata.IsSuccess = false;
                                                res.json(formdata);
                                            } else {
                                                result.IsNewUser = false;
                                                formdata.Data = stringify(result, null, 2, { offset: 4 });
                                                formdata.IsSuccess = true;
                                                res.json(formdata);
                                            }
                                        });
                                        //#endregion save.
                                    }
                                });
                            }
                        }
                    });
                }
            }
        });
    }

    static getAllUser(req, res, next) {
        let formdata = new Formdata();
        const document = req.body;
        let userDataAccess = new UserDataAccess();

        let user = new UserModel();
        userDataAccess.getAllUser(function (response, result) {
            if (response) {
                formdata.Errors = response.message;
                formdata.IsSuccess = false;
                res.json(formdata);
            } else {
                formdata.Data = stringify(result, null, 2, { offset: 4 });
                formdata.IsSuccess = true;
                res.json(formdata);
            }
        });
    }
}

module.exports = AccountController;
