'use strict';
const SettingsDataAccess = require('../dataaccess/settings');
const SettingModel = require('../models/settingmodel');

class DataHelper {
    constructor() {
    }

    init() {
        let settingsDataAccess = new SettingsDataAccess();
        let settingModel1 = new SettingModel();
        settingModel1.DocumentId = process.env.SETTINGS_PARAMS_NOTIFICATIONS_LIKED_AURA_MESSSAGE;
        settingModel1.Value = "{0} liked your aura.";
        settingsDataAccess.save(settingModel1, function (response, result) {
            if (response) {
            } else {
            }
        });

        let settingModel2 = new SettingModel();
        settingModel2.DocumentId = process.env.SETTINGS_PARAMS_NOTIFICATIONS_NEW_FOLLOW_MESSSAGE;
        settingModel2.Value = "{0} started following you.";

        settingsDataAccess.save(settingModel2, function (response, result) {
            if (response) {
            } else {
            }
        });

        let settingModel3 = new SettingModel();
        settingModel3.DocumentId = process.env.SETTINGS_PARAMS_NOTIFICATIONS_NEW_FRIEND_ON_AURA_MESSSAGE;
        settingModel3.Value = "Your Facebook friend {0} is on Aura as {1}.";

        settingsDataAccess.save(settingModel3, function (response, result) {
            if (response) {
            } else {
            }
        });
        let settingModel4 = new SettingModel();
        settingModel4.DocumentId = process.env.SETTINGS_PARAMS_NOTIFICATIONS_FIRST_AURA_MESSSAGE;
        settingModel4.Value = "{0} took their first aura.";

        settingsDataAccess.save(settingModel4, function (response, result) {
            if (response) {
            } else {
            }
        });

        let settingModel5 = new SettingModel();
        settingModel5.DocumentId = process.env.SETTINGS_PARAMS_TERMS_AND_CONDITIONS;
        settingModel5.Value = "xxxx";

        settingsDataAccess.save(settingModel5, function (response, result) {
            if (response) {
            } else {
            }
        });
    }
}

module.exports = DataHelper; 