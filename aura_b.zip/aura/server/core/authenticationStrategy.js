'use strict';
const passport = require('passport');
const basicStrategy = require('passport-http').BasicStrategy;
const localStrategy = require('passport-local').Strategy;
const UserDataAccess = require('../dataaccess/user');
const UserModel = require('../models/usermodel');

passport.use('client-basic', new basicStrategy(
    function (username, password, callback) {
        let userDataAccess = new UserDataAccess();
        userDataAccess.getById(username, function (err, user) {
            if (err) {
                return callback(err, null);
            }
            else {
                return callback(null, user);
            }
        });
    }
));

exports.isAuthenticated = passport.authenticate('client-basic', {session: false});