'use strict';
const aws = require('aws-sdk');
const fs = require('fs');
const request = require('request');
const multiparty = require('multiparty');

class AWSElasticTranscoder {
    static createJob(key, callback) {
        aws.config.update({
            accessKeyId: process.env.AWS_SECRET_KEY,
            secretAccessKey: process.env.AWS_SECRET_ACCESSKEY,
            region: process.env.AWS_REGION
        });

        let transcoder = new aws.ElasticTranscoder();

        let params = {
            PipelineId: process.env.AWS_TRANSCODER_PIPELINEID,
            Input: {
                Key: 'temp/' + key,
            },
            OutputKeyPrefix: 'videos/',
            Outputs: [
                { PresetId: process.env.AWS_TRANSCODER_PIPELINE_PRESENTID, Key: key }
            ]
        };

        params.Outputs[0].ThumbnailPattern = key.replace('.mp4', '') + '-{count}';
        transcoder.createJob(params, function (err, data) {
            if (!!err) {
                callback(err, data);
                return;
            }
            let jobId = data.Job.Id;
            console.log('AWS transcoder job created (' + jobId + ')');
            transcoder.waitFor('jobComplete', { Id: jobId }, callback);
        });
    }
}

module.exports = AWSElasticTranscoder;