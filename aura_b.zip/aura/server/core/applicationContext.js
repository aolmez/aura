'use strict';
const crypto = require('crypto');
const url = require('url');

class ApplicationContext {
    constructor() {

    }

    static getTokenStringBase() {
        return 'base64';
    }

    static getTokenByteLength() {
        return 12;
    }

    static getSecret() {
        let Secret = 'c0fa1bc00531bd78ef38c628449c5102aeabd49b5dc3a2a516ea6ea959d6658e';
        return Secret;
    }

    static generateHash(password) {
        const hash = crypto.createHash('sha512').update(password).digest('hex');
        return hash;
    }

    static validPassword(password, saltPassword) {
        const hash = crypto.createHash('sha512').update(saltPassword).digest('hex');
        return hash == password;
    }

    static toRemoveSpecialChar(value) {
        return value.replace(/[^\w\s]/gi, '');
    }

    static getMessageString(errors) {
        let msg = '';
        for (var index = 0; index < errors.length; index++) {
            var error = errors[index];
            msg += error.msg + '\n';
        }
        return msg;
    }


    static getStringFromDate(value) {
        let result = value;
        if (value) {
            result = moment(value).format("DD/MM/Y").toString();
        }
        return result;
    }

    static getDateFromString(value) {
        let result = value;
        if (value) {
            result = ApplicationContext.stringToDate(value, "dd/MM/yyyy", "/");
        } else { result = undefined; }
        return result;
    }

    static stringToDate(_date, _format, _delimiter) {
        const formatLowerCase = _format.toLowerCase();
        const formatItems = formatLowerCase.split(_delimiter);
        const dateItems = _date.split(_delimiter);
        const monthIndex = formatItems.indexOf("mm");
        const dayIndex = formatItems.indexOf("dd");
        const yearIndex = formatItems.indexOf("yyyy");
        let month = parseInt(dateItems[monthIndex]);
        month -= 1;
        const formatedDate = new Date(dateItems[yearIndex], month, dateItems[dayIndex]);
        return formatedDate;
    }
    static IsAuthenticated(req, res, next) {
        if (req.session && req.session.user) {
            next();
        } else {
            res.redirect('/admin/');
        }
    }

    static setUserInSession(req, model) {
        req.session.user = model;
        req.session.htmlUser = {
            email: model.Email,
            firstName: model.Firstname,
            lastName: model.Lastname,
            fullname: model.Fullname,
            photoPath: model.PhotoPath
        };
    }

    static getUser(req) {
        var user = null;
        if (req.session && req.session.user) {
            user = req.session.user;
        }
        return user;
    }

    static trimByChar(string, charToRemove) {
        while (string.charAt(0) == charToRemove) {
            string = string.substring(1);
        }

        while (string.charAt(string.length - 1) == charToRemove) {
            string = string.substring(0, string.length - 1);
        }

        return string;
    }

    static checkUsernameOnlyLatinChars(username) {
        if (username && username.length > 0) {
            var filteredUsername = username.replace(/[^a-z0-9]._/i, "");
            if (filteredUsername == username) {
                return true;
            }
        }
        return false;
    }
}

module.exports = ApplicationContext;
