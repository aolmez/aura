'use strict';
const fs = require('fs');
const path = require('path');
const uuid = require('uuid');

class FileStorage {

    constructor() { }

    static getTempDirectory() {
        const directoryPath = path.resolve('./public/temp');
        return directoryPath;
    }

    static getStorageDirectory() {
        const directoryPath = path.resolve('./filesystem/storage');
        return directoryPath;
    }

    static getAvatarDirectory() {
        const directoryPath = path.resolve('./public/images/avatars');
        return directoryPath;
    }

    static generateFileName() {
        let filename = uuid.v4();
        filename = filename.replace('-', '');
        return filename;
    }

    copyFile(source, target) {
        return new Promise(function (resolve, reject) {
            let rd = fs.createReadStream(source);
            rd.on('error', rejectCleanup);
            let wr = fs.createWriteStream(target);
            wr.on('error', rejectCleanup);
            function rejectCleanup(err) {
                rd.destroy();
                wr.end();
                reject(err);
            }
            wr.on('finish', resolve);
            rd.pipe(wr);
        });
    }
}

module.exports = FileStorage;
