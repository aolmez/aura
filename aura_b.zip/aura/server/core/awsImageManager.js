'use strict';
const aws = require('aws-sdk');
const fs = require('fs');
const request = require('request');
const multiparty = require('multiparty');

class AWSImageManager {
    static downloadAndUploadAWS(uri, filename, callback) {
        aws.config.update({
            accessKeyId: process.env.AWS_SECRET_KEY,
            secretAccessKey: process.env.AWS_SECRET_ACCESSKEY
        });
        const s3 = new aws.S3({params: {Bucket: process.env.AWS_AVATAR_BUCKET}});

        let imageStream = request({
            url: uri,
            encoding: null
        }, function (err, response, body) {
            if (err)
                return callback(err, response);

            console.log('STATUS: ' + response.statusCode);
            console.log('HEADERS: ' + JSON.stringify(response.headers));
            if (200 === response.statusCode) {
                let contentType = response.headers['content-type'];
                let contentLength = response.headers['content-length'];
                s3.upload({
                    Key: filename,
                    ContentType: contentType,
                    ContentLength: contentLength,
                    ACL: "public-read",
                    Body: body
                }, callback);
            }
        });

        imageStream.on('error', function (err) {
            console.log(err)
        })
        imageStream.on('close', callback);
    }

    static uploadAWS(files, filename, callback) {
        let form = new multiparty.Form();
        aws.config.update({
            accessKeyId: process.env.AWS_SECRET_KEY,
            secretAccessKey: process.env.AWS_SECRET_ACCESSKEY
        });
        const s3 = new aws.S3({
            params: {
                Bucket: process.env.AWS_AVATAR_BUCKET,
                region: process.env.AWS_REGION
            }
        });
        files.image.forEach(function (file) {

            fs.readFile(file.path, function (err, data) {
                if (err) {
                    callback(err, null);
                    return;
                }

                let contentType = 'image/jpeg';
                let contentLength = file.size;
                const base64data = new Buffer(data, 'binary');
                s3.upload({
                    Key: filename,
                    Body: base64data,
                    ContentType: contentType,
                    ContentLength: contentLength,
                    ACL: 'public-read'
                }, function (response) {
                    fs.unlink(file.path, function (err) {
                        if (err) {
                            callback(err, null);
                        }
                    });

                    if (response) {
                        callback(response, null);
                    } else {
                        callback(null, {});
                    }
                });

            });
        });
    }

    static uploadAvatarAWS(file, filename, deleteSource, callback) {
        let form = new multiparty.Form();
        aws.config.update({
            accessKeyId: process.env.AWS_SECRET_KEY,
            secretAccessKey: process.env.AWS_SECRET_ACCESSKEY
        });
        const s3 = new aws.S3({
            params: {
                Bucket: process.env.AWS_AVATAR_BUCKET,
                region: process.env.AWS_REGION
            }
        });

        fs.readFile(file, function (err, data) {
            if (err) {
                callback(err, null);
                return;
            }

            let contentType = 'image/jpeg';
            let contentLength = data.length;
            const base64data = new Buffer(data, 'binary');
            s3.upload({
                Key: filename,
                Body: base64data,
                ContentType: contentType,
                ContentLength: contentLength,
                ACL: 'public-read'
            }, function (response) {
                if (deleteSource) {
                    fs.unlink(file, function (err) {
                        if (err) {
                            callback(err, null);
                            return;
                        }
                    });
                }

                if (response) {
                    callback(response, null);
                } else {
                    callback(null, {});
                }
            });

        });
    }

    static copyToPictureFile(tempPath, callback) {
        aws.config.update({
            accessKeyId: process.env.AWS_SECRET_KEY,
            secretAccessKey: process.env.AWS_SECRET_ACCESSKEY
        });
        const s3 = new aws.S3();
        var params = {
            Bucket: process.env.AWS_MAIN_BUCKET,
            CopySource: process.env.AWS_TEMP_BUCKET + '/' + tempPath,
            Key: 'pictures/' + tempPath,
            ACL: "public-read"
        };
        s3.copyObject(params, function (response, result) {
            callback(response, result);
        });
    }

    static deleteTemp(tempPath, callback) {
        aws.config.update({
            accessKeyId: process.env.AWS_SECRET_KEY,
            secretAccessKey: process.env.AWS_SECRET_ACCESSKEY
        });
        const s3 = new aws.S3();
        var params = {
            Bucket: process.env.AWS_TEMP_BUCKET,
            Key: tempPath,
        };
        s3.deleteBucket(params, function (response, result) {
            if (callback)
                callback(response, result);
        });
    }
}

module.exports = AWSImageManager;
