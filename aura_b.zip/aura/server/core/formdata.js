'use strict';

class FormData {
    constructor() {
        this.Data = '';
        this.ErrorCode = '';
        this.Errors = '';
        this.HtmlContent = '';
        this.IsRedirect = false;
        this.IsSuccess = false;
        this.Url = '';
        this.ExtraData = '';
    }
    getData() {
        return this.Data;
    }
    setData(data) {
        this.Data = data;
    }
    toString() {
        return 'FormData.${this.Data}';
    }
}

module.exports = FormData;
