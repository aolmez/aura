'use strict';
const firebase = require('firebase');
const admin = require('firebase-admin');

class NotificationManager {
    constructor() {

    }

    init() {
        var serviceAccount = require("../../files/serviceAccountKey.json");

        admin.initializeApp({
            credential: admin.credential.cert(serviceAccount),
            databaseURL: process.env.FIREBASE_DATABASE_URL
        });
    }

    send(message) {
        admin.messaging().send(message).then((response) => {
            console.log('Successfully sent message:', response);
        }).catch((error) => {
            console.log('Error sending message:', error);
        });
    }

    sendWithCallback(message, callback) {
        admin.messaging().send(message).then((response) => {
            callback();
        }).catch((error) => {
            callback();
        });
    }
}

module.exports = NotificationManager;