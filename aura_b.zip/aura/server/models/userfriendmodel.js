'use strict';
const Helper = require("./helper");

class UserFriendModel {
    constructor() {
        this.DocumentId = undefined;
        this.FriendDocumentId = undefined;
        this.OwnerDocumentId = undefined;
        this.Type = 'friend';
        this.Provider = undefined;
        this.OwnerFullname = undefined;
        this.OwnerUsername = undefined;
        this.OwnerPhotoPath= undefined;
        this.FriendFullname = undefined;
        this.FriendUsername = undefined;
        this.FriendPhotoPath= undefined;
        this.CreatedAt = Helper.getTick();
    }
}

module.exports = UserFriendModel; 