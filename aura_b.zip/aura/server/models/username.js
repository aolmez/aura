'use strict';

class Username {
    constructor() {
        this.Username = undefined;
        this.Fullname = undefined;
        this.PhotoPath = undefined;
    }
    static load(object) {
        let user = new Username();
        if (object.email)
            user.Email = object.email.S;
        if (object.fullname)
            user.Fullname = object.fullname.S;
        if (object.photopath)
            user.PhotoPath = object.photopath.S;
        return user;
    }
}

module.exports = Username;
