'use strict';
const AuraType = {
    Image: 0,
    Video: 1
};

module.exports = AuraType;