'use strict';
const NotificationType = {
    Like: 0,
    NewFollow: 1,
    NewFriendOnAura: 2,
    FirstAura: 3,
    ChatMessage: 4
};

module.exports = NotificationType;