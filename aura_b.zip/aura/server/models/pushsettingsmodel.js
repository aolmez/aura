'use strict';
const Helper = require("./helper");
const PushNotificationSettingStatus = require('./pushnotificationsettingstatus');
const NotificationType = require('./notificationType');

class PushSettingsModel {
    constructor() {
        this.Like = PushNotificationSettingStatus.On;
        this.NewFollow = PushNotificationSettingStatus.On;
        this.NewFriendOnAura = PushNotificationSettingStatus.On;
        this.FirstAura = PushNotificationSettingStatus.On;
    }
    set(type, value) {
        if (type == NotificationType.Like) {
            this.Like = value;
        }
        else if (type == NotificationType.NewFollow) {
            this.NewFollow = value;
        }
        else if (type == NotificationType.NewFriendOnAura) {
            this.NewFriendOnAura = value;
        }
        else if (type == NotificationType.FirstAura) {
            this.FirstAura = value;
        }
    }
}

module.exports = PushSettingsModel; 