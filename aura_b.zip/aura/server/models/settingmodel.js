'use strict';

class SettingModel {
    constructor() {
        this.DocumentId = undefined;
        this.Value = undefined;
        this.Type = 'setting';
    }
}

module.exports = SettingModel; 