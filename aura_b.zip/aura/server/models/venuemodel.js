'use strict'; 
const Helper = require("./helper");

class VenueModel {
    constructor() {
        this.DocumentId = undefined;
        this.Title = undefined;
        this.City = undefined;
        this.Address = undefined;        
        this.Location = {
            latitude: undefined,
            longitude: undefined
        };
        this.PhotoPath = undefined;
        this.IsActive = false;
        this.Type = 'venue'; 
        this.CreatedAt = Helper.getTick(); 
        this.CheckInCount = 0;
        this.AuraCount = 0;
        this.Followers = 0;
    }
}

module.exports = VenueModel; 