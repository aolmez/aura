'use strict';
const AuraShareType = {
    Public: 0,
    Private: 1
};

module.exports = AuraShareType;