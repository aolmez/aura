'use strict';
const Helper = require("./helper");

class DeviceModel {
    constructor() {
        this.DocumentId = undefined;
        this.Token = undefined; 
        this.OwnerId = undefined; 
        this.DeviceType = undefined;
        this.Type = 'token';
        this.CreatedAt = Helper.getTick();
    } 
}

module.exports = DeviceModel;
