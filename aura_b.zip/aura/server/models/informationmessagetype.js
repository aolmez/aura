'use strict';
const InformtionMessageType = {
    Problem: 0,
    Idea: 1,
    AuraReport: 2,
};

module.exports = InformtionMessageType;