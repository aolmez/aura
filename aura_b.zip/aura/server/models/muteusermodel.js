'use strict'; 
const Helper = require("./helper");

class MuteUserModel {
    constructor() {
        this.DocumentId = undefined; 
        this.OwnerDocumentId = undefined;  
        this.FriendDocumentId = undefined;  
        this.Type = 'muteuser'; 
        this.CreatedAt = Helper.getTick(); 
    }
}

module.exports = MuteUserModel; 