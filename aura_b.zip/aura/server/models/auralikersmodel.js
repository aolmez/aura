'use strict';
const Helper = require("./helper");

class AuraLikersModel {
    constructor() {
        this.DocumentId = undefined;
        this.AuraDocumentId = undefined;
        this.Owner = undefined; 
        this.OwnerPhotoPath = undefined;
        this.Fullname = undefined;
        this.Username = undefined;
        this.Type = 'liker'; 
        this.CreatedAt = Helper.getTick();
    }
}

module.exports = AuraLikersModel; 