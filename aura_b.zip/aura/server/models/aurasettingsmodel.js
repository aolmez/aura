'use strict';
const Helper = require("./helper");
const PushNotificationSettingStatus = require('./pushnotificationsettingstatus');
const AuraSettingsType = require('./aurasettingtype');

class AuraSettingsModel {
    constructor() {
        this.AllowMessageReplies = PushNotificationSettingStatus.Everyone;
        this.MyMap = PushNotificationSettingStatus.Everyone;
        this.RecentAurasOnProfile = PushNotificationSettingStatus.Everyone;
        this.FollowerFollowingList = PushNotificationSettingStatus.Everyone;
    }
    set(type, value) {
        if (type == AuraSettingsType.AllowMessageReplies) {
            this.AllowMessageReplies = value;
        }
        else if (type == AuraSettingsType.MyMap) {
            this.MyMap = value;
        }
        else if (type == AuraSettingsType.RecentAurasOnProfile) {
            this.RecentAurasOnProfile = value;
        }
        else if (type == AuraSettingsType.FollowerFollowingList) {
            this.FollowerFollowingList = value;
        }
    }
}

module.exports = AuraSettingsModel;