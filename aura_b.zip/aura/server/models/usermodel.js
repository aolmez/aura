'use strict';
const Helper = require("./helper");

class UserModel {
    constructor() {
        this.DocumentId = undefined;
        this.Email = undefined;
        this.Username = undefined;
        this.Password = undefined;
        this.Firstname = undefined;
        this.Lastname = undefined;
        this.Fullname = undefined;
        this.EmailToken = undefined;
        this.PhotoPath = undefined;
        this.Facebook = undefined;
        this.Google = undefined;
        this.ShortBiography = undefined;
        this.IsActive = false;
        this.IsWebUser = false;
        this.Type = 'user';
        this.CreatedAt = Helper.getTick();
        this.AuraCount = 0;
        this.Followers = 0;
        this.Following = 0;
    }
}

module.exports = UserModel;
