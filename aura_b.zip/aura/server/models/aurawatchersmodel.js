'use strict';
const Helper = require("./helper");

class AuraWatchersModel {
    constructor() {
        this.DocumentId = undefined;
        this.Owner = undefined;
        this.OwnerPhotoPath = undefined;
        this.Type = 'watcher';
        this.CreatedAt = Helper.getTick();
    }
}

module.exports = AuraWatchersModel; 