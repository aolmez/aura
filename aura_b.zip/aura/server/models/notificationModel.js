'use strict';
const Helper = require("./helper");
const NotificationType = require("./notificationType");

class NotificationModel {
    constructor() {
        this.DocumentId = undefined;
        this.NotificationType = undefined;
        this.Message = undefined;
        this.OwnerId = undefined;
        this.UserFriendId = undefined;
        this.Data = {};
        this.Type = 'notification';
        this.CreatedAt = Helper.getTick();
    }
}

module.exports = NotificationModel; 