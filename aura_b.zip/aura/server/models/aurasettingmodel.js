'use strict';
const Helper = require("./helper");

class AuraSettingModel {
    constructor() {
        this.DocumentId = undefined;
        this.Status = undefined;
        this.AuraSettingsType = undefined;
        this.OwnerDocumentId = undefined;
        this.Type = 'aurasetting';
        this.CreatedAt = Helper.getTick();
    }
}

module.exports = AuraSettingModel; 