'use strict';

class PagedFilter {
    constructor() {
        this.Latitude = undefined;
        this.Longitude = undefined;
        this.PageIndex = 0;
        this.PageSize = 10;
        this.User = undefined;
        this.CurrentUser = undefined;
        this.VenueId = undefined;
        this.Title = undefined;
        this.Radius = undefined;
    }
    static load(object, user) {
        let filter = new PagedFilter();
        filter.Latitude = object.Latitude;
        filter.Longitude = object.Longitude;
        filter.PageIndex = object.PageIndex;
        filter.PageSize = 10;
        filter.User = user;
        filter.CurrentUser = user;
        filter.VenueId = object.VenueId;
        filter.Title = object.Title;
        filter.AuraDocumentId = object.AuraDocumentId;
        filter.Radius = object.Radius;
        return filter;
    }
}

module.exports = PagedFilter;