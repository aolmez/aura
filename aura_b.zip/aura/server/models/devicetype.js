'use strict';
const DeviceType = {
    IOS: 0,
    Android: 1
};

module.exports = DeviceType;