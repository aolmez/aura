'use strict';
const Helper = require("./helper");

class PushSettingModel {
    constructor() {
        this.DocumentId = undefined;
        this.Status = undefined;
        this.NotificationType = undefined;
        this.OwnerDocumentId = undefined;
        this.Type = 'pushsetting';
        this.CreatedAt = Helper.getTick();
    }
}

module.exports = PushSettingModel; 