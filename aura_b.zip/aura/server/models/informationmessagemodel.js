'use strict';
const InformationMessageType = require("./informationmessagetype"); 
const Helper = require("./helper");

class InformationMessageModel {
    constructor() {
        this.DocumentId = undefined; 
        this.AruaDocumentId = undefined; 
        this.Message = undefined; 
        this.BaseType = InformationMessageType.Idea;  
        this.Owner = undefined;
        this.OwnerPhotoPath = undefined; 
        this.Fullname = undefined;
        this.Username = undefined;
        this.IsActive = false;
        this.Type = 'informationmessage'; 
        this.CreatedAt = Helper.getTick(); 
    }
}

module.exports = InformationMessageModel; 