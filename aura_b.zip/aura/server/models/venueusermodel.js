'use strict';
const Helper = require("./helper");

class VenueUserModel {
    constructor() {
        this.DocumentId = undefined;
        this.Owner = undefined;
        this.OwnerPhotoPath = undefined;
        this.VenueId= undefined;
        this.Type = 'venueuser'; 
        this.CreatedAt = Helper.getTick();
    }
}

module.exports = VenueUserModel; 