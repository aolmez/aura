'use strict';

class Helper {
    constructor() {
    }
    static getTick() {
        Date.prototype.getUTC = function () {
            return new Date(
                this.getUTCFullYear(),
                this.getUTCMonth(),
                this.getUTCDate(),
                this.getUTCHours(),
                this.getUTCMinutes(),
                this.getUTCSeconds()
            );
        };

        let date = new Date().getUTC();
        let tick = ((date.getTime() * 10000) + 621355968000000000) - (date.getTimezoneOffset() * 600000000);
        return tick;
    }

    static getTickWithParam(hour) {
        Date.prototype.getUTC = function () {
            return new Date(
                this.getUTCFullYear(),
                this.getUTCMonth(),
                this.getUTCDate(),
                this.getUTCHours() + hour,
                this.getUTCMinutes(),
                this.getUTCSeconds()
            );
        };

        let date = new Date().getUTC();
        let tick = ((date.getTime() * 10000) + 621355968000000000) - (date.getTimezoneOffset() * 600000000);
        return tick;
    }
}

module.exports = Helper; 