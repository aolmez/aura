'use strict';
const Helper = require("./helper");

class BlockedUserModel {
    constructor() {
        this.DocumentId = undefined; 
        this.OwnerId = undefined;  
        this.BlockedUserId = undefined;  
        this.BlockedUserPhotoPath = undefined;
        this.BlockedFullname = undefined;
        this.BlockedUsername = undefined;
        this.Type = 'blockeduser';
        this.CreatedAt = Helper.getTick();
    } 
}

module.exports = BlockedUserModel;
