'use strict';
const AuraSettingsType = {
    AllowMessageReplies: 0,
    MyMap: 1,
    RecentAurasOnProfile: 2,
    FollowerFollowingList: 3, 
};

module.exports = AuraSettingsType; 