'use strict';
const AuraType = require("./auratype");
const AuraShareType = require("./aurasharetype");
const Helper = require("./helper");

class AuraModel {
    constructor() {
        this.DocumentId = undefined;
        this.Title = undefined;
        this.VenueId = undefined;
        this.DocumentPath = undefined;
        this.VideoDocumentPath = undefined;
        this.Duration = undefined;
        this.VideoDocumentPath = undefined;
        this.City = undefined;
        this.Address = undefined;
        this.Location = {
            latitude: undefined,
            longitude: undefined
        };
        this.BaseType = AuraType.Image;
        this.ShareType = AuraShareType.Public;
        this.PhotoPath = undefined;
        this.Author = undefined;
        this.Owner = undefined;
        this.IsActive = false;
        this.Type = 'aura'; 
        this.CreatedAt = Helper.getTick();
        this.LikeCount = 0;
        this.ViewerCount = 0;
    }
}

module.exports = AuraModel; 