'use strict';
const PushNotificationSettingStatus = {
    Off: 0,
    On: 1,
    PeopleYouFollow: 2,
    Everyone: 3,
};

module.exports = PushNotificationSettingStatus;