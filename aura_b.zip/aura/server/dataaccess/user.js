'use strict';
const aws = require('aws-sdk');
const async = require("async");
const uuid = require('uuid/v4');
const format = require('string-format');
const BaseModel = require('./basemodel');
const BaseObject = require('./baseobject');
const BaseObjectType = require('./baseobjecttype');
const VenueUserModel = require('../models/venueusermodel');
const UserFriendModel = require('../models/userfriendmodel');
const atomicCounter = require('dynamodb-atomic-counter');
const couchbase = require("couchbase");
const app = require("../../app");
const N1qlQuery = require('couchbase').N1qlQuery;
const NotificationDataAccess = require('./notification');
const NotificationModel = require('../models/notificationModel');
const NotificationType = require('../models/notificationType');
const DeviceDataAccess = require('./device');
const DeviceModel = require('../models/devicemodel');
const DeviceType = require('../models/devicetype');
const SettingsDataAccess = require('./settings');
const Helper = require("../models/helper");
const AuraSettingsType = require('../models/aurasettingtype');
const PushNotificationSettingStatus = require('../models/pushnotificationsettingstatus');

class UserDataAccess extends BaseModel {
    constructor() {
        super('users');
    }

    save(model, callback) {
        model.DocumentId = model.DocumentId ? model.DocumentId : uuid.v4();
        app.buckets.user.upsert(model.DocumentId, model, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, model);
        });
    }

    saveFriend(model, callback) {
        model.DocumentId = model.DocumentId ? model.DocumentId : uuid.v4();
        app.buckets.userfriends.upsert(model.DocumentId, model, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, model);
        });
    }

    changeVenueFollowers(venueId, callback) {
        let query = N1qlQuery.fromString('UPDATE `users` USE KEYS ($1)  SET Followers  = (select raw count(*)  from userfriends where Type = "starVenue" and FriendDocumentId = ($1))[0]  RETURNING Followers;');
        query.consistency(couchbase.N1qlQuery.Consistency.REQUEST_PLUS);
        app.buckets.user.query(query, [venueId], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                callback(null, result[0].Followers);
            }
        });
    }

    calculateFollowingCount(documentId, callback) {
        let query = N1qlQuery.fromString('UPDATE `users` USE KEYS ($1)  SET Following = (select raw count(*)  from userfriends where OwnerDocumentId = ($1))[0] ;');
        query.consistency(couchbase.N1qlQuery.Consistency.REQUEST_PLUS);
        app.buckets.user.query(query, [documentId], function (error, result) {
            if (error) {
                callback(error, null);
            }
            else {
                callback(null, result);
            }
        });
    }


    saveVenue(user, updateCheckInCount, model) {
        return new Promise(function (resolve, reject) {
            try {
                model.DocumentId = model.DocumentId ? model.DocumentId : uuid.v4();
                app.buckets.user.get(model.DocumentId, function (error, result) {
                    let hasError = false;
                    if (error && error.code !== 13) {
                        hasError = true;
                    }
                    if (hasError && error) {
                        reject(error);
                    }
                    else {
                        let key = user.DocumentId + "::" + model.DocumentId;
                        let venueUserModel = new VenueUserModel();
                        venueUserModel.DocumentId = key;
                        venueUserModel.Owner = user.DocumentId;
                        venueUserModel.OwnerPhotoPath = user.PhotoPath;
                        venueUserModel.VenueId = model.VenueId;

                        if (result === null) {
                            if (updateCheckInCount) {
                                model.CheckInCount = 1;
                            } else {
                                model.CheckInCount = 0;
                            }
                            app.buckets.venueusers.upsert(venueUserModel.DocumentId, venueUserModel, function (error, result) {
                                if (error) {
                                    reject(error);
                                }
                                else {
                                    app.buckets.user.upsert(model.DocumentId, model, function (error, result) {
                                        if (error) {
                                            reject(error);
                                        }
                                        resolve(result);
                                    });
                                }
                            });
                        }
                        else {
                            model = result.value;
                            if (updateCheckInCount) {
                                model.CheckInCount += 1;
                            }
                            app.buckets.venueusers.get(key, function (error, result) {
                                let hasError = false;
                                if (error && error.code !== 13) {
                                    hasError = true;
                                }
                                if (hasError && error) {
                                    reject(error);
                                } else {
                                    if (result === null) {
                                        app.buckets.venueusers.upsert(venueUserModel.DocumentId, venueUserModel, function (error, result) {
                                            if (error) {
                                                reject(error);
                                            }
                                            else {
                                                app.buckets.user.upsert(model.DocumentId, model, function (error, result) {
                                                    if (error) {
                                                        reject(error);
                                                    }
                                                    resolve(result);
                                                });
                                            }
                                        });
                                    }
                                    else {
                                        resolve(model);
                                    }
                                }
                            });
                        }
                    }
                });
            } catch (error) {
                reject(error);
            }
        });
    }

    getById(id, callback) {
        app.buckets.user.get(id, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result.value);
        });
    }

    getByEmail(email, callback) {
        let viewQuery = couchbase.ViewQuery;
        let query = viewQuery.from('users', 'GetByEmail').key(email).stale(viewQuery.Update.BEFORE);
        app.buckets.user.query(query, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            } else {
                if (result.length > 0) {
                    callback(null, result[0].value);
                } else {
                    //callback({message: 'Kullanici bulunamadı.'}, null);
                    callback(null, null);
                }
            }
        });
    }

    getByFacebookId(facebookId, callback) {
        let viewQuery = couchbase.ViewQuery;
        let query = viewQuery.from('users', 'GetByFacebookID').key(facebookId).stale(viewQuery.Update.BEFORE);
        app.buckets.user.query(query, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            if (result.length > 0) {
                callback(null, result[0]);
            } else {
                callback(null, null);
            }
        });
    }

    getByGoogleId(googleId, callback) {
        let viewQuery = couchbase.ViewQuery;
        let query = viewQuery.from('users', 'GetByGoogleID').key(googleId).stale(viewQuery.Update.BEFORE);
        app.buckets.user.query(query, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            if (result.length > 0) {
                callback(null, result[0]);
            } else {
                callback(null, null);
            }
        });
    }

    getByUsername(username, callback) {
        let viewQuery = couchbase.ViewQuery;
        let query = viewQuery.from('users', 'GetByUsername').key(username).stale(viewQuery.Update.BEFORE);
        app.buckets.user.query(query, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            if (result.length > 0) {
                callback(null, result[0]);
            } else {
                callback(null, null);
            }
        });
    }

    updateUsernameById(documentId, username, callback) {
        let query = N1qlQuery.fromString('UPDATE ' + super.TableName + ' USE KEYS ($1)  SET Username = $2');
        app.buckets.user.query(query, [documentId, username], function (error, rows, meta) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                callback(null, meta);
            }
        });
    }

    addFriendsById(user, friends, provider, callback) {
        const scope = this;
        let viewQuery = couchbase.ViewQuery;
        let query = viewQuery.from('users', 'GetByFacebookID').stale(viewQuery.Update.BEFORE).keys(friends);
        if (provider === 'google') {
            query = viewQuery.from('users', 'GetByGoogleID').stale(viewQuery.Update.BEFORE).keys(friends);
        }
        if (friends && friends.length && friends.length > 0) {
            app.buckets.user.query(query, {}, function (error, result) {
                if (error) {
                    callback(error, null);
                    return;
                }
                else {
                    let settingsDataAccess = new SettingsDataAccess();
                    settingsDataAccess.getById(process.env.SETTINGS_PARAMS_NOTIFICATIONS_NEW_FOLLOW_MESSSAGE, function (response, setting) {
                        if (response) {
                            callback(response, null);
                        }
                        else {
                            if (result && result.length > 0) {
                                let notificationDataAccess = new NotificationDataAccess();
                                let deviceDataAccess = new DeviceDataAccess();
                                let notificationModel = new NotificationModel();
                                notificationModel.NotificationType = NotificationType.NewFollow;

                                let friends = result;
                                let promises = Array();
                                for (let index = 0; index < friends.length; index++) {
                                    let friend = friends[index];
                                    let key = user.DocumentId + '::' + friend.id;
                                    let promise = scope.sendNewFollow(key, friend, notificationModel, user, setting, provider);
                                    promises.push(promise);
                                }

                                Promise.all(promises).then(function (results) {
                                    let query = N1qlQuery.fromString('UPDATE `users` USE KEYS ($1)  SET Following = (select raw count(*)  from userfriends where OwnerDocumentId = ($1)) [0];');
                                    query.consistency(couchbase.N1qlQuery.Consistency.REQUEST_PLUS);
                                    app.buckets.user.query(query, [user.DocumentId], function (error, result) {
                                        if (error) {
                                            reject(error);
                                        }
                                        else {
                                            promises = Array();
                                            for (let index = 0; index < friends.length; index++) {
                                                let friend = friends[index];
                                                let promise = new Promise(function (resolve, reject) {
                                                    let query = N1qlQuery.fromString('UPDATE `users` USE KEYS ($1)  SET Followers = (select raw count(*)  from userfriends where FriendDocumentId = ($1))[0];');
                                                    query.consistency(couchbase.N1qlQuery.Consistency.REQUEST_PLUS);
                                                    app.buckets.user.query(query, [friend.id], function (error, result) {
                                                        if (error && error.code != 5030) {
                                                            reject(error);
                                                        }
                                                        else {
                                                            resolve();
                                                        }
                                                    });
                                                });
                                                promises.push(promise);
                                            }

                                            Promise.all(promises).then(function (results) {
                                                callback(null, {});
                                            }).catch(function (error) {
                                                callback(error, null);
                                            });
                                        }
                                    });

                                }).catch(function (error) {
                                    callback(error, null);
                                });

                            } else {
                                callback(null, {});
                            }
                        }
                    });
                }
            });
        } else {
            callback(null, {});
        }
    }

    sendNewFollow(key, friend, notificationModel, user, setting, provider) {
        return new Promise(function (resolve, reject) {
            let notificationDataAccess = new NotificationDataAccess();
            let deviceDataAccess = new DeviceDataAccess();
            app.buckets.user.get(friend.id, function (error, friend) {
                if (error) {
                    reject(error);
                } else {
                    friend = friend.value;
                    let doc = new UserFriendModel();
                    doc.DocumentId = key;
                    doc.OwnerDocumentId = user.DocumentId;
                    doc.OwnerFullname = user.Fullname;
                    doc.OwnerUsername = user.Username;
                    doc.OwnerPhotoPath = user.PhotoPath;
                    doc.Provider = provider;
                    doc.FriendDocumentId = friend.DocumentId;
                    doc.FriendFullname = doc.Fullname;
                    doc.FriendUsername = friend.Username;
                    doc.FriendPhotoPath = friend.PhotoPath;

                    notificationModel.Message = format(setting.Value, user.Username);
                    //notificationModel.Message = format(setting.Value, user.Fullname, user.Username);
                    notificationModel.Data = doc;
                    notificationModel.UserFriendId = friend.DocumentId;
                    app.buckets.userfriends.get(key, function (error, result) {
                        let data = doc;
                        let isNotKeyExist = false;
                        if (error && error.code === 13) {
                            isNotKeyExist = true;
                        }
                        if (!isNotKeyExist && error) {
                            reject(error);
                            return;
                        }
                        if (isNotKeyExist) {
                            app.buckets.userfriends.upsert(key, doc, function (error, result) {
                                if (error) {
                                    reject(error);
                                } else {
                                    //get all device...
                                    deviceDataAccess.getByOwnerId(user.DocumentId, friend.DocumentId, NotificationType.NewFriendOnAura, function (response, devices) {
                                        if (response) {
                                            reject(response);
                                        }
                                        else {
                                            if (devices.length !== 0) {
                                                let promises = Array();

                                                notificationModel.DocumentId = "nfol::" + key;
                                                notificationModel.OwnerId = friend.DocumentId;

                                                let promise = new Promise(function (resolve, reject) {
                                                    notificationDataAccess.save(notificationModel, function (error, notification) {
                                                        if (error) {
                                                            reject(error);
                                                        }
                                                        else {
                                                            let messagePromises = Array();
                                                            devices.forEach(function (device) {
                                                                let data = {
                                                                    DocumentId: key,
                                                                    Owner: friend.DocumentId,
                                                                    OwnerPhotoPath: friend.PhotoPath,
                                                                    NotificationType: NotificationType.NewFriendOnAura.toString()
                                                                };
                                                                let message = {
                                                                    android: {
                                                                        priority: 'normal',
                                                                        notification: {
                                                                            title: '',
                                                                            body: notificationModel.Message,
                                                                            sound: "default"
                                                                        },
                                                                        data: data
                                                                    },
                                                                    apns: {
                                                                        payload: {
                                                                            aps: {
                                                                                alert: {
                                                                                    title: '',
                                                                                    body: notificationModel.Message,
                                                                                    sound: "default"
                                                                                }
                                                                            },
                                                                            data: data
                                                                        },
                                                                    },
                                                                    token: device.Token
                                                                };
                                                                let messagePromise = new Promise(function (resolve, reject) {
                                                                    app.notification.manager.sendWithCallback(message, function () {
                                                                        resolve();
                                                                    });
                                                                });
                                                                messagePromises.push(messagePromise);
                                                            });

                                                            let messagePromisesResults = Promise.all(messagePromises);
                                                            messagePromisesResults.then(function () {
                                                                resolve();
                                                            }, function (error) {
                                                                reject(error);
                                                            });
                                                        }
                                                    });
                                                });

                                                promises.push(promise);


                                                let results = Promise.all(promises);

                                                results.then(function () {
                                                    resolve();
                                                }, function (error) {
                                                    reject(error);
                                                });
                                            } else {
                                                resolve();
                                            }
                                        }
                                    });
                                }
                            });
                        }
                        else {
                            resolve();
                        }
                    });
                }
            });
        });
    }

    informById(user, friends, provider, callback) {
        const scope = this;
        let viewQuery = couchbase.ViewQuery;
        let query = viewQuery.from('users', 'GetByFacebookID').stale(viewQuery.Update.BEFORE).keys(friends);
        if (provider === 'google') {
            query = viewQuery.from('users', 'GetByGoogleID').stale(viewQuery.Update.BEFORE).keys(friends);
        }
        if (friends && friends.length && friends.length > 0) {
            app.buckets.user.query(query, {}, function (error, result) {
                if (error) {
                    callback(error, null);
                    return;
                }
                else {
                    let settingsDataAccess = new SettingsDataAccess();
                    settingsDataAccess.getById(process.env.SETTINGS_PARAMS_NOTIFICATIONS_NEW_FRIEND_ON_AURA_MESSSAGE, function (response, setting) {
                        if (response) {
                            callback(response, null);
                        }
                        else {
                            if (result && result.length > 0) {
                                let notificationDataAccess = new NotificationDataAccess();
                                let deviceDataAccess = new DeviceDataAccess();
                                let notificationModel = new NotificationModel();
                                notificationModel.NotificationType = NotificationType.NewFriendOnAura;

                                let friends = result;
                                let promises = [];
                                for (let index = 0; index < friends.length; index++) {
                                    let friend = friends[index];
                                    let key = user.DocumentId + '::' + friend.id;
                                    let promise = scope.sendNewFriendOnAura(key, friend.id, notificationModel, user, setting);
                                    promises.push(promise);
                                }
                                var results = Promise.all(promises);

                                results.then(function (data) {
                                    callback(null, {});
                                }, function (err) {
                                    callback(err, null);
                                });
                            } else {
                                callback(null, {});
                            }
                        }
                    });
                }
            });
        } else {
            callback(null, {});
        }
    }

    sendNewFriendOnAura(key, friendId, notificationModel, user, setting) {
        return new Promise(function (resolve, reject) {
            let notificationDataAccess = new NotificationDataAccess();
            let deviceDataAccess = new DeviceDataAccess();
            app.buckets.user.get(friendId, function (error, friend) {
                if (error) {
                    reject(error);
                } else {
                    friend = friend.value;
                    notificationModel.Message = format(setting.Value, user.Fullname, user.Username);
                    notificationModel.UserFriendId = friend.DocumentId;

                    //get all device...
                    deviceDataAccess.getByOwnerId(user.DocumentId, friend.DocumentId, NotificationType.NewFriendOnAura, function (response, devices) {
                        if (response) {
                            reject(error);
                        }
                        else {
                            if (devices.length !== 0) {
                                let promises = Array();
                                notificationModel.DocumentId = "nf::" + key;
                                notificationModel.OwnerId = friend.DocumentId;
                                let promise = new Promise(function (resolve, reject) {
                                    notificationDataAccess.save(notificationModel, function (error, notification) {
                                        if (error) {
                                            reject(error);
                                        }
                                        else {
                                            let messagePromises = Array();
                                            devices.forEach(function (device) {
                                                let data = {
                                                    DocumentId: key,
                                                    Owner: friend.DocumentId,
                                                    OwnerPhotoPath: friend.PhotoPath,
                                                    NotificationType: NotificationType.NewFriendOnAura.toString()
                                                };
                                                let message = {
                                                    android: {
                                                        priority: 'normal',
                                                        notification: {
                                                            title: '',
                                                            body: notificationModel.Message,
                                                            sound: "default"
                                                        },
                                                        data: data
                                                    },
                                                    apns: {
                                                        payload: {
                                                            aps: {
                                                                alert: {
                                                                    title: '',
                                                                    body: notificationModel.Message,
                                                                    sound: "default"
                                                                }
                                                            },
                                                            data: data
                                                        },
                                                    },
                                                    token: device.Token
                                                };
                                                let messagePromise = new Promise(function (resolve, reject) {
                                                    app.notification.manager.sendWithCallback(message, function () {
                                                        resolve();
                                                    });
                                                });
                                                messagePromises.push(messagePromise);
                                            });

                                            let messagePromisesResults = Promise.all(messagePromises);

                                            messagePromisesResults.then(function () {
                                                resolve();
                                            }, function (error) {
                                                reject(error);
                                            });
                                        }
                                    });
                                });
                                promises.push(promise);

                                let results = Promise.all(promises);
                                results.then(function () {
                                    resolve();
                                }, function (error) {
                                    reject(error);
                                });

                            } else {
                                resolve();
                            }
                        }
                    });
                }
            });
        });
    }

    followUserById(currentUser, friend, callback) {
        app.buckets.user.get(friend, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                friend = result.value;
                if (friend) {
                    let provider = 'facebook';
                    if (friend.Facebook) {
                        provider = 'facebook';
                    }
                    else {
                        provider = 'google';
                    }
                    let key = currentUser.DocumentId + '::' + friend.DocumentId;//+ '::' + provider;

                    app.buckets.userfriends.get(key, function (error, result) {
                        let isNotKeyExist = false;
                        if (error && error.code === 13) {
                            isNotKeyExist = true;
                        }
                        if (!isNotKeyExist && error) {
                            callback(error, null);
                            return;
                        }
                        if (isNotKeyExist) {

                            let doc = new UserFriendModel();
                            doc.DocumentId = key;
                            doc.OwnerDocumentId = currentUser.DocumentId;
                            doc.OwnerFullname = currentUser.Fullname;
                            doc.OwnerUsername = currentUser.Username;
                            doc.OwnerPhotoPath = currentUser.PhotoPath;
                            doc.Provider = provider;
                            doc.FriendDocumentId = friend.DocumentId;
                            doc.FriendFullname = friend.Fullname;
                            doc.FriendUsername = friend.Username;
                            doc.FriendPhotoPath = friend.PhotoPath;

                            app.buckets.userfriends.upsert(key, doc, function (error, result) {
                                if (error) {
                                    callback(error, null);
                                    return;
                                }
                                else {
                                    let query = N1qlQuery.fromString('UPDATE `users` USE KEYS ($1)  SET Following = (select raw count(*)  from userfriends where OwnerDocumentId = ($1))[0] ;');
                                    query.consistency(couchbase.N1qlQuery.Consistency.REQUEST_PLUS);
                                    app.buckets.user.query(query, [currentUser.DocumentId], function (error, result) {
                                        if (error) {
                                            callback(error, null);
                                            return;
                                        }
                                        else {
                                            let query = N1qlQuery.fromString('UPDATE `users` USE KEYS ($1)  SET Followers = (select raw count(*)  from userfriends where FriendDocumentId = ($1))[0] ;');
                                            query.consistency(couchbase.N1qlQuery.Consistency.REQUEST_PLUS);
                                            app.buckets.user.query(query, [friend.DocumentId], function (error, result) {
                                                if (error) {
                                                    callback(error, null);
                                                    return;
                                                }
                                                else {
                                                    callback(null, "");
                                                }
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
                else {
                    callback("Eklemek istediğiniz kullanıcı bulunamadı.", null);
                }
            }
        });

    }

    isFollowedUserById(documentId, friend, callback) {
        app.buckets.user.get(friend, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                friend = result.value;
                if (friend) {
                    let provider = 'facebook';
                    if (friend.Facebook) {
                        provider = 'facebook';
                    }
                    else {
                        provider = 'google';
                    }
                    let key = documentId + '::' + friend.DocumentId;// + '::' + provider;

                    let query = N1qlQuery.fromString('select b.* FROM `userfriends` b where META(b).id = ($1)');
                    app.buckets.user.query(query, [key], function (error, result) {
                        if (error) {
                            callback(error, null);
                            return;
                        }
                        callback(null, result);
                    });
                }
                else {
                    callback("Eklemek istediğiniz kullanıcı bulunamadı.", null);
                }
            }
        });

    }

    unfollowUserById(documentId, friend, callback) {
        app.buckets.user.get(friend, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                friend = result.value;
                if (friend) {
                    let provider = 'facebook';
                    if (friend.Facebook) {
                        provider = 'facebook';
                    }
                    else {
                        provider = 'google';
                    }
                    let key = documentId + '::' + friend.DocumentId;//+ '::' + provider;

                    let query = N1qlQuery.fromString('DELETE FROM `userfriends` b where META(b).id = ($1)');
                    app.buckets.user.query(query, [key], function (error, result) {
                        if (error) {
                            callback(error, null);
                            return;
                        } else {
                            let query = N1qlQuery.fromString('UPDATE `users` USE KEYS ($1)  SET Following = (select raw count(*)  from userfriends where OwnerDocumentId = ($1))[0] ;');
                            query.consistency(couchbase.N1qlQuery.Consistency.REQUEST_PLUS);
                            app.buckets.user.query(query, [documentId], function (error, uresult) {
                                if (error) {
                                    callback(error, null);
                                    return;
                                }
                                else {
                                    let query = N1qlQuery.fromString('UPDATE `users` USE KEYS ($1)  SET Followers = (select raw count(*)  from userfriends where FriendDocumentId = ($1))[0] ;');
                                    query.consistency(couchbase.N1qlQuery.Consistency.REQUEST_PLUS);
                                    app.buckets.user.query(query, [friend.DocumentId], function (error, uresult) {
                                        if (error) {
                                            callback(error, null);
                                            return;
                                        }
                                        else {
                                            callback(null, result);
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
                else {
                    callback("Eklemek istediğiniz kullanıcı bulunamadı.", null);
                }
            }
        });

    }

    removeFriendsById(documentId, callback) {
        let query = N1qlQuery.fromString('DELETE FROM `userfriends` b where META(b).id = ($1)');
        app.buckets.userfriends.query(query, [documentId], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result);
        });
    }

    updateMetadataById(documentId, fullname, shortBiography, photoPath, callback) {
        let queryString = "UPDATE " + super.TableName + "  USE KEYS($1) SET ";
        let params = [documentId];
        if (fullname) {
            params.push(fullname);
            if (params.length > 2) {
                queryString += " , ";
            }
            queryString += " Fullname  = $" + params.length;
        }
        if (shortBiography) {
            params.push(shortBiography);
            if (params.length > 2) {
                queryString += " , ";
            }
            queryString += " ShortBiography  = $" + params.length;
        }
        if (photoPath) {
            params.push(photoPath);
            if (params.length > 2) {
                queryString += " , ";
            }
            queryString += " PhotoPath  = $" + params.length;
        }
        let query = N1qlQuery.fromString(queryString);
        app.buckets.user.query(query, params, function (error, rows, meta) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                callback(null, meta);
            }
        });
    }

    decreaseCheckInCount(documentId, callback) {
        let query = N1qlQuery.fromString('UPDATE  ' + super.TableName + ' USE KEYS ($1)  SET CheckInCount = CheckInCount - 1');
        app.buckets.user.query(query, [documentId], function (error, result) {
            if (error) {
                if (callback)
                    callback(error, null);
                return;
            }
            else {
                if (callback)
                    callback(null, result);
                return;
            }
        });
    }

    decreaseAuraCount(documentId, callback) {
        let query = N1qlQuery.fromString('UPDATE  ' + super.TableName + ' USE KEYS ($1)  SET AuraCount = AuraCount - 1');
        app.buckets.user.query(query, [documentId], function (error, result) {
            if (error) {
                if (callback)
                    callback(error, null);
                return;
            }
            else {
                if (callback)
                    callback(null, result);
                return;
            }
        });
    }

    increaseAuraCount(documentId, callback) {
        let query = N1qlQuery.fromString('UPDATE  ' + super.TableName + ' USE KEYS ($1)  SET AuraCount = AuraCount + 1');
        app.buckets.user.query(query, [documentId], function (error, result) {
            if (error) {
                if (callback)
                    callback(error, null);
                return;
            }
            else {
                if (callback)
                    callback(null, result);
                return;
            }
        });
    }

    getByName(filter, callback) {
        let viewQuery = couchbase.ViewQuery;
        filter.Title = filter.Title + "%";
        let query = N1qlQuery.fromString('select u.DocumentId as Id , u.Fullname , u.PhotoPath, u.Type, u.Username, u.Title, u.Location,u.Address from  `'
            + super.TableName + '` u  where  u.IsActive = true and  '
            + ' meta().id not in (SELECT RAW us.OwnerId FROM `usersettings` us WHERE us.Type = "blockeduser" and us.BlockedUserId = $1) '
            + ' and ((u.Username is not null  and u.Type="user") or u.Type = "venue") and ' +
            ' (lower (u.Fullname) like lower ("' + filter.Title + '") or lower (u.Username) like lower ("' + filter.Title + '") or lower (u.Title) like lower ("' + filter.Title + '") ) limit 20');
        app.buckets.user.query(query, [filter.CurrentUser], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result);
        });
    }

    getByCity(filter, callback) {
        let viewQuery = couchbase.ViewQuery;
        filter.Title = filter.Title + "%";
        let query = N1qlQuery.fromString('select u.DocumentId as Id , u.Fullname , u.PhotoPath, u.Type, u.Username, u.Title, u.Location,u.Address from  `' + super.TableName + '` u  where  u.IsActive = true and (lower(u.City) like lower ("' + filter.Title + '")) and  Type="venue"  limit 20');
        app.buckets.user.query(query, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result);
        });
    }

    getUserFollowers(filter, callback) {
        let query = N1qlQuery.fromString('select raw s.Status from settings s where meta().id = $1  and s.Type = "aurasetting"');
        app.buckets.settings.query(query, ["as::" + filter.User + "::" + AuraSettingsType.FollowerFollowingList], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                if (result && result.length > 0) {
                    let setting = result[0];
                    if (setting == PushNotificationSettingStatus.Everyone || filter.CurrentUser == filter.User) {
                        let queryString = '  select uf.*, auf IS NOT NULL as IsFollowed ' +
                            ' from userfriends uf ' +
                            ' left join userfriends auf  ON KEYS "' + filter.User + '::"||uf.FriendDocumentId ' +
                            ' where  uf.FriendDocumentId = $1  and uf.Type="friend" ' +
                            ' order by lower(uf.OwnerFullname)  limit $2 offset $3 ';
                        let query = N1qlQuery.fromString(queryString);
                        app.buckets.userfriends.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex], function (error, results) {
                            if (error) {
                                callback(error, null);
                                return;
                            }
                            if (results.length > 0) {
                                callback(null, results);
                            } else {
                                callback(null, null);
                            }
                        });
                    }
                    else {
                        //profile active user follow ediyormu?
                        let key = filter.User + '::' + filter.CurrentUser;
                        query = N1qlQuery.fromString('select * from userfriends uf where  meta().id = $1 and uf.Type = "friend" ');
                        app.buckets.settings.query(query, [key], function (error, result) {
                            if (error) {
                                callback(error, null);
                                return;
                            }
                            else {
                                if (result.length <= 0) {
                                    callback(null, []);
                                } else {
                                    let queryString = '  select uf.*, auf IS NOT NULL as IsFollowed ' +
                                        ' from userfriends uf ' +
                                        ' left join userfriends auf  ON KEYS "' + filter.User + '::"||uf.FriendDocumentId ' +
                                        ' where  uf.FriendDocumentId = $1  and uf.Type="friend" ' +
                                        ' order by lower(uf.OwnerFullname)  limit $2 offset $3 ';
                                    let query = N1qlQuery.fromString(queryString);
                                    app.buckets.userfriends.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex], function (error, results) {
                                        if (error) {
                                            callback(error, null);
                                            return;
                                        }
                                        if (results.length > 0) {
                                            callback(null, results);
                                        } else {
                                            callback(null, null);
                                        }
                                    });
                                }
                            }
                        });
                    }
                }
                else if (result && result.length === 0) {
                    let queryString = '  select uf.*, auf IS NOT NULL as IsFollowed ' +
                        ' from userfriends uf ' +
                        ' left join userfriends auf  ON KEYS "' + filter.User + '::"||uf.FriendDocumentId ' +
                        ' where  uf.FriendDocumentId = $1  and uf.Type="friend" ' +
                        ' order by lower(uf.OwnerFullname)  limit $2 offset $3 ';
                    let query = N1qlQuery.fromString(queryString);
                    app.buckets.userfriends.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex], function (error, results) {
                        if (error) {
                            callback(error, null);
                            return;
                        }
                        if (results.length > 0) {
                            callback(null, results);
                        } else {
                            callback(null, null);
                        }
                    });
                }
                else {
                    callback(null, []);
                }
            }
        });
    }

    getUserFollowings(filter, callback) {
        let query = N1qlQuery.fromString('select raw s.Status from settings s where meta().id = $1  and s.Type = "aurasetting"');
        app.buckets.settings.query(query, ["as::" + filter.User + "::" + AuraSettingsType.FollowerFollowingList], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                if (result && result.length > 0) {
                    let setting = result[0];
                    if (setting == PushNotificationSettingStatus.Everyone || filter.CurrentUser == filter.User) {
                        let queryString = '  select uf.*, auf IS NOT NULL as IsFollowed ' +
                            ' from userfriends uf ' +
                            ' left join userfriends auf  ON KEYS "' + filter.User + '::"||uf.FriendDocumentId ' +
                            ' where  uf.OwnerDocumentId = $1 ' +
                            ' order by lower(uf.FriendFullname)  limit $2 offset $3 ';
                        let query = N1qlQuery.fromString(queryString);
                        app.buckets.userfriends.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex], function (error, results) {
                            if (error) {
                                callback(error, null);
                                return;
                            }
                            if (results.length > 0) {
                                callback(null, results);
                            } else {
                                callback(null, null);
                            }
                        });
                    }
                    else {
                        //profile active user follow ediyormu?
                        let key = filter.User + '::' + filter.CurrentUser;
                        query = N1qlQuery.fromString('select * from userfriends uf where  meta().id = $1 and uf.Type = "friend" ');
                        app.buckets.settings.query(query, [key], function (error, result) {
                            if (error) {
                                callback(error, null);
                                return;
                            }
                            else {
                                if (result.length <= 0) {
                                    callback(null, []);
                                } else {
                                    let queryString = '  select uf.*, auf IS NOT NULL as IsFollowed ' +
                                        ' from userfriends uf ' +
                                        ' left join userfriends auf  ON KEYS "' + filter.User + '::"||uf.FriendDocumentId ' +
                                        ' where  uf.OwnerDocumentId = $1 ' +
                                        ' order by lower(uf.FriendFullname)  limit $2 offset $3 ';
                                    let query = N1qlQuery.fromString(queryString);
                                    app.buckets.userfriends.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex], function (error, results) {
                                        if (error) {
                                            callback(error, null);
                                            return;
                                        }
                                        if (results.length > 0) {
                                            callback(null, results);
                                        } else {
                                            callback(null, null);
                                        }
                                    });
                                }
                            }
                        });
                    }
                }
                else if (result && result.length === 0) {
                    let queryString = '  select uf.*, auf IS NOT NULL as IsFollowed ' +
                        ' from userfriends uf ' +
                        ' left join userfriends auf  ON KEYS "' + filter.User + '::"||uf.FriendDocumentId ' +
                        ' where  uf.OwnerDocumentId = $1 ' +
                        ' order by lower(uf.FriendFullname)  limit $2 offset $3 ';
                    let query = N1qlQuery.fromString(queryString);
                    app.buckets.userfriends.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex], function (error, results) {
                        if (error) {
                            callback(error, null);
                            return;
                        }
                        if (results.length > 0) {
                            callback(null, results);
                        } else {
                            callback(null, null);
                        }
                    });
                } else {
                    callback(null, []);
                }
            }
        });
    }

    deactive(documentId, callback) {
        let query = N1qlQuery.fromString('UPDATE ' + super.TableName + ' USE KEYS ($1)  SET IsActive = false');
        app.buckets.user.query(query, [documentId], function (error, rows, meta) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                callback(null, meta);
            }
        });
    }

    active(documentId, callback) {
        let query = N1qlQuery.fromString('UPDATE ' + super.TableName + ' USE KEYS ($1)  SET IsActive = true');
        app.buckets.user.query(query, [documentId], function (error, rows, meta) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                callback(null, meta);
            }
        });
    }

    getVenueDetailById(currentUserId, venueId, callback) {
        let queryString = '  select u.*, uf IS NOT NULL as IsStarred ' +
            ' from users u ' +
            ' left join userfriends uf  ON KEYS "' + currentUserId + '::"|| u.DocumentId ' +
            ' where  u.DocumentId = $1 ';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.userfriends.query(query, [venueId], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            if (results && results.length > 0) {
                callback(null, results[0]);
            } else {
                callback(null, null);
            }
        });
    }

    getAllUser(callback) {
        let queryString = 'select u.* from users u where u.Type="user" and u.IsWebUser = true ';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.user.query(query, [], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, results);
        });
    }
}

module.exports = UserDataAccess;
