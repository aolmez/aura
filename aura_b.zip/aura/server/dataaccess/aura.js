'use strict';
const aws = require('aws-sdk');
const async = require("async");
const uuid = require('uuid/v4');
const turf = require('@turf/turf');
const BaseModel = require('./basemodel');
const BaseObject = require('./baseobject');
const BaseObjectType = require('./baseobjecttype');
const Helper = require("../models/helper");
const couchbase = require("couchbase");
const app = require("../../app");
const N1qlQuery = require('couchbase').N1qlQuery;
const AuraSettingsType = require('../models/aurasettingtype');
const PushNotificationSettingStatus = require('../models/pushnotificationsettingstatus');

class AuraDataAccess extends BaseModel {
    constructor() {
        super('auras');
    }

    save(model, callback) {
        model.DocumentId = model.DocumentId ? model.DocumentId : uuid.v4();
        app.buckets.aura.upsert(model.DocumentId, model, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, model);
        });
    }

    getById(id, callback) {
        app.buckets.aura.get(id, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result.value);
        });
    }

    getStarVenuePaged(filter, callback) {
        let scope = this;
        let queryString = 'SELECT a.*, al IS NOT NULL as IsLiked,alw  IS NOT NULL as IsWatched, u.CheckInCount ' +
            ' FROM `auras` a LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `auralikers` alw ON KEYS "w::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `users` u ON KEYS  a.VenueId ' +
            ' WHERE a.IsActive = true AND a.ShareType = 0 AND a.CreatedAt > $4 ' +
            ' AND a.VenueId  in (SELECT  RAW uf.FriendDocumentId FROM `userfriends` uf where uf.OwnerDocumentId = $1 and uf.Type =  "starVenue") ' +
            ' order by a.CreatedAt desc limit $2 offset $3;';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.aura.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex, Helper.getTickWithParam(parseInt(process.env.AURA_TIMECONTROL_MAXHOUR))], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            scope.getRelationalAurasWithVenueId(filter, results).then(function (results) {
                callback(error, results);
            }).catch(function (error) {
                callback(error, results);
            });
        });
    }

    getDetailById(filter, callback) {
        let scope = this;
        let queryString = 'SELECT a.*, al IS NOT NULL as IsLiked,alw  IS NOT NULL as IsWatched, u.CheckInCount ' +
            ' FROM `' + super.TableName + '` a LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `auralikers` alw ON KEYS "w::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `users` u ON KEYS  a.VenueId ' +
            ' WHERE a.IsActive = true  and a.DocumentId = $1;';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.aura.query(query, [filter.AuraDocumentId], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            scope.getRelationalAurasWithVenueId(filter, results).then(function (results) {
                callback(error, results);
            }).catch(function (error) {
                callback(error, results);
            });
        });
    }

    getPaged(filter, callback) {
        let scope = this;
        let queryString = 'SELECT a.*, al IS NOT NULL as IsLiked,alw  IS NOT NULL as IsWatched, u.CheckInCount ' +
            ' FROM `' + super.TableName + '` a LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `auralikers` alw ON KEYS "w::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `users` u ON KEYS  a.VenueId ' +
            ' WHERE a.IsActive = true  AND a.ShareType = 0 AND a.CreatedAt > $4 ' +
            ' AND a.Owner not in (SELECT RAW us.OwnerId FROM `usersettings` us WHERE us.Type = "blockeduser" and us.BlockedUserId = $1) ' +
            ' AND (a.Owner IN (SELECT RAW FriendDocumentId FROM `userfriends` WHERE OwnerDocumentId = $1 and Type = "friend" )or a.Owner =  $1) ' +
            ' order by a.CreatedAt desc limit $2 offset $3;';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.aura.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex, Helper.getTickWithParam(parseInt(process.env.AURA_TIMECONTROL_MAXHOUR))], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            scope.getRelationalAurasWithVenueId(filter, results).then(function (results) {
                callback(error, results);
            }).catch(function (error) {
                callback(error, results);
            });
        });
    }

    /*
    * Private met
    */
    getRelationalAurasWithVenueId(filter, results) {
        return new Promise(function (resolve, reject) {
            try {
                let promises = Array();
                for (let index = 0; index < results.length; index++) {
                    let item = results[index];
                    let promise = new Promise(function (innerResolve, innerReject) {
                        let mainItem = item;
                        let queryString = 'SELECT a.*, al IS NOT NULL as IsLiked FROM `auras` a LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.User + '" ' +
                            ' WHERE a.IsActive = true AND a.ShareType = 0 AND a.CreatedAt > $4 AND a.VenueId = $5 AND a.DocumentId != $6 AND (a.Owner IN (SELECT RAW FriendDocumentId FROM `userfriends` WHERE OwnerDocumentId = $1 and Type = "friend"  )or a.Owner =  $1) order by a.CreatedAt desc limit $2 offset $3;';
                        let query = N1qlQuery.fromString(queryString);
                        app.buckets.aura.query(query,
                            [filter.User,
                                2,
                                0,
                                Helper.getTickWithParam(parseInt(process.env.AURA_TIMECONTROL_MAXHOUR)),
                                item.VenueId,
                                item.DocumentId],
                            function (error, results) {
                                if (error) {
                                    innerReject(error);
                                } else {
                                    mainItem.InnerAuras = results;
                                    let queryString = 'SELECT count(a.DocumentId) as TotalCount  FROM `auras` a LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.User + '" ' +
                                        ' WHERE a.IsActive = true AND a.ShareType = 0 AND a.CreatedAt > $4 AND a.VenueId = $5  AND (a.Owner IN (SELECT RAW FriendDocumentId FROM `userfriends` WHERE OwnerDocumentId = $1 and Type = "friend" )or a.Owner =  $1);';
                                    let query = N1qlQuery.fromString(queryString);
                                    app.buckets.aura.query(query,
                                        [filter.User,
                                            2,
                                            0,
                                            Helper.getTickWithParam(parseInt(process.env.AURA_TIMECONTROL_MAXHOUR)),
                                            item.VenueId],
                                        function (error, results) {
                                            if (error) {
                                                innerReject(error);
                                            } else {
                                                let totalCount = 0;
                                                if (results && results.length && results.length > 0) {
                                                    totalCount = results[0].TotalCount;
                                                }
                                                mainItem.TotalCount = totalCount;
                                                innerResolve(mainItem);
                                            }
                                        });
                                }
                            });
                    });
                    promises.push(promise);
                }
                Promise.all(promises).then(function (results) {
                    resolve(results);
                }).catch(function (error) {
                    reject(error);
                });
            } catch (error) {
                reject(error);
            }
        });
    }

    getPagedNearBy(filter, callback) {
        let scope = this;
        let queryString = 'SELECT a.*, al IS NOT NULL as IsLiked, u.CheckInCount, ' +
            ' (acos(sin( RADIANS($5)) * sin (RADIANS(a.Location.latitude)) + ' +
            ' cos( RADIANS($5))  * cos(RADIANS(a.Location.latitude)) * ' +
            ' cos (RADIANS(a.Location.longitude) - RADIANS($6))) * 6371)  Distance ' +
            ' FROM `' + super.TableName + '` a LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `users` u ON KEYS  a.VenueId ' +
            ' WHERE a.IsActive = true  AND a.ShareType = 0 AND a.CreatedAt > $4 ' +
            ' AND a.Owner not in (SELECT RAW us.OwnerId FROM `usersettings` us WHERE us.Type = "blockeduser" and us.BlockedUserId = $1) ' +
            ' AND (acos(sin( RADIANS($5)) * sin (RADIANS(a.Location.latitude)) + ' +
            ' cos( RADIANS($5))  * cos(RADIANS(a.Location.latitude)) * ' +
            ' cos (RADIANS(a.Location.longitude) - RADIANS($6))) * 6371)  < 7500 ' +
            ' order by Distance limit $2 offset $3;';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.aura.query(query, [filter.User,
            filter.PageSize,
            filter.PageSize * filter.PageIndex,
            Helper.getTickWithParam(parseInt(process.env.AURA_TIMECONTROL_ONE_WEEK_AGO)),
            filter.Latitude,
            filter.Longitude
        ], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            scope.getRelationalAurasWithVenueId(filter, results).then(function (results) {
                callback(error, results);
            }).catch(function (error) {
                callback(error, results);
            });
        });
    }

    like(documentId, like, callback) {
        app.buckets.auralikers.get(like.DocumentId, function (error, result) {
            let isNotKeyExist = false;
            if (error && error.code === 13) {
                isNotKeyExist = true;
            }
            if (!isNotKeyExist && error) {
                callback(error, null);
                return;
            }
            if (isNotKeyExist) {
                app.buckets.auralikers.upsert(like.DocumentId, like, function (error, result) {
                    if (error) {
                        callback(error, null);
                        return;
                    }
                    else {
                        let query = N1qlQuery.fromString('UPDATE `auras` USE KEYS ($1)  SET LikeCount = (select raw count(*)  from auralikers where Type = "liker" and AuraDocumentId = ($1))[0] RETURNING LikeCount;');
                        query.consistency(couchbase.N1qlQuery.Consistency.REQUEST_PLUS);
                        app.buckets.aura.query(query, [documentId], function (error, result) {
                            if (error) {
                                callback(error, null);
                                return;
                            }
                            else {
                                callback(null, result[0].LikeCount);
                            }
                        });
                    }
                });
            }
            else {
                let query = N1qlQuery.fromString('select a.LikeCount from `auras` a USE KEYS ($1);');
                app.buckets.aura.query(query, [documentId], function (error, result) {
                    if (error) {
                        callback(error, null);
                        return;
                    }
                    else {
                        callback(null, result[0].LikeCount);
                    }
                });
            }
        });
    }

    unlike(documentId, like, callback) {
        app.buckets.auralikers.remove(like.DocumentId, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            let query = N1qlQuery.fromString('UPDATE `auras` USE KEYS ($1)  SET LikeCount = (select raw count(*)  from auralikers where Type = "liker" and AuraDocumentId = ($1))[0] RETURNING LikeCount;');
            query.consistency(couchbase.N1qlQuery.Consistency.REQUEST_PLUS);
            app.buckets.aura.query(query, [documentId], function (error, result) {
                if (error) {
                    callback(error, null);
                    return;
                }
                else {
                    callback(null, result[0].LikeCount);
                }
            });
        });
    }

    increaseViewerCount(documentId, like, callback) {
        app.buckets.auralikers.get(like.DocumentId, function (error, result) {
            let isNotKeyExist = false;
            if (error && error.code === 13) {
                isNotKeyExist = true;
            }
            if (!isNotKeyExist && error) {
                callback(error, null);
                return;
            }
            if (isNotKeyExist) {
                app.buckets.auralikers.upsert(like.DocumentId, like, function (error, result) {
                    if (error) {
                        callback(error, null);
                        return;
                    }
                    else {
                        let query = N1qlQuery.fromString('UPDATE `auras` USE KEYS ($1)  SET ViewerCount  = (select raw count(*)  from auralikers where Type = "watcher" and AuraDocumentId = ($1))[0]  RETURNING ViewerCount;');
                        query.consistency(couchbase.N1qlQuery.Consistency.REQUEST_PLUS);
                        app.buckets.aura.query(query, [documentId], function (error, result) {
                            if (error) {
                                callback(error, null);
                                return;
                            }
                            else {
                                callback(null, result[0].ViewerCount);
                            }
                        });
                    }
                });
            } else {
                let query = N1qlQuery.fromString('select a.ViewerCount from `auras` a USE KEYS ($1);');
                app.buckets.aura.query(query, [documentId], function (error, result) {
                    if (error) {
                        callback(error, null);
                        return;
                    }
                    else {
                        callback(null, result[0].ViewerCount);
                    }
                });
            }
        });
    }

    getByOwner(filter, callback) {
        let scope = this;
        let queryString = 'SELECT a.*, al IS NOT NULL as IsLiked,alw  IS NOT NULL as IsWatched, u.CheckInCount ' +
            ' FROM `' + super.TableName + '` a LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `auralikers` alw ON KEYS "w::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `users` u ON KEYS  a.VenueId ' +
            ' WHERE a.IsActive = true  AND a.ShareType = 0 AND a.CreatedAt > $4 AND a.Owner =  $1 ' +
            ' order by a.CreatedAt desc limit $2 offset $3;';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.aura.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex, Helper.getTickWithParam(parseInt(process.env.AURA_TIMECONTROL_MAXHOUR))], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            scope.getRelationalAurasWithVenueId(filter, results).then(function (results) {
                callback(error, results);
            }).catch(function (error) {
                callback(error, results);
            });
        });
    }

    getCoordinateByOwner(filter, callback) {
        let query = N1qlQuery.fromString('select raw s.Status from settings s where meta().id = $1  and s.Type = "aurasetting"');
        app.buckets.settings.query(query, ["as::" + filter.User + "::" + AuraSettingsType.MyMap], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                if (result && result.length > 0) {
                    let setting = result[0];
                    if (setting == PushNotificationSettingStatus.Everyone || filter.CurrentUser == filter.User) {
                        let viewQuery = couchbase.ViewQuery;
                        let query = viewQuery.from('auras', 'GetCoordinateByOwner')
                            .stale(viewQuery.Update.BEFORE)
                            .key(filter.User)
                            .skip(filter.PageSize * filter.PageIndex)
                            .limit(filter.PageSize)
                            .order(couchbase.ViewQuery.Order.DESCENDING);
                        app.buckets.aura.query(query, function (error, result) {
                            if (error) {
                                callback(error, null);
                                return;
                            }
                            if (result.length > 0) {
                                callback(null, result);
                            } else {
                                callback(null, null);
                            }
                        });
                    } else {
                        let key = filter.User + '::' + filter.CurrentUser;
                        query = N1qlQuery.fromString('select * from userfriends uf where  meta().id = $1 and uf.Type = "friend" ');
                        app.buckets.settings.query(query, [key], function (error, result) {
                            if (error) {
                                callback(error, null);
                                return;
                            }
                            else {
                                if (result.length <= 0) {
                                    callback(null, []);
                                } else {
                                    let viewQuery = couchbase.ViewQuery;
                                    let query = viewQuery.from('auras', 'GetCoordinateByOwner')
                                        .stale(viewQuery.Update.BEFORE)
                                        .key(filter.User)
                                        .skip(filter.PageSize * filter.PageIndex)
                                        .limit(filter.PageSize)
                                        .order(couchbase.ViewQuery.Order.DESCENDING);
                                    app.buckets.aura.query(query, function (error, result) {
                                        if (error) {
                                            callback(error, null);
                                            return;
                                        }
                                        if (result.length > 0) {
                                            callback(null, result);
                                        } else {
                                            callback(null, null);
                                        }
                                    });
                                }
                            }
                        });
                    }
                }
                else if (result && result.length === 0) {
                    let viewQuery = couchbase.ViewQuery;
                    let query = viewQuery.from('auras', 'GetCoordinateByOwner')
                        .stale(viewQuery.Update.BEFORE)
                        .key(filter.User)
                        .skip(filter.PageSize * filter.PageIndex)
                        .limit(filter.PageSize)
                        .order(couchbase.ViewQuery.Order.DESCENDING);
                    app.buckets.aura.query(query, function (error, result) {
                        if (error) {
                            callback(error, null);
                            return;
                        }
                        if (result.length > 0) {
                            callback(null, result);
                        } else {
                            callback(null, null);
                        }
                    });
                }
                else {
                    callback(null, []);
                }
            }
        });
    }

    getByVenueId(filter, callback) {
        let scope = this;
        let queryString = 'SELECT a.*, al IS NOT NULL as IsLiked,alw  IS NOT NULL as IsWatched, u.CheckInCount ' +
            ' FROM `' + super.TableName + '` a LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `auralikers` alw ON KEYS "w::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `users` u ON KEYS  a.VenueId ' +
            ' WHERE a.IsActive = true AND a.ShareType = 0  AND a.CreatedAt > $4 AND a.VenueId =  $1 ' +
            ' order by a.CreatedAt desc limit $2 offset $3;';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.aura.query(query, [filter.VenueId, filter.PageSize, filter.PageSize * filter.PageIndex, Helper.getTickWithParam(parseInt(process.env.AURA_TIMECONTROL_MAXHOUR))], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            scope.getRelationalAurasWithVenueId(filter, results).then(function (results) {
                callback(error, results);
            }).catch(function (error) {
                callback(error, results);
            });
        });
    }

    getByUser(filter, callback) {
        let scope = this;
        let settingQuery = N1qlQuery.fromString('select raw s.Status from settings s where meta().id = $1  and s.Type = "aurasetting"');
        app.buckets.settings.query(settingQuery, ["as::" + filter.User + "::" + AuraSettingsType.RecentAurasOnProfile], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                if (result && result.length > 0) {
                    let setting = result[0];
                    if (setting == PushNotificationSettingStatus.Everyone || filter.User == filter.CurrentUser) {
                        let queryString = 'SELECT a.*, al IS NOT NULL as IsLiked,alw  IS NOT NULL as IsWatched, u.CheckInCount ' +
                            ' FROM `auras` a LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.CurrentUser + '" ' +
                            ' LEFT JOIN `auralikers` alw ON KEYS "w::"||a.DocumentId||"::' + filter.CurrentUser + '" ' +
                            ' LEFT JOIN `users` u ON KEYS  a.VenueId ' +
                            ' WHERE a.IsActive = true  AND a.ShareType = 0 AND a.CreatedAt > $4 AND a.Owner =  $1 ' +
                            ' order by a.CreatedAt desc limit $2 offset $3;';
                        let query = N1qlQuery.fromString(queryString);
                        app.buckets.aura.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex, Helper.getTickWithParam(parseInt(process.env.AURA_TIMECONTROL_MAXHOUR))], function (error, results) {
                            if (error) {
                                callback(error, null);
                                return;
                            }
                            scope.getRelationalAurasWithVenueId(filter, results).then(function (results) {
                                callback(error, results);
                            }).catch(function (error) {
                                callback(error, results);
                            });
                        });
                    }
                    else {
                        //profile active user follow ediyormu?
                        let key = filter.User + '::' + filter.CurrentUser;
                        let query = N1qlQuery.fromString('select * from userfriends uf where  meta().id = $1 and uf.Type = "friend" ');
                        app.buckets.settings.query(query, [key], function (error, result) {
                            if (error) {
                                callback(error, null);
                                return;
                            }
                            else {
                                if (result.length <= 0) {
                                    callback(null, []);
                                } else {
                                    let queryString = 'SELECT a.*, al IS NOT NULL as IsLiked,alw  IS NOT NULL as IsWatched, u.CheckInCount ' +
                                        ' FROM `auras` a LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.CurrentUser + '" ' +
                                        ' LEFT JOIN `auralikers` alw ON KEYS "w::"||a.DocumentId||"::' + filter.CurrentUser + '" ' +
                                        ' LEFT JOIN `users` u ON KEYS  a.VenueId ' +
                                        ' WHERE a.IsActive = true  AND a.ShareType = 0 AND a.CreatedAt > $4 AND a.Owner =  $1 ' +
                                        ' order by a.CreatedAt desc limit $2 offset $3;';
                                    let query = N1qlQuery.fromString(queryString);
                                    app.buckets.aura.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex, Helper.getTickWithParam(parseInt(process.env.AURA_TIMECONTROL_MAXHOUR))], function (error, results) {
                                        if (error) {
                                            callback(error, null);
                                            return;
                                        }
                                        scope.getRelationalAurasWithVenueId(filter, results).then(function (results) {
                                            callback(error, results);
                                        }).catch(function (error) {
                                            callback(error, results);
                                        });
                                    });
                                }
                            }
                        });
                    }
                }
                else if (result && result.length === 0) {
                    let queryString = 'SELECT a.*, al IS NOT NULL as IsLiked,alw  IS NOT NULL as IsWatched, u.CheckInCount ' +
                        ' FROM `auras` a LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.CurrentUser + '" ' +
                        ' LEFT JOIN `auralikers` alw ON KEYS "w::"||a.DocumentId||"::' + filter.CurrentUser + '" ' +
                        ' LEFT JOIN `users` u ON KEYS  a.VenueId ' +
                        ' WHERE a.IsActive = true  AND a.ShareType = 0 AND a.CreatedAt > $4 AND a.Owner =  $1 ' +
                        ' order by a.CreatedAt desc limit $2 offset $3;';
                    let query = N1qlQuery.fromString(queryString);
                    app.buckets.aura.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex, Helper.getTickWithParam(parseInt(process.env.AURA_TIMECONTROL_MAXHOUR))], function (error, results) {
                        if (error) {
                            callback(error, null);
                            return;
                        }
                        scope.getRelationalAurasWithVenueId(filter, results).then(function (results) {
                            callback(error, results);
                        }).catch(function (error) {
                            callback(error, results);
                        });
                    });
                }
                else {
                    callback(null, []);
                }
            }
        });
    }

    getExplorePaged(filter, callback) {
        let scope = this;
        let queryString = '   SELECT a.* , al IS NOT NULL as IsLiked,alw  IS NOT NULL as IsWatched, u.CheckInCount  from ( ' +
            ' SELECT  ARRAY_AGG(ia)[Count(ia.DocumentId)-1].* , COUNT(ia.VenueId) as TotalCount ' +
            ' from `' + super.TableName + '` ia where ia.IsActive = true  AND ia.ShareType = 0  ' +
            ' and ia.Owner not in (SELECT RAW us.OwnerId FROM `usersettings` us WHERE us.Type = "blockeduser" and us.BlockedUserId = $1) ' +
            ' and ia.CreatedAt > $4 GROUP BY ia.Title   ' +
            ' order by  COUNT(ia.Title) desc ,Title  limit $2 offset $3  ' +
            ' ) as a  ' +
            ' LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `auralikers` alw ON KEYS "w::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `users` u ON KEYS  a.VenueId ' +
            ' where a.IsActive = true  AND a.ShareType = 0 ' +
            ' and a.Owner not in (SELECT RAW us.OwnerId FROM `usersettings` us WHERE us.Type = "blockeduser" and us.BlockedUserId = $1) ' +
            ' and a.CreatedAt > $4 order by a.TotalCount  desc';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.aura.query(query, [filter.User,
            filter.PageSize,
            filter.PageSize * filter.PageIndex,
            Helper.getTickWithParam(parseInt(process.env.AURA_TIMECONTROL_ONE_WEEK_AGO))], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            scope.getRelationalAurasWithVenueId(filter, results).then(function (results) {
                callback(error, results);
            }).catch(function (error) {
                callback(error, results);
            });
        });
    }

    getCoordinateForMap(filter, callback) {
        let scope = this;
        let queryString = 'SELECT distinct a.VenueId, a.Title, a.DocumentId,a.PhotoPath,a.Author,a.Address,a.Location, al IS NOT NULL as IsLiked, u.CheckInCount, ' +
            ' (acos(sin( RADIANS($5)) * sin (RADIANS(a.Location.latitude)) + ' +
            ' cos( RADIANS($5))  * cos(RADIANS(a.Location.latitude)) * ' +
            ' cos (RADIANS(a.Location.longitude) - RADIANS($6))) * 6371)  Distance ' +
            ' FROM `' + super.TableName + '` a LEFT JOIN `auralikers` al ON KEYS "l::"||a.DocumentId||"::' + filter.User + '" ' +
            ' LEFT JOIN `users` u ON KEYS  a.VenueId ' +
            ' WHERE a.IsActive = true  AND a.ShareType = 0 AND a.CreatedAt > $4 ' +
            ' AND (acos(sin( RADIANS($5)) * sin (RADIANS(a.Location.latitude)) + ' +
            ' cos( RADIANS($5))  * cos(RADIANS(a.Location.latitude)) * ' +
            ' cos (RADIANS(a.Location.longitude) - RADIANS($6))) * 6371)  < ' + filter.Radius +
            ' order by a.CreatedAt desc limit $2 offset $3;';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.aura.query(query, [filter.User,
            filter.PageSize,
            filter.PageSize * filter.PageIndex,
            Helper.getTickWithParam(parseInt(process.env.AURA_TIMECONTROL_MAXHOUR)),
            filter.Latitude,
            filter.Longitude,
            filter.Radius
        ], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(error, results);
        });
    }

    getLikers(filter, callback) {
        let queryString = '  select al.*, auf IS NOT NULL as IsFollowed  from auralikers al   ' +
            '  LEFT JOIN `users` u ON KEYS  al.Owner ' +
            ' left join userfriends auf  ON KEYS "' + filter.User + '::"||al.Owner LET  au = CASE WHEN  auf.Type = "friend" THEN auf ELSE MISSING END ' +
            ' where  u.IsActive = true and al.AuraDocumentId = $1 ' +
            ' and u.DocumentId not in (SELECT RAW us.OwnerId FROM `usersettings` us WHERE us.Type = "blockeduser" and us.BlockedUserId = $4) ' +
            ' and  al.Type = "liker"  ' +
            ' order by al.Fullname  limit $2 offset $3 ';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.auralikers.query(query, [filter.AuraDocumentId, filter.PageSize, filter.PageSize * filter.PageIndex, filter.CurrentUser], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            if (results.length > 0) {
                callback(null, results);
            } else {
                callback(null, null);
            }
        });
    }

    getWatchers(filter, callback) {
        let queryString = '  select al.*, auf IS NOT NULL as IsFollowed  from auralikers al   ' +
            '  LEFT JOIN `users` u ON KEYS  al.Owner ' +
            ' left join userfriends auf  ON KEYS "' + filter.User + '::"||al.Owner LET  au = CASE WHEN  auf.Type = "friend" THEN auf ELSE MISSING END ' +
            ' where  u.IsActive = true and  al.AuraDocumentId = $1 ' +
            ' and u.DocumentId not in (SELECT RAW us.OwnerId FROM `usersettings` us WHERE us.Type = "blockeduser" and us.BlockedUserId = $4) ' +
            ' and  al.Type = "watcher"  ' +
            ' order by al.Fullname  limit $2 offset $3 ';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.auralikers.query(query, [filter.AuraDocumentId, filter.PageSize, filter.PageSize * filter.PageIndex, filter.CurrentUser], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            if (results.length > 0) {
                callback(null, results);
            } else {
                callback(null, null);
            }
        });
    }


    deactiveWithOwnerId(ownerId, callback) {
        let query = N1qlQuery.fromString('UPDATE ' + super.TableName + ' set IsActive = false where Owner=$1 ');
        app.buckets.aura.query(query, [ownerId], function (error, rows, meta) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                callback(null, meta);
            }
        });
    }

    activeWithOwnerId(ownerId, callback) {
        let query = N1qlQuery.fromString('UPDATE ' + super.TableName + 'set IsActive = true where Owner=$1');
        app.buckets.aura.query(query, [ownerId], function (error, rows, meta) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                callback(null, meta);
            }
        });
    }


    delete(key, callback) {
        let query = N1qlQuery.fromString('DELETE FROM  ' + super.TableName + ' a where META(a).id = ($1)');
        app.buckets.aura.query(query, [key], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result);
        });
    }


    deleteByOwnerId(key, ownerId, callback) {
        let query = N1qlQuery.fromString('DELETE FROM  ' + super.TableName + ' a where META(a).id = ($1) and  a.Owner = ($2) ');
        app.buckets.aura.query(query, [key, ownerId], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result);
        });
    }
}

module.exports = AuraDataAccess;
