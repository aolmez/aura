'use strict';
const BaseObjectType = require('./baseobjecttype');

class BaseObject {
    constructor(type, defaultValue) {
        this.mType = type;
        this.mValue = defaultValue;
    }
    get Value() {
        return this.mValue;
    }
    set Value(value) {
        this.mValue = value;
    }
    toString() {
        return 'BaseObject.${this.mValue}';
    }
    isEmpty() {
        let result = true;
        if (this.mValue && this.mValue != '') {
            result = false;
        }
        return result;
    }
    toAWSObject() {
        if (this.mType == BaseObjectType.String) {
            return { S: this.mValue };
        } else if (this.mType == BaseObjectType.Bool) {
            return { BOOL: this.mValue };
        } else if (this.mType == BaseObjectType.Number) {
            return { N: this.mValue.toString() };
        } else if (this.mType == BaseObjectType.List) {
            return { L: this.mValue.toString() };
        } else { return { S: this.mValue }; }
    }
}

module.exports = BaseObject;