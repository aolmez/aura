'use strict';
const aws = require('aws-sdk');
const async = require("async");
const uuid = require('uuid/v4');
const BaseModel = require('./basemodel');
const BaseObject = require('./baseobject');
const BaseObjectType = require('./baseobjecttype');
const VenueUserModel = require('../models/venueusermodel');
const atomicCounter = require('dynamodb-atomic-counter');
const couchbase = require("couchbase");
const app = require("../../app");
const N1qlQuery = require('couchbase').N1qlQuery;

class UserSettingsDataAccess extends BaseModel {
    constructor() {
        super('usersettings');
    }
    save(model, callback) {
        model.DocumentId = model.DocumentId ? model.DocumentId : uuid.v4();
        app.buckets.usersettings.upsert(model.DocumentId, model, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, model);
        });
    }

    getById(id, callback) {
        app.buckets.usersettings.get(id, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result.value);
        });
    }

    delete(key, callback) {
        let query = N1qlQuery.fromString('DELETE FROM `usersettings` n where META(n).id = ($1)');
        app.buckets.notifications.query(query, [key], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result);
        });
    }

    getPagedBlockUser(filter, callback) {
        let scope = this;
        let queryString = 'SELECT  us.* FROM `usersettings` us WHERE us.OwnerId = $1 and us.Type = "blockeduser" order by us.CreatedAt desc limit $2 offset $3; ';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.userfriends.query(query, [filter.User, filter.PageSize,filter.PageSize * filter.PageIndex], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(error, results);
        });
    }

    checkBlocked(ownerId, blockedUserId, callback) {
        let scope = this;
        let queryString = 'SELECT  us.* FROM `usersettings` us WHERE us.OwnerId = $1 and us.BlockedUserId = $2  and us.Type = "blockeduser"; ';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.userfriends.query(query, [ownerId, blockedUserId], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(error, results);
        });
    }
}

module.exports = UserSettingsDataAccess;
