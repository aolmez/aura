'use strict';
const couchbase = require("couchbase");

class BaseModel {
    constructor(tablename) {
        this.mTableName = tablename;
    }
    get TableName() {
        return this.mTableName;
    }
    set TableName(name) {
        this.mTableName = name;
    }
    toString() {
        return 'BaseModel.${this.mTableName}';
    }
}

module.exports = BaseModel;
