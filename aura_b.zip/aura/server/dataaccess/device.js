'use strict';
const aws = require('aws-sdk');
const async = require("async");
const uuid = require('uuid/v4');
const BaseModel = require('./basemodel');
const BaseObject = require('./baseobject');
const BaseObjectType = require('./baseobjecttype');
const VenueUserModel = require('../models/venueusermodel');
const atomicCounter = require('dynamodb-atomic-counter');
const couchbase = require("couchbase");
const app = require("../../app");
const N1qlQuery = require('couchbase').N1qlQuery;
const AuraSettingsType = require('../models/aurasettingtype');
const PushNotificationSettingStatus = require('../models/pushnotificationsettingstatus');
const NotificationType = require('../models/notificationType');

class DeviceDataAccess extends BaseModel {
    constructor() {
        super('devices');
    }

    save(model, callback) {
        model.DocumentId = model.DocumentId ? model.DocumentId : uuid.v4();
        app.buckets.devices.upsert(model.DocumentId, model, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, model);
        });
    }

    getById(id, callback) {
        app.buckets.devices.get(id, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result.value);
        });
    }

    getByAll(callback) {
        let N1qlQuery = couchbase.N1qlQuery;
        let query = N1qlQuery.fromString('Sselect d.Token from devices d where d.Type= "token"');
        app.buckets.devices.query(query, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result);
        });
    }

    getByOwnerId(currentUser, ownerId, notificationType, callback) {
        let permissionCheckString = 'SELECT raw s.OwnerDocumentId FROM   settings s  where meta(s).id = "' + ownerId + '::$1" and s.Type = "pushsetting" and s.Status == 0';
        let permissionCheckQuery = N1qlQuery.fromString(permissionCheckString);
        app.buckets.settings.query(permissionCheckQuery, [notificationType], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            if (results == null || results.length == 0) {
                let query = N1qlQuery.fromString('select raw s.Status from settings s where meta().id = $1  and s.Type = "aurasetting"');
                app.buckets.settings.query(query, ["as::" + ownerId + "::" + AuraSettingsType.AllowMessageReplies], function (error, result) {
                    if (error) {
                        callback(error, null);
                        return;
                    }
                    else {
                        if (result && result.length > 0) {
                            let setting = result[0];
                            if (result == PushNotificationSettingStatus.Everyone || ownerId == currentUser) {
                                let queryString = 'SELECT d.* FROM `devices` d where d.OwnerId  = "' + ownerId + '";';
                                let query = N1qlQuery.fromString(queryString);
                                app.buckets.devices.query(query, [], function (error, results) {
                                    if (error) {
                                        callback(error, null);
                                        return;
                                    }
                                    callback(null, results);
                                });
                            }
                            else if (result == PushNotificationSettingStatus.PeopleYouFollow) {
                                let key = ownerId + '::' + currentUser;
                                query = N1qlQuery.fromString('select * from userfriends uf where  meta().id = $1 and uf.Type = "friend" ');
                                app.buckets.settings.query(query, [key], function (error, result) {
                                    if (error) {
                                        callback(error, null);
                                        return;
                                    }
                                    else {
                                        if (result.length <= 0) {
                                            callback(null, []);
                                        } else {
                                            let queryString = 'SELECT d.* FROM `devices` d where d.OwnerId  = "' + ownerId + '";';
                                            let query = N1qlQuery.fromString(queryString);
                                            app.buckets.devices.query(query, [], function (error, results) {
                                                if (error) {
                                                    callback(error, null);
                                                    return;
                                                }
                                                callback(null, results);
                                            });
                                        }
                                    }
                                });
                            } else {
                                callback(null, []);
                            }
                        } else if (result && result.length === 0) {
                            let queryString = 'SELECT d.* FROM `devices` d where d.OwnerId  = "' + ownerId + '";';
                            let query = N1qlQuery.fromString(queryString);
                            app.buckets.devices.query(query, [], function (error, results) {
                                if (error) {
                                    callback(error, null);
                                    return;
                                }
                                callback(null, results);
                            });
                        }
                        else {
                            callback(null, []);
                        }
                    }
                });
            } else {
                callback(null, []);
            }
        });

    }

    getFollowersByOwnerId(ownerId, notificationType, callback) {
        let innerQueryString = 'select raw cs from userfriends uf ' +
            ' left join settings s ' +
            ' ON KEYS  uf.OwnerDocumentId||"::$1" ' +
            '  LET  cs = CASE WHEN  s.Type = "pushsetting" and s.Status == 0 THEN MISSING ELSE uf.OwnerDocumentId END ' +
            ' where cs is not null and ' +
            ' uf.FriendDocumentId =  "' + ownerId + '" and uf.Type= "friend"';

        let innerQuery = N1qlQuery.fromString(innerQueryString);
        app.buckets.userfriends.query(innerQuery, [notificationType], function (error, userfriends) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                let queryString = 'SELECT d.* FROM `devices` d  where d.OwnerId in $1';
                let query = N1qlQuery.fromString(queryString);
                app.buckets.devices.query(query, [userfriends], function (error, results) {
                    if (error) {
                        if (error.code == 5010) {
                            callback(null, []);
                            return;
                        } else {
                            callback(error, null);
                            return;
                        }
                    }
                    callback(null, results);
                });
            }
        });
    }

    getFollowingsByOwnerId(ownerId, notificationType, callback) {
        let innerQueryString = 'select raw cs from userfriends uf ' +
            ' left join settings s ' +
            ' ON KEYS  uf.FriendDocumentId||"::$1" ' +
            '  LET  cs = CASE WHEN  s.Type = "pushsetting" and s.Status == 0 THEN MISSING ELSE uf.FriendDocumentId END ' +
            ' where cs is not null and ' +
            ' uf.OwnerDocumentId =  "' + ownerId + '" and uf.Type= "friend"';

        let innerQuery = N1qlQuery.fromString(innerQueryString);
        app.buckets.userfriends.query(innerQuery, [notificationType], function (error, userfriends) {
            if (error) {
                callback(error, null);
                return;
            }
            else {
                let queryString = 'SELECT d.* FROM `devices` d  where d.OwnerId in $1';
                let query = N1qlQuery.fromString(queryString);
                app.buckets.devices.query(query, [userfriends], function (error, results) {
                    if (error) {
                        if (error.code == 5010) {
                            callback(null, []);
                            return;
                        } else {
                            callback(error, null);
                            return;
                        }
                    }
                    callback(null, results);
                });
            }
        });
    }
}

module.exports = DeviceDataAccess;