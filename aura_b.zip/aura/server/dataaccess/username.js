'use strict';
const BaseModel = require('./basemodel');
const BaseObject = require('./baseobject');
const BaseObjectType = require('./baseobjecttype');

class UsernameDataAccess extends BaseModel {
    constructor(dynamodb) {
        super(dynamodb);
        super.TableName = 'users_username';
        this.mUsername = new BaseObject(BaseObjectType.String, undefined);
        this.mFullName = new BaseObject(BaseObjectType.String, undefined);
        this.mPhotoPath = new BaseObject(BaseObjectType.String, undefined);
    }
    get Model() {
        return super.mModel;
    }
    set Model(model) {
        super.mModel = model;
        this.mUsername.Value = this.mModel.Username;
        this.mFullName.Value = this.mModel.Fullname;
        this.mPhotoPath.Value = this.mModel.PhotoPath;
    }
    toAWSObject() {
        let params = {
            TableName: super.TableName,
            Item: {}
        };
        if (!this.mUsername.isEmpty())
            params.Item.username = this.mUsername.toAWSObject();
        if (!this.mFullName.isEmpty())
            params.Item.fullname = this.mFullName.toAWSObject();
        if (!this.mPhotoPath.isEmpty())
            params.Item.photopath = this.mPhotoPath.toAWSObject();
        return params;
    }
    toAWSFilter() {
        let params = {
            TableName: super.TableName,
            Key: {}
        };
        if (!this.mUsername.isEmpty())
            params.Key.username = this.mUsername.toAWSObject();
        if (!this.mFullName.isEmpty())
            params.Key.fullname = this.mFullName.toAWSObject();
        if (!this.mPhotoPath.isEmpty())
            params.Key.photopath = this.mPhotoPath.toAWSObject();
    }
    save(callback) {
        super.DynamoDB.putItem(this.toAWSObject(), callback);
    }
    getByPrimaryKey(callback) {
        let params = {
            TableName: this.TableName,
            KeyConditionExpression: "#username = :username",
            ExpressionAttributeNames: {
                "#username": "username"
            },
            ExpressionAttributeValues: {
                ":username": this.mUsername.toAWSObject()
            }
        };
        super.DynamoDB.query(params, callback);
    }
}

module.exports = UsernameDataAccess;
