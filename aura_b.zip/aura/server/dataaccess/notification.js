'use strict';
const aws = require('aws-sdk');
const async = require("async");
const uuid = require('uuid/v4');
const app = require("../../app");
const BaseModel = require('./basemodel');
const BaseObject = require('./baseobject');
const BaseObjectType = require('./baseobjecttype');
const N1qlQuery = require('couchbase').N1qlQuery;

class NotificationDataAccess extends BaseModel {
    constructor() {
        super('notifications');
    }

    save(model, callback) {
        model.DocumentId = model.DocumentId ? model.DocumentId : uuid.v4();
        app.buckets.notifications.upsert(model.DocumentId, model, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, model);
        });
    }

    delete(key, callback) {
        let query = N1qlQuery.fromString('DELETE FROM `notifications` n where META(n).id = ($1)');
        app.buckets.notifications.query(query, [key], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result);
        });
    }

    deleteByOwnerId(ownerId, callback) {
        let query = N1qlQuery.fromString('DELETE FROM `notifications` n where n.OwnerId = ($1)');
        app.buckets.notifications.query(query, [ownerId], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result);
        });
    }

    deleteByOwnerIdAndFirendId(ownerId, friendId, callback) {
        let query = N1qlQuery.fromString('DELETE FROM `notifications` n where n.OwnerId = ($1) and n.UserFriendId = ($2)');
        app.buckets.notifications.query(query, [ownerId, friendId], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result);
        });
    }

    getPaged(filter, callback) {
        let scope = this;
        let queryString = 'SELECT n.* ,auf IS NOT NULL as IsFollowed FROM `' + super.TableName + '` n ' +
            ' left join userfriends auf  ON KEYS n.UserFriendId ' +
            ' WHERE n.OwnerId = ($1) ' +
            ' order by n.CreatedAt desc limit $2 offset $3;';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.notifications.query(query, [filter.User, filter.PageSize, filter.PageSize * filter.PageIndex], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(error, results);
        });
    }
}

module.exports = NotificationDataAccess;
