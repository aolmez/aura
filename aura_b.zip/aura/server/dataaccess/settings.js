'use strict';
const aws = require('aws-sdk');
const async = require("async");
const uuid = require('uuid/v4');
const app = require("../../app");
const BaseModel = require('./basemodel');
const BaseObject = require('./baseobject');
const BaseObjectType = require('./baseobjecttype');
const PushNotificationSettingStatus = require('../models/pushnotificationsettingstatus');
const PushSettingsModel = require('../models/pushsettingsmodel');
const AuraSettingsModel = require('../models/aurasettingsmodel');
const NotificationType = require('../models/notificationType');
const N1qlQuery = require('couchbase').N1qlQuery;

class SettingsDataAccess extends BaseModel {
    constructor() {
        super('notifications');
    }

    save(model, callback) {
        model.DocumentId = model.DocumentId ? model.DocumentId : uuid.v4();
        app.buckets.settings.upsert(model.DocumentId, model, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            } else {
                callback(null, model);
            }
        });
    }

    getById(id, callback) {
        app.buckets.settings.get(id, function (error, result) {
            if (error) {
                callback(error, null);
            } else {
                callback(null, result.value);
            }
        });
    }

    getSettings(ownerDocumentId, callback) {
        let queryString = ' SELECT  s.* FROM `settings` s where s.OwnerDocumentId = $1 and s.Type = "pushsetting"';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.settings.query(query, [ownerDocumentId], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            if (results.length > 0) {
                let settings = new PushSettingsModel();
                for (let index = 0; index < results.length; index++) {
                    let item = results[index];
                    settings.set(item.NotificationType, item.Status);
                }
                callback(null, settings);
            } else {
                let settings = new PushSettingsModel();
                callback(null, settings);
            }
        });
    }

    getAuraSettings(ownerDocumentId, callback) {
        let queryString = ' SELECT  s.* FROM `settings` s where s.OwnerDocumentId = $1 and s.Type = "aurasetting"';
        let query = N1qlQuery.fromString(queryString);
        app.buckets.settings.query(query, [ownerDocumentId], function (error, results) {
            if (error) {
                callback(error, null);
                return;
            }
            if (results.length > 0) {
                let settings = new AuraSettingsModel();
                for (let index = 0; index < results.length; index++) {
                    let item = results[index];
                    settings.set(item.AuraSettingsType, item.Status);
                }
                callback(null, settings);
            } else {
                let settings = new AuraSettingsModel();
                callback(null, settings);
            }
        });
    }

    deleteById(key, callback) {
        let query = N1qlQuery.fromString('DELETE FROM  `settings` s where META(s).id = ($1)');
        app.buckets.settings.query(query, [key], function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result);
        });
    }
}

module.exports = SettingsDataAccess;
