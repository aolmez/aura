'use strict';
const aws = require('aws-sdk');
const async = require("async");
const uuid = require('uuid/v4');
const BaseModel = require('./basemodel');
const BaseObject = require('./baseobject');
const BaseObjectType = require('./baseobjecttype');
const VenueUserModel = require('../models/venueusermodel');
const atomicCounter = require('dynamodb-atomic-counter');
const couchbase = require("couchbase");
const app = require("../../app");
const N1qlQuery = require('couchbase').N1qlQuery;

class UserFriendsDataAccess extends BaseModel {
    constructor() {
        super('userfriends');
    }
    save(model, callback) {
        model.DocumentId = model.DocumentId ? model.DocumentId : uuid.v4();
        app.buckets.userfriends.upsert(model.DocumentId, model, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, model);
        });
    }

    getById(id, callback) {
        app.buckets.userfriends.get(id, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result.value);
        });
    }

    getByFollewerId(id, callback) {
        app.buckets.userfriends.get(id, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, result.value);
        });
    }
}

module.exports = UserFriendsDataAccess;
