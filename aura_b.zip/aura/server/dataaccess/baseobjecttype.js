'use strict';
const BaseObjectType = {
    String: 0,
    Bool: 1,
    Number: 2,
    List: 3
};

module.exports = BaseObjectType;