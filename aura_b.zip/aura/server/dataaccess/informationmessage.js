'use strict';
const aws = require('aws-sdk');
const async = require("async");
const uuid = require('uuid/v4');
const app = require("../../app");
const BaseModel = require('./basemodel');
const BaseObject = require('./baseobject');
const BaseObjectType = require('./baseobjecttype');
const N1qlQuery = require('couchbase').N1qlQuery;

class InformationMessageDataAccess extends BaseModel {
    constructor() {
        super('informationmessages');
    }

    save(model, callback) {
        model.DocumentId = model.DocumentId ? model.DocumentId : uuid.v4();
        app.buckets.informationmessages.upsert(model.DocumentId, model, function (error, result) {
            if (error) {
                callback(error, null);
                return;
            }
            callback(null, model);
        });
    } 
}

module.exports = InformationMessageDataAccess;
