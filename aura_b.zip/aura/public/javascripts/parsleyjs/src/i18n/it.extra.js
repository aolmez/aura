// Validation errors messages for Parsley
import Parsley from '../parsley';

Parsley.addMessages('it', {
  dateiso: "Inserire una data valida (AAAA-MM-GG)."
});
