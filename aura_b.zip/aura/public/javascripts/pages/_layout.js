$.fn.clearValidation = function () {
    var length = $(this).length;
    for (var index = 0; index < length; ++index) {
        $(this)[index].reset();
        $.each($(this)[index].elements, function (i, element) {
            var icon = $(element).parent('.input-with-icon').children('i');
            var parent = $(element).parent('.input-with-icon');
            icon.removeClass('fa fa-check').removeClass('fa fa-exclamation');
            parent.removeClass('success-control').removeClass('error-control');
        });
    }
};