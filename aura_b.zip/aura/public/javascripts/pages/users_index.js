$(document).ready(function () {
	"use strict";
		let users = new Users();
		users.loadDataTable();
});


class Users {

	constructor() { }

	loadDataTable() {
        $('#reservationTable').dataTable({
  "bProcessing" : true,
  "bServerSide" : true,
  "sAjaxSource" : '/users/datatable',
  "aoColumns" : [
    { "mData" : "name" },
    { "mData" : "email" },
    { "mData" : "email" },
    { "mData" : "email" }
  ]
});
	}

	static showFrmLoginLoadingAnimation() { }

	static hideFrmLoginLoadingAnimation() { }
}
