$(document).ready(function () {
    'use strict';
    $('#frmAuraSave [name=venue]').on('change', function () {
        var venue = jQuery.parseJSON(this.value);
        $('#frmAuraSave [name=VenueId]').val(venue.id);
        $('#frmAuraSave [name=Title]').val(venue.name);
        $('#frmAuraSave [name=Address]').val(venue.location.address);
        $('#frmAuraSave [name=City]').val(venue.location.city);
        $('#frmAuraSave [name=Latitude]').val(venue.location.lat);
        $('#frmAuraSave [name=Longitude]').val(venue.location.lng);
    });

    $("#frmLocation").parsley().on("form:submit", function () {
        $.ajax({
            dataType: "json",
            contentType: $("#frmLocation").attr('enctype'),
            url: $("#frmLocation").attr('action'),
            type: $("#frmLocation").attr('method'),
            data: $("#frmLocation").serializeArray(),
            success: function (result) {
                if (result && result.IsSuccess) {
                    if (result.Data && result.Data.length > 0) {
                        $('#frmAuraSave [name=venue]')
                            .find('option')
                            .remove()
                            .end();
                        $.each(result.Data, function (i, item) {
                            $('#frmAuraSave [name=venue]').append($('<option>', {
                                value: JSON.stringify(item),
                                text: item.name
                            }));
                        });
                        var venue = result.Data[0];
                        $('#frmAuraSave [name=VenueId]').val(venue.id);
                        $('#frmAuraSave [name=Title]').val(venue.name);
                        $('#frmAuraSave [name=Address]').val(venue.location.address);
                        $('#frmAuraSave [name=City]').val(venue.location.city);
                        $('#frmAuraSave [name=Latitude]').val(venue.location.lat);
                        $('#frmAuraSave [name=Longitude]').val(venue.location.lng);
                    } else {
                        $('#frmAuraSave [name=venue]')
                            .find('option')
                            .remove()
                            .end();
                    }
                }
            },
            error: function (jqXHR, erorThrown) {
                cubbysoftware.core.util.showErrorMessageBox(cubbysoftware.core.stringresources.ErrorMessageText);
            }
        });
        return false;
    });


    $("#frmAuraSave").parsley({ excluded: "input[type=text]:hidden" }).on("form:submit", function () {
        showFrmAuraSaveLoadingAnimation();
        $.ajax({
            dataType: "json",
            contentType: $("#frmAuraSave").attr('enctype'),
            url: $("#frmAuraSave").attr('action'),
            type: $("#frmAuraSave").attr('method'),
            data: $("#frmAuraSave").serializeArray(),
            success: function (result) {
                hideFrmAuraSaveLoadingAnimation();
                if (result && result.IsSuccess) {
                    $("#frmAuraSave").clearValidation();
                    cubbysoftware.core.util.showInfoMessageBox("Başarıyla kaydedildi.");
                } else {
                    cubbysoftware.core.util.showErrorMessageBox(result.Errors);
                }
            },
            error: function (jqXHR, erorThrown) {
                hideFrmAuraSaveLoadingAnimation();
                cubbysoftware.core.util.showErrorMessageBox(cubbysoftware.core.stringresources.ErrorMessageText);
            }
        });
        return false;
    });
    $('#frmAuraSave [name=BaseType]').change(function () {
        if ($("#frmAuraSave [name=BaseType]:checked").val() == '0') {
            $("#frmVideoUploader").hide();
            $("#divDuration").hide();
            $("#divVideoDocumentPath").hide();
        } else {
            $("#frmVideoUploader").show();
            $("#divDuration").show();
            $("#divVideoDocumentPath").show();
        }
    });

    $("#frmLicenseDocumentCreateUploader").empty();
    var csrf_token = $('meta[name="csrf-token"]').attr('content');
    $("#frmLicenseDocumentCreateUploader").pluploadQueue({
        runtimes: 'html5, html4, Flash, Silverlight',
        url: '/admin/uploader?_csrf=' + csrf_token,
        chunk_size: '300Kb',
        unique_names: true,
        multi_selection: false,
        max_file_count: 1,
        filters: {
            max_file_size: '10mb',
            mime_types: [{
                title: "jpeg dosyası",
                extensions: "jpeg"
            }]
        },
        init: {
            UploadProgress: function (uploader, file) {
                console.log('file%: ' + file.percent);

            },
            FileUploaded: function (uploader, file, response) {
                const formdata = $.parseJSON(response.response);
                if (formdata && formdata.IsSuccess) {
                    const filename = formdata.Data;
                    const extra = formdata.ExtraData;
                    $('#frmAuraSave [name=DocumentPath]').val(filename);
                }
            },
            UploadComplete: function (uploader, file) {
                if (uploader.total.uploaded == uploader.files.length) {
                    //DocumentCreateForm.loadUploader();
                }
            }
        }
    });

    $("#frmVideoUploader").empty();
    $("#frmVideoUploader").pluploadQueue({
        runtimes: 'html5, html4, Flash, Silverlight',
        url: '/admin/uploader?_csrf=' + csrf_token,
        chunk_size: '300Kb',
        unique_names: true,
        multi_selection: false,
        max_file_count: 1,
        filters: {
            max_file_size: '10mb',
            mime_types: [{
                title: "mp4 dosyası",
                extensions: "mp4"
            }]
        },
        init: {
            UploadProgress: function (uploader, file) {
                console.log('file%: ' + file.percent);

            },
            FileUploaded: function (uploader, file, response) {
                const formdata = $.parseJSON(response.response);
                if (formdata && formdata.IsSuccess) {
                    const filename = formdata.Data;
                    const extra = formdata.ExtraData;
                    $('#frmAuraSave [name=VideoDocumentPath]').val(filename);
                }
            },
            UploadComplete: function (uploader, file) {
                if (uploader.total.uploaded == uploader.files.length) {
                    //DocumentCreateForm.loadUploader();
                }
            }
        }
    });
    $("#frmVideoUploader").hide();


    $.ajax({
        dataType: "json",
        contentType: $("#frmGetAllUser").attr('enctype'),
        url: $("#frmGetAllUser").attr('action'),
        type: $("#frmGetAllUser").attr('method'),
        success: function (result) {
            if (result && result.IsSuccess) {
                var users = jQuery.parseJSON(result.Data);
                $('#frmAuraSave [name=UserId]')
                    .find('option')
                    .remove()
                    .end();
                if (users != null && users.length > 0) {
                    $.each(users, function (i, item) {
                        $('#frmAuraSave [name=UserId]').append($('<option>', {
                            value: item.DocumentId,
                            text: item.Fullname
                        }));
                    });
                }
            }
            else {
                cubbysoftware.core.util.showErrorMessageBox(result.Errors);
            }
        },
        error: function (jqXHR, erorThrown) {
            cubbysoftware.core.util.showErrorMessageBox(cubbysoftware.core.stringresources.ErrorMessageText);
        }
    });
});



function showFrmAuraSaveLoadingAnimation() {
    $("#frmAuraSave").block({
        message: '<i class="icon-spinner9 icon-3x  spinner"></i>',
        overlayCSS: {
            backgroundColor: '#fff',
            opacity: 0.8,
            cursor: 'wait'
        },
        css: {
            border: 0,
            padding: 0,
            backgroundColor: 'none'
        }
    });
}

function hideFrmAuraSaveLoadingAnimation() {
    $("#frmAuraSave").unblock();
}

function initMap() {
    var myLatlng = { lat: 38.42365482344079, lng: 27.142939929077215 };

    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 14,
        center: myLatlng
    });
    map.addListener('click', function (event) {
        var lat = event.latLng.lat();
        var lng = event.latLng.lng();
        $("#frmLocation [name=lat]").val(lat);
        $("#frmLocation [name=lng]").val(lng);
        $("#frmLocation").submit();
    });
}