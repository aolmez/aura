$(document).ready(function () {
    'use strict';
    $("#frmLogin").parsley().on("form:submit", function () {
        showFrmLoginLoadingAnimation();
        $.ajax({
            dataType: "json",
            contentType: $("#frmLogin").attr('enctype'),
            url: $("#frmLogin").attr('action'),
            type: $("#frmLogin").attr('method'),
            data: $("#frmLogin").serializeArray(),
            success: function (result) {
                if (result && result.IsSuccess) {
                    window.location.href = result.Url;
                }
                else {
                    hideFrmLoginLoadingAnimation();
                    cubbysoftware.core.util.showErrorMessageBox(result.Errors);
                }
            },
            error: function (jqXHR, erorThrown) {
                hideFrmLoginLoadingAnimation();
                cubbysoftware.core.util.showErrorMessageBox(cubbysoftware.core.stringresources.ErrorMessageText);
            }
        });
        return false;
    });
});

function showFrmLoginLoadingAnimation() {
    $("#frmLogin .login-form").block({
        message: '<i class="icon-spinner9 icon-3x  spinner"></i>',
        overlayCSS: {
            backgroundColor: '#fff',
            opacity: 0.8,
            cursor: 'wait'
        },
        css: {
            border: 0,
            padding: 0,
            backgroundColor: 'none'
        }
    });
}

function hideFrmLoginLoadingAnimation() {
    $("#frmLogin .login-form").unblock();
}