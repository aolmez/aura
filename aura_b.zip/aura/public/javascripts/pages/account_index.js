$(document).ready(function () {
    'use strict';

    $("#frmCreateUser").parsley().on("form:submit", function () {
        showFrmCreateUserLoadingAnimation();
        $.ajax({
            dataType: "json",
            contentType:  $("#frmCreateUser").attr('enctype'),
            url: $("#frmCreateUser").attr('action'),
            type: $("#frmCreateUser").attr('method'),
            data: $("#frmCreateUser").serializeArray(),
            success: function (result) {
                hideFrmCreateUserLoadingAnimation();
                if (result && result.IsSuccess) {
                    $("#frmCreateUser").clearValidation();
                    cubbysoftware.core.util.showInfoMessageBox("Başarıyla kaydedildi.");
                }
                else {
                    cubbysoftware.core.util.showErrorMessageBox(result.Errors);
                }
            },
            error: function (jqXHR, erorThrown) {
                hideFrmCreateUserLoadingAnimation();
                cubbysoftware.core.util.showErrorMessageBox(cubbysoftware.core.stringresources.ErrorMessageText);
            }
        });
        return false;
    });

    var csrf_token = $('meta[name="csrf-token"]').attr('content');
    $("#frmUploader").pluploadQueue({
        runtimes: 'html5, html4, Flash, Silverlight',
        url: '/admin/uploadTemp?_csrf=' + csrf_token,
        chunk_size: '300Kb',
        unique_names: true,
        multi_selection: false,
        max_file_count: 1,
        filters: {
            max_file_size: '10mb',
            mime_types: [{
                title: "jpeg dosyası",
                extensions: "jpeg"
            }]
        },
        init: {
            UploadProgress: function (uploader, file) {
                console.log('file%: ' + file.percent);

            },
            FileUploaded: function (uploader, file, response) {
                const formdata = $.parseJSON(response.response);
                if (formdata && formdata.IsSuccess) {
                    const filename = formdata.Data;
                    const extra = formdata.ExtraData;
                    $('#frmCreateUser [name=PhotoPath]').val(filename);
                }
            },
            UploadComplete: function (uploader, file) {
                if (uploader.total.uploaded == uploader.files.length) {
                    //DocumentCreateForm.loadUploader();
                }
            }
        }
    });

});



function showFrmCreateUserLoadingAnimation() {
    $("#frmCreateUser").block({
        message: '<i class="icon-spinner9 icon-3x  spinner"></i>',
        overlayCSS: {
            backgroundColor: '#fff',
            opacity: 0.8,
            cursor: 'wait'
        },
        css: {
            border: 0,
            padding: 0,
            backgroundColor: 'none'
        }
    });
}

function hideFrmCreateUserLoadingAnimation() {
    $("#frmCreateUser").unblock();
}