﻿var cubbysoftware = cubbysoftware || {};
cubbysoftware.core = cubbysoftware.core || {};
cubbysoftware.core.stringresources = cubbysoftware.core.stringresources || {};

cubbysoftware.core.stringresources.AlertConfirmButtonText = 'Tamam';
cubbysoftware.core.stringresources.ErrorMessageTitle = 'Hata!';
cubbysoftware.core.stringresources.WarningMessageTitle = 'Uyarı';
cubbysoftware.core.stringresources.InfoMessageTitle = 'Bilgi';
cubbysoftware.core.stringresources.SuccessMessageTitle = 'İşleminiz başarıyla gerçekleşti.';
cubbysoftware.core.stringresources.QuestionMessageTitle = 'Soru?';

cubbysoftware.core.stringresources.ErrorMessageText = 'Hata oluştu.';
cubbysoftware.core.stringresources.WarningMessageText = 'Uyarı';
cubbysoftware.core.stringresources.InfoMessageText = 'Bilgi';
cubbysoftware.core.stringresources.SuccessMessageText = 'İşlem Başarılı!';
cubbysoftware.core.stringresources.QuestionMessageText = 'Soru';
cubbysoftware.core.stringresources.WaitingMessageText = 'İşlem Başarıyla kayıt altına alındı. Tamamlanması için bekleyiniz!';

cubbysoftware.core.stringresources.ComboDefaultText = '--- Lüften Seçiniz ---';


cubbysoftware.core.stringresources.FileRemoveError = 'Dosya silinirken bir hata oluştu.';
cubbysoftware.core.stringresources.PasswordReseted = 'Kullanıcı şifresi sıfırlandı.';
cubbysoftware.core.stringresources.SubIdNotFoundMessageText = 'Seçmiş olduğunuz kullanıcının My Drive kimliği bulunmamaktadır.';



