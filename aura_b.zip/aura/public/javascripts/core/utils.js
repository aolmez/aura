﻿var cubbysoftware = cubbysoftware || {};
cubbysoftware.core = cubbysoftware.core || {};
cubbysoftware.core.util = (function () {
    'use strict';
    var utilModel = (function () {

        //Messagebox

        var showInfoMessageBox = function (text) {
            swal({
                title: cubbysoftware.core.stringresources.InfoMessageTitle,
                text: text,
                confirmButtonColor: "#2196F3",
                confirmButtonText: cubbysoftware.core.stringresources.AlertConfirmButtonText,
                type: "info"
            });
        };

        var showErrorMessageBox = function (text) {
            swal({
                title: cubbysoftware.core.stringresources.ErrorMessageTitle,
                text: text,
                confirmButtonColor: "#EF5350",
                confirmButtonText: cubbysoftware.core.stringresources.AlertConfirmButtonText,
                type: "error"
            });
        };

        var showWarningMessageBox = function (text) {
            swal({
                title: cubbysoftware.core.stringresources.WarningMessageTitle,
                text: text,
                confirmButtonColor: "#FF7043",
                confirmButtonText: cubbysoftware.core.stringresources.AlertConfirmButtonText,
                type: "warning"
            });
        }

        var showSuccessMessageBox = function (text) {
            swal({
                title: cubbysoftware.core.stringresources.SuccessMessageTitle,
                text: text,
                confirmButtonColor: "#66BB6A",
                confirmButtonText: cubbysoftware.core.stringresources.AlertConfirmButtonText,
                type: "success"
            });
        };

        var showCombineMessagesMessageBox = function (text, showCancelButton, isConfirmText, isnotConfirmText) {
            swal({
                title: cubbysoftware.core.stringresources.QuestionMessageTitle,
                text: text,
                type: "warning",
                showCancelButton: showCancelButton,
                confirmButtonColor: "#EF5350",
                confirmButtonText: "Onayla",
                cancelButtonText: "İptal Et",
                closeOnConfirm: false,
                closeOnCancel: false
            },
         function (isConfirm) {
             if (isConfirm) {
                 swal({
                     title: "İşlem Başarılı",
                     text: isConfirmText,
                     confirmButtonColor: "#66BB6A",
                     type: "success"
                 });
             }
             else {
                 swal({
                     title: "İşlem İptal Edildi",
                     text: isnotConfirmText,
                     confirmButtonColor: "#2196F3",
                     type: "error"
                 });
             }
         });
        };

        //Notification

        var showNotificationInfo = function (text) {
            $.jGrowl(text, {
                header: cubbysoftware.core.stringresources.InfoMessageTitle,
                theme: 'bg-info',
                position: 'top-right'
            });
        };

        var showNotificationError = function (text) {
            $.jGrowl(text, {
                header: cubbysoftware.core.stringresources.ErrorMessageTitle,
                theme: 'bg-danger',
                position: 'top-right'
            });
        };

        var showNotificationWarning = function (text) {
            $.jGrowl(text, {
                header: cubbysoftware.core.stringresources.WarningMessageTitle,
                theme: 'bg-warning',
                position: 'top-right'
            });
        }

        var showNotificationSuccess = function (text) {
            $.jGrowl(text, {
                header: cubbysoftware.core.stringresources.SuccessMessageTitle,
                theme: 'bg-success',
                position: 'top-right'
            });
        };


        var convertNETDateTime = function (data) {
            if (data == null) return '1/1/1950';
            var r = /\/Date\(([0-9]+)\)\//gi
            var matches = data.match(r);
            if (matches == null) return '1/1/1950';
            var result = matches.toString().substring(6, 19);
            var epochMilliseconds = result.replace(
            /^\/Date\(([0-9]+)([+-][0-9]{4})?\)\/$/,
            '$1');
            var b = new Date(parseInt(epochMilliseconds));
            var c = new Date(b.toString());
            var curr_date = c.getDate();
            var curr_month = c.getMonth() + 1;
            var curr_year = c.getFullYear();
            var curr_h = c.getHours();
            var curr_m = c.getMinutes();
            var curr_s = c.getSeconds();
            var curr_offset = c.getTimezoneOffset() / 60;
            var d = padLeft(curr_date, 2) + '/' + padLeft(curr_month.toString(), 2) + '/' + curr_year + " " + padLeft(curr_h, 2) + ':' + padLeft(curr_m, 2) + ':' + padLeft(curr_s, 2);
            return d;
        };

        var padLeft = function (nr, n, str) {
            return Array(n - String(nr).length + 1).join(str || '0') + nr;
        };


        var getParam = function (name) {
            if (name = (new RegExp('[?&]' + encodeURIComponent(name) + '=([^&]*)')).exec(location.search))
                return decodeURIComponent(name[1]);
        };

        return {
            showInfoMessageBox: showInfoMessageBox,
            showErrorMessageBox: showErrorMessageBox,
            showWarningMessageBox: showWarningMessageBox,
            showSuccessMessageBox: showSuccessMessageBox,
            showCombineMessagesMessageBox: showCombineMessagesMessageBox,
            showNotificationInfo: showNotificationInfo,
            showNotificationError: showNotificationError,
            showNotificationWarning: showNotificationWarning,
            showNotificationSuccess: showNotificationSuccess,
            convertNETDateTime: convertNETDateTime,
            padLeft: padLeft,
            getParam: getParam

        };

    }());
    return utilModel;
}());

String.prototype.replaceAll = function (search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};