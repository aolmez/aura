const express = require("express");
const session = require('express-session');
const redisStore = require('connect-redis')(session);
const expressValidator = require('express-validator');
const aws = require('aws-sdk');
const firebase = require('firebase');
const admin = require('firebase-admin');
const raven = require('raven');
const couchbase = require("couchbase");
const io = require('socket.io');
const csrf = require('csurf');
const path = require('path');
const logger = require('morgan');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const debug = require('debug')('CubbySoftware');
const passport = require('passport');
const dotenv = require('dotenv');
const cluster = require('cluster');
const os = require('os');
const compression = require('compression');
const Https = require('./https');
const Formdata = require('./server/core/formdata');
const NotificationManager = require('./server/core/notificationManager');
const DataHelper = require('./server/common/dataHelper');

/**
 * Load environment variables from .env file, where API keys and passwords are configured.
 */
dotenv.load({path: '.env.variables'});

const app = express();
app.disable('x-powered-by');
app.use(compression());

const pages = require('./routes/pages');
const api = require('./routes/api');
const adminPages = require('./routes/admin');

raven.config(process.env.RAVEN_DSN).install();

// view engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'ejs');
app.set('port', process.env.PORT || 3000);

app.set('trust proxy', 1);
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(expressValidator());
//app.use(express.methodover);
app.use(cookieParser());
app.use(passport.initialize());
app.use(passport.session());

app.use(require('stylus').middleware(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', api);
app.use(csrf({cookie: true}));
if (process.env.USE_REDIS && process.env.USE_REDIS == 'true') {
    app.use(session({
        store: new redisStore({
            host: process.env.REDIS_HOST,
            port: process.env.REDIS_PORT,
            prefix: process.env.REDIS_PREFIX,
            ttl: 1000,
            disableTTL: true,
            scanCount: 32,
            unref: true
        }),
        secret: process.env.SESSION_SECRET
    }));
}
else {
    app.use(session({
        secret: process.env.SESSION_SECRET,
        resave: false,
        saveUninitialized: true,
        //cookie: { secure: true }
        cookie: {maxAge: 600000, httpOnly: false}
    }));
}

// The request handler must be the first middleware on the app
app.use(raven.requestHandler());

app.use('/', pages);
app.use('/admin', adminPages);

app.use(raven.errorHandler());

module.exports.raven = raven;

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

app.use(function (err, req, res, next) {
    let formdata = new Formdata();
    formdata.ErrorCode = err.status || 500;
    formdata.Errors = err.message;
    formdata.IsSuccess = false;
    res.json(formdata);
});

connect();

function connect() {
    let couchbaseCluster = new couchbase.Cluster(process.env.COUCHBASE_URL);
    couchbaseCluster.authenticate(process.env.COUCHBASE_USERNAME, process.env.COUCHBASE_PASSWORD);
    module.exports.buckets = {};
    module.exports.buckets.user = couchbaseCluster.openBucket(process.env.COUCHBASE_BUCKET_USERS);
    module.exports.buckets.userfriends = couchbaseCluster.openBucket(process.env.COUCHBASE_BUCKET_USER_FRIENDS);
    module.exports.buckets.aura = couchbaseCluster.openBucket(process.env.COUCHBASE_BUCKET_AURA);
    module.exports.buckets.auralikers = couchbaseCluster.openBucket(process.env.COUCHBASE_BUCKET_AURA_LIKERS);
    module.exports.buckets.aurawatchers = couchbaseCluster.openBucket(process.env.COUCHBASE_BUCKET_AURA_WATCHERS);
    module.exports.buckets.venueusers = couchbaseCluster.openBucket(process.env.COUCHBASE_BUCKET_VENUE_USERS);
    module.exports.buckets.devices = couchbaseCluster.openBucket(process.env.COUCHBASE_BUCKET_DEVICES);
    module.exports.buckets.notifications = couchbaseCluster.openBucket(process.env.COUCHBASE_BUCKET_NOTIFICATION);
    module.exports.buckets.settings = couchbaseCluster.openBucket(process.env.COUCHBASE_BUCKET_SETTINGS);
    module.exports.buckets.usersettings = couchbaseCluster.openBucket(process.env.COUCHBASE_BUCKET_USERSETTINGS);
    module.exports.buckets.informationmessages = couchbaseCluster.openBucket(process.env.COUCHBASE_BUCKET_INFORMATIONMESSAGES);


    const foursquare = require('node-foursquare-venues')(process.env.FOURSQUARE_CLIENT_ID, process.env.FOURSQUARE_CLIENT_SECRET);
    module.exports.foursquare = foursquare;

    let notificationManager = new NotificationManager();
    notificationManager.init();
    module.exports.notification = {};
    module.exports.notification.manager = notificationManager;

    /*
    let dataHelper = new DataHelper();
    dataHelper.init();
    */

    const useHttps = (process.env.USE_HTTPS && process.env.USE_HTTPS == 'true') ? true : false;
    if (useHttps) {
        const https = Https({
            httpsPort: 443
        });
    }
    else {
        if (process.env.DEBUG_MODE && process.env.DEBUG_MODE == 'false' && cluster.isMaster) {
            console.log(`Master ${process.pid} is running`);
            const numCPUs = os.cpus().length;
            for (let i = 0; i < numCPUs; i++) {
                cluster.fork();
            }
            cluster.on('exit', (worker, code, signal) => {
                console.log(`worker ${worker.process.pid} died`);
            });
        }
        else {
            const server = app.listen(app.get('port'), function () {
                debug('Express server listening on port ' + server.address().port);
            });
        }
    }
}